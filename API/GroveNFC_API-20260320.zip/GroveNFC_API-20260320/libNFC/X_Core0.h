/*
NFC runs on RP2040's core0
*/

#ifndef __XCORE0_H__
#define __XCORE0_H__

	//GroveNFC Hardware V1.0, PS-20260202
	//////////////////////////////////////////////////
	//output gpio
	//Reader mode, gpio output pwm 
	#define IOO_CARRIER_13M56			12  //&13
	#define IOO_CARRIER_13M56_OPT		10  //&11
	#define IOO_PWM_41K4					18

	//Tag mode, gpio output to load modulate
	#define IOO_14443ATAG_MODULATE		9
	#define IOO_14443BTAG_MODULATE		IOO_14443ATAG_MODULATE
	#define IOO_15693TAG_MODULATE		IOO_14443ATAG_MODULATE
	#define IOO_FELICATAG_MODULATE		IOO_14443ATAG_MODULATE
	
	#define IOO_BUSY					19  //1--busy
		#define IOO_BUSY_ASSERT				sio_hw->gpio_set = (1<<IOO_BUSY);
		#define IOO_BUSY_DESASSERT 			sio_hw->gpio_clr = (1<<IOO_BUSY);
		
	#define IOO_INDICATOR_LED			6
		#define INDICATOR_LED_ON			sio_hw->gpio_set = (1<<IOO_INDICATOR_LED);
		#define INDICATOR_LED_OFF 			sio_hw->gpio_clr = (1<<IOO_INDICATOR_LED);
		#define INDICATOR_LED_TOG			sio_hw->gpio_togl = (1<<IOO_INDICATOR_LED);
		
	#define IOO_NFC_LED					7
		#define IOO_NFC_LED_ON				sio_hw->gpio_set = (1<<IOO_NFC_LED);
		#define IOO_NFC_LED_OFF 			sio_hw->gpio_clr = (1<<IOO_NFC_LED);
		#define IOO_NFC_LED_TOG				sio_hw->gpio_togl = (1<<IOO_NFC_LED);
		
	#define IOO_RSSI_LED				8
		#define IOO_RSSI_LED_ON				sio_hw->gpio_set = (1<<IOO_RSSI_LED);
		#define IOO_RSSI_LED_OFF 			sio_hw->gpio_clr = (1<<IOO_RSSI_LED);
		#define IOO_RSSI_LED_TOG			sio_hw->gpio_togl = (1<<IOO_RSSI_LED);

	//input gpio
	//Reader mode, gpio input for tag's data
	#define IOI_14443ATAG_RSP		14
	#define IOI_14443BTAG_RSP		IOI_14443ATAG_RSP	
	#define IOI_15693TAG_RSP		IOI_14443ATAG_RSP
	#define IOI_FELICATAG_RSP		IOI_14443ATAG_RSP
	//Tag mode, gpio input for reader's command, use for PIO machine
	#define IOI_14443AREADER_REQ		15
	#define IOI_14443BREADER_REQ		IOI_14443AREADER_REQ
	#define IOI_15693READER_REQ			IOI_14443AREADER_REQ
	#define IOI_FELICAREADER_REQ		IOI_14443AREADER_REQ

	//input ADC
	//carrier amplitude
	#define ADC_RSSI 	29
	//////////////////////////////////////////////////////

//Tag Emulator Buffer
//extern uint8_t u8TagRecvCmd[256];
//extern uint8_t u8TagSimData[4096];
	
#endif
