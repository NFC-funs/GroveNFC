#ifndef     __X_14443AHW_H__
#define     __X_14443AHW_H__

#include <stdint.h>
#include <stdio.h>

#include "pico/stdlib.h"

/* ###################################### */
/* return parity - 1 or 0                 */
/* ###################################### */
uint8_t oddparity(uint8_t bt);

/* ###################################### */
/* return ISO14443A crc16                 */
/* high byte transmit first               */
/* ###################################### */
uint16_t crc16_A(uint8_t *data, uint16_t len);

/* ###################################### */
/* return true or false                   */
/* ###################################### */
bool HasValidCrcA(uint8_t *receivedCmd, uint16_t receivedCmd_len);

/* ###################################### */
/* append crc to the end of data          */
/* ###################################### */
void AppendCrcA(uint8_t *data, uint16_t len);

/*
///////////////////////////////reader/////////////////////////////////////////////////////////////////////
//timing for 14443A
///////////////////////////////////////////////////////
//PS-20220828
//PCD --> PICC timing
//X -- 64/fc + pause(32/fc) + 32/fc
//Y -- 128/fc
//Z -- pause(32/fc) + 96/fc
//logic 1 -- X
//logic 0 -- Y/Z instead of Y
//SOF -- Z
//EOF -- logic 0 + Y
*/
/* ###################################### */
/*Call this function after X_NFCFiledOn();*/
/*Delay time = u16timer * 2.36us          */
/* ###################################### */
void RF14443A_Carrier_On_Delay(uint16_t u16timer); //unit -- 32/fc

/* ######################################### */
/* transmit data                             */
/* uint8_t *buf: transmit data buffer        */
/* uint8_t *par: parity bit - 0 or 1         */
/* uint8_t parflag: 1 - transmit par;0 - dont transmit par*/
/* uint16_t len: length of transmit data     */
/* uint8_t TxLastBits: 0 - 8bits;1:7 - 1-7bits*/
/* ######################################### */
void __not_in_flash_func(RF14443A_Reader_SendData)(uint8_t *buf, uint8_t *par, uint8_t parFlag, uint16_t len, uint8_t TxLastBits);
/*
///////////////////////////////////////////////////////
//PS-20220828
//PICC --> PCD delay = (n*128-204)/fc,the MIN is 70us(n=9)
//n =9,REQA/WAKE-UP/ANTICOLLISION/SELECT
//n>=9,other command
//last data bit is "logic 1" -- FDT=(n*128+84)/fc -- delay=FDT-256/fc-32/fc 91.15us
//last data bit is "logic 0" -- FDT=(n*128+20)/fc -- delay=FDT-(256/fc-32/fc) 86.43us
//ex: cmd-0x52 FDT=91.15us
//    cmd-0x93 0x20 FDT=86.43us
///////////////////////////////////////////////////////
*/

/* ######################################### */
/* return length of receive data             */
/* uint8_t *recv_buf: receive data buffer    */
/* uint8_t nbit: 9 - include parity bit and ignore the bit;8 - parity bit as data;4 - 4bits ack*/
/* uint8_t encryption: 0 - unencryted;1 - encryted; Mifare mode*/
/* uint16_t u16FDT: FDT Max = u16FDT * 9.44us*/
/* ######################################### */
int16_t __not_in_flash_func(RF14443A_Reader_RecvData)(uint8_t *recv_buf, uint8_t nbit, uint8_t encryption, uint16_t u16FDT);

/* ######################################### */
/* PIO: receive tag's data in reader mode    */
/* ######################################### */
//capture rising edge
void X_PIOCapture1Init();
void X_PIOCapture1Deinit();
/////////////////////////////////////////////////

/* ################tag mode#######################
    PS-20220828
    PICC --> PCD timing,fs=fc/16
    D -- 4/fs + 64/fc
    E -- 64/fc + 4/fs
    F -- 128/fc
    logic 1 -- D
    logic 0 -- E
    SOF -- D
    EOF -- F
    PS-20230820 test wave
    demodulate PCD --> PICC data
    low after pause about 500ns
    pause time is about 2.1us(actually,its 2.36us)*/
/////////////////////////////////////////////////////

/* ######################################### */
/* response 4bit ack in tag mode             */
/* ######################################### */
void __not_in_flash_func(X_14443A_Tag_Send4bit)(uint8_t data4bit);

/* ######################################### */
/* response data in tag mode                 */
/* uint8_t *resp: response data buffer       */
/* uint16_t len: length of response data     */
/* uint8_t parflag: 1 - transmit par;0 - dont transmit par*/
/* uint8_t *par: parity bit - 0 or 1         */
/* ######################################### */
void __not_in_flash_func(X_14443A_Tag_SendData)(uint8_t *resp, uint16_t len, uint8_t parFlag, uint8_t *par);

/* ######################################### */
/* callback function in tag mode             */
/* ######################################### */
typedef int (*ISO14ACbEmul)(uint16_t len);
int __not_in_flash_func(ISO14A_callback)(ISO14ACbEmul callback, uint16_t len);
//X_ISO14A_Tag_Emul call back function
int __not_in_flash_func(X_ISO14A_Tag_Emul)(uint16_t len);

/* ######################################### */
/* PIO: receive reader's command in tag mode */
/* ######################################### */
//capture falling edge and filter inter-pulse
void X_PIOCapture0filterInit();
void X_PIOCapture0filterDeinit();


#endif
