#ifndef __XCOMM_H__
#define __XCOMM_H__

uint8_t X_SystemInit(void);
uint8_t X_NFCInit();
void X_NFCFiledOn();
void X_NFCFiledOff();
void X_NFCSetRef(uint16_t voltage);

#endif
