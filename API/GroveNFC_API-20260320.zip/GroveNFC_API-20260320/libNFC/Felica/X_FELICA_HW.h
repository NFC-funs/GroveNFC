#ifndef     __X_FELICA_H__
#define     __X_FELICA_H__

#include <stdint.h>
#include <stdio.h>

#include "pico/stdlib.h"

///////////////////////////////////////////////////////
//PS-20250131
//PCD --> PICC timing
//etu -- 128/(D*Fc)
//	D=2 Bit-rate=Fc/64=212kbps
//	D=4 Bit-rate=Fc/32=424kbps
//ASK 10%
//logic 1: H(unmodulated state) + L
//logic 0: L + H(unmodulated state)


//PICC -- > PCD timing, No subcarrier
//logic 1: H(unmodulated state) + L
//logic 0: L + H(unmodulated state)
//Character transmission format: MSB
//Frame format:
//	Preamble(6 bytes): 00-00-00-00-00-00
//	Sync code(2 bytes): B2-4D
//	LEN(1 byte): 
//	Data field(0-254 bytes): length is (LEN - 1)
//	EDC: CRC(2 bytes), Error detection code -- (LEN + Data field)
//the first time slot shall start after 512*64/Fc=2.417ms
//time slot duration: 256*64/Fc=1.208ms

//PS-20250201
//Hardware: Pico-NFC-V1.0 20241210
//PICC -- > PCD code
//logic 0: ----____ or ________
//logic 1: ____----
//Preamble: 46-47 '0's, not 48
///////////////////////////////////////////////////////


/* ###################################### */
/*Call this function after X_NFCFiledOn();*/
/*Delay time = u16timer * 2.36us          */
/* ###################################### */
void RFFelica_Carrier_On_Delay(uint16_t u16timer); //unit -- 32/fc

/* ###################################### */
/* return Felica crc16                    */
/* high byte transmit first                */
/* ###################################### */
uint16_t crc16_F(uint8_t *data, uint16_t len);

/* ###################################### */
/* return true or false                   */
/* ###################################### */
bool HasValidCrcF(uint8_t *receivedCmd, uint16_t receivedCmd_len);

/* ###################################### */
/* append crc to the end of data          */
/* ###################################### */
void AppendCrcF(uint8_t *data, uint16_t len);

/* ######################################### */
/* transmit clear txt data, u8speed: 0-212K  */
/* uint8_t *buf: transmit data buffer        */
/* uint16_t len: length of transmit data     */
/* ######################################### */
void __not_in_flash_func(FELICA_Reader_SendData)(uint8_t *buf, uint16_t len, uint8_t u8speed);

/* ######################################### */
/* return length of receive data             */
/* receive clear txt data, u8speed: 0-212K   */
/* uint8_t *recv_buf: receive data buffer    */
/* uint8_t u8Slot: time slot                 */
/* ######################################### */
int16_t __not_in_flash_func(FELICA_Reader_RecvData)(uint8_t *recv_buf, uint8_t u8Slot, uint8_t u8speed);

/* ######################################### */
/* PIO: receive tag's data in reader mode    */
/* ######################################### */
//capture rising edge
void X_PIOFelica1Init();
void X_PIOFelica1Deinit();

void X_PIOFelica10Init();
void X_PIOFelica10Deinit();

#endif
