#include <stdio.h>
#include <string.h>

#include "libNFC/X_Core0.h"
#include "libNFC/ISO14A/X_14443A_HW.h"
#include "X_ISO14A_App.h"
#include "2-NFC/ISO14A/Ntag/X_Ntag.h"

//////////////////////////////////////////////////////////////////////////////
#define ISO14A_READER
#ifdef ISO14A_READER

	uint16_t X_RF14443A_Reqa(void)
	{
		uint8_t buffer[2] = {0};
		uint8_t buf[2];
		uint8_t i;
		int16_t recv_len;

		//REQA,0x26 WUPA,0x52
		for(i=0;i<3;i++)
		{
			buf[0] = 0x52;
			//read consecutive sector must use WUPA--0x52
			printf("WUPA: %02x \n",buf[0]);  //52
			RF14443A_Reader_SendData(buf, buf, 0, 1, 7);
			recv_len = RF14443A_Reader_RecvData(buffer, 9, 0, 18);

			if(recv_len == 2)
			{
				printf("WUPA-ATQA: %02x %02x \n",buffer[0],buffer[1]);  //0400
				return (buffer[0] + ((uint16_t)buffer[1]<<8));
			}			
		}
		return 0xFFFF;  //error or no tag
	}

	uint8_t X_RF14443A_AntiCL1(uint8_t *CardNo)
	{
		uint8_t buffer[5]={0};
		uint8_t i, m_crc;
		int16_t recv_len;
		uint8_t buf[2],Par[2];

		buf[0] = 0x93;
		buf[1] = 0x20;
		for(i=0; i<2; i++)
			Par[i] = oddparity(buf[i]);

		RF14443A_Reader_SendData(buf, Par, 1, 2, 0);
		recv_len = RF14443A_Reader_RecvData(buffer, 9, 0, 18);

		if(recv_len == 5){
			CardNo[0] = buffer[0];
			CardNo[1] = buffer[1];
			CardNo[2] = buffer[2];
			CardNo[3] = buffer[3];
			CardNo[4] = buffer[4];

			m_crc = CardNo[0] ^ CardNo[1] ^ CardNo[2] ^ CardNo[3];

			if(m_crc != CardNo[4]){
				return 2;
			}
			else{
				printf("ANTI-UID-0: %02x %02x %02x %02x %02x \n",buffer[0],buffer[1],buffer[2],buffer[3],buffer[4]);
				return 0;
			}
		}
		return 1;	
	}

	uint8_t X_RF14443A_AntiCL2(uint8_t *CardNo)
	{
		uint8_t buffer[5]={0};
		uint8_t i, m_crc;
		int16_t recv_len;
		uint8_t buf[2],Par[2];

		buf[0] = 0x95;
		buf[1] = 0x20;
		for(i=0; i<2; i++)
			Par[i] = oddparity(buf[i]);

		RF14443A_Reader_SendData(buf, Par, 1, 2, 0);
		recv_len = RF14443A_Reader_RecvData(buffer, 9, 0, 18);

		if(recv_len == 5){
			CardNo[5] = buffer[0];
			CardNo[6] = buffer[1];
			CardNo[7] = buffer[2];
			CardNo[8] = buffer[3];
			CardNo[9] = buffer[4];

			m_crc = CardNo[5] ^ CardNo[6] ^ CardNo[7] ^ CardNo[8];

			if(m_crc != CardNo[9]){
				return 2;
			}
			else{
				printf("ANTI-UID-1: %02x %02x %02x %02x %02x \n",buffer[0],buffer[1],buffer[2],buffer[3],buffer[4]);
				return 0;
			}
		}
		return 1;	
	}

	uint8_t X_RF14443A_SelCL1(uint8_t *CardNo)
	{
		uint8_t buffer[3]={0};
		uint8_t i;
		int16_t recv_len;
		uint16_t crc;

		uint8_t buf[9], Par[9];

		buf[0] = 0x93;
		buf[1] = 0x70;
		memcpy(buf + 2, CardNo, 5);

		AppendCrcA(buf, 7);

		for(i=0; i<9; i++)
			Par[i] = oddparity(buf[i]);

		RF14443A_Reader_SendData(buf, Par, 1, 9, 0);
		recv_len = RF14443A_Reader_RecvData(buffer, 9, 0, 18);

		if(recv_len == 3){
			printf("SEL-SAK-CL1: %02x \n", buffer[0]);
			return buffer[0];
		}

		return 0xFF;
	}

	uint8_t X_RF14443A_SelCL2(uint8_t *CardNo)
	{
		uint8_t buffer[3]={0};
		uint8_t i;
		int16_t recv_len;
		uint16_t crc;

		uint8_t buf[9], Par[9];

		buf[0] = 0x95;
		buf[1] = 0x70;
		memcpy(buf + 2, CardNo + 5, 5);

		AppendCrcA(buf, 7);

		for(i=0; i<9; i++)
			Par[i] = oddparity(buf[i]);

		RF14443A_Reader_SendData(buf, Par, 1, 9, 0);
		recv_len = RF14443A_Reader_RecvData(buffer, 9, 0, 18);

		if(recv_len == 3){
			printf("SEL-SAK-CL2: %02x \n", buffer[0]);
			return buffer[0];
		}

		return 0xFF;
	}

	uint8_t X_RF14443A_Halt()
	{
		uint8_t buffer[5]={0};
		uint8_t i, crc;
		int16_t recv_len;

		uint8_t buf[5], Par[5];

		buf[0] = 0x50;
		buf[1] = 0x00;

		AppendCrcA(buf, 2);

		for(i=0; i<4; i++)
		Par[i] = oddparity(buf[i]);

		RF14443A_Reader_SendData(buf, Par, 1, 4, 0);
		recv_len = RF14443A_Reader_RecvData(buffer, 9, 0, 18);

		return 0;
	}

	uint8_t X_RF14443A_GetUid(uint8_t *CardNo)
	{
		uint16_t atqa;
		
		atqa = X_RF14443A_Reqa();

		if (atqa == 0xFFFF) return 2;

		if ((atqa&0x00C0) == 0x40){  //7B
			if (X_RF14443A_AntiCL1(CardNo)) return 3;
			if (X_RF14443A_SelCL1(CardNo)==0xFF) return 4;
			if (X_RF14443A_AntiCL2(CardNo)) return 5;
			if (X_RF14443A_SelCL2(CardNo)==0xFF) return 6;
			//X_RF14443A_Halt();
			return 0;
		}
		else if ((atqa&0x00C0) == 0x00) {  //4B
			if (X_RF14443A_AntiCL1(CardNo)) return 7;
			if (X_RF14443A_SelCL1(CardNo)==0xFF) return 8;
			//X_RF14443A_Halt();
			return 0;
		}
		else return 1;
	} 
#endif

#define ISO14A_TAG
#ifdef ISO14A_TAG
extern uint8_t u8TagRecvCmd[];

int __not_in_flash_func(X_ISO14A_Tag_Emul)(uint16_t len)
{
	//call ntag or mifare emulation function according to the received command in u8TagRecvCmd
	Ntag_Emul(len);
	return 0;
}

#endif
/////////////////////////////////////////////////////////////////
