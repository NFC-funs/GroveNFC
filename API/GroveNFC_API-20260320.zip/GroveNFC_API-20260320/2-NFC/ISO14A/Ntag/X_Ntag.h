#ifndef     __X_NTAG_H__
#define     __X_NTAG_H__

//#define NTAG_DATA_FROM_CONST  //const uint8_t Ntag215_Data[], else from flash

int __not_in_flash_func(Ntag_Emul)(uint16_t len);

uint8_t Ntag215_write(uint8_t block, uint8_t *data);
int16_t Ntag215_read(uint8_t block, uint8_t *data);

#endif