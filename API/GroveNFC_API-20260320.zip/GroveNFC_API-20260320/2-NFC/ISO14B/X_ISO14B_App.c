#include <stdio.h>
#include <string.h>

#include "libNFC/X_Core0.h"

#include "libNFC/ISO14B/X_14443B_HW.h"

#include "X_ISO14B_App.h"

bool u8ISO14BTagEnable;

//////////////////////////////////////////////////////////////////////////////
#define ISO14B_READER
#ifdef ISO14B_READER

	int16_t X_RF14443B_reqb()
	{
		uint8_t u8ArrayReqb[5] = {0x05,0x00,0x00,0x00,0x00};//71-FF
		//uint8_t u8ArrayReqb[5] = {0x05,0x00,0x08,0x00,0x00};//WUPB
		uint16_t i, crc;
		int16_t len;
		uint8_t buf[32];

		AppendCrcB(u8ArrayReqb, 3);

		printf("reqb: %02x %02x %02x %02x %02x\n", u8ArrayReqb[0], u8ArrayReqb[1], u8ArrayReqb[2], u8ArrayReqb[3], u8ArrayReqb[4]);
		RF14443B_Reader_SendData(u8ArrayReqb, 5, 6);

		//recv deata
		len = RF14443B_Reader_RecvData(buf, 0);
		printf("China ID recv len: %d\n",len);
		if (len > 2){
			printf("reqb resp: ");
			for (i=0;i<len;i++){
				printf(" %02x",buf[i]);
			}
			printf("\n");
			if (HasValidCrcB(buf, len)){
				printf("crc ok..\n");
				return 0;
			}
			else return -1;
		}
		
		return -3;
	}

	int16_t X_RF14443B_attrib()
	{
		uint8_t u8ArrayAttrib[11] = {0x1D,0x00,0x00,0x00,0x00,0x00,0x08,0x01,0x08,0x00,0x00};//F3-10
		uint16_t i, crc;
		int16_t len;
		uint8_t buf[32];

		AppendCrcB(u8ArrayAttrib, 9);

		printf("attrib: %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x\n", \
		u8ArrayAttrib[0], u8ArrayAttrib[1], u8ArrayAttrib[2], u8ArrayAttrib[3], u8ArrayAttrib[4], u8ArrayAttrib[5],\
		u8ArrayAttrib[6], u8ArrayAttrib[7], u8ArrayAttrib[8], u8ArrayAttrib[9], u8ArrayAttrib[10]);
		RF14443B_Reader_SendData(u8ArrayAttrib, 11, 6);

		//recv deata
		len = RF14443B_Reader_RecvData(buf, 2);
		printf("China ID recv len: %d\n",len);
		if (len > 2){
			printf("attrib resp: ");
			for (i=0;i<len;i++){
				printf(" %02x",buf[i]);
			}
			printf("\n");
			if (HasValidCrcB(buf, len)){
				printf("crc ok..\n");
				return 0;
			}
			else return -1;
		}

		return -3;
	}

	int16_t X_RF14443B_getuid()
	{
		uint8_t u8ArrayGetuid[7] = {0x00,0x36,0x00,0x00,0x08,0x00,0x00};//57-44
		uint16_t i, crc;
		int16_t len;
		uint8_t buf[32];

		AppendCrcB(u8ArrayGetuid, 5);

		printf("Getuid: %02x %02x %02x %02x %02x %02x %02x\n", \
		u8ArrayGetuid[0], u8ArrayGetuid[1], u8ArrayGetuid[2], u8ArrayGetuid[3], u8ArrayGetuid[4], u8ArrayGetuid[5], u8ArrayGetuid[6]);
		RF14443B_Reader_SendData(u8ArrayGetuid, 7, 6);

		//recv deata
		len = RF14443B_Reader_RecvData(buf, 2);
		printf("China ID recv len: %d\n",len);
		if (len > 2){
			printf("Getuid resp: ");
			for (i=0;i<len;i++){
				printf(" %02x",buf[i]);
			}
			printf("\n");
			if (HasValidCrcB(buf, len)){
				printf("crc ok..\n");
				return 0;
			}
			else return -1;
		}

	}

#endif
/////////////////////////////////////////////////////////////////

#define ISO14B_TAG
#ifdef ISO14B_TAG
extern uint8_t u8TagRecvCmd[];

int __not_in_flash_func(X_ISO14B_Tag_Emul)(uint16_t len)
{
	uint8_t resp[16];
	uint16_t i, crc;

	if (len==0){
		printf("recvlen= %d\n", len);
		return -1;	
	} 
	if (HasValidCrcB(u8TagRecvCmd, len) == 0){
		printf("crc err...\n");
		return -2;
	} 

	//demo for China ID
	if (u8TagRecvCmd[0] == 0x05)  //Reqb
	{
		resp[0] = 0x50;
		resp[1] = 0x00;
		resp[2] = 0x00;
		resp[3] = 0x00;
		resp[4] = 0x00;
		resp[5] = 0xD1;
		resp[6] = 0x03;
		resp[7] = 0x00;
		resp[8] = 0x81;
		resp[9] = 0x00;
		resp[10] = 0x70;
		resp[11] = 0xC0;

		AppendCrcB(resp, 12);

		X_14443B_Tag_SendData(resp, 14, 256, 200, 1);
	}
	if (u8TagRecvCmd[0] == 0x1D)  //Attrib
	{
		resp[0] = 0x08;

		AppendCrcB(resp, 1);

		X_14443B_Tag_SendData(resp, 3, 256, 200, 1);
	}
	if (u8TagRecvCmd[0] == 0x00)  //Getuid
	{
		resp[0] = 0x10;
		resp[1] = 0x80;

		resp[2] = 0xC0;
		resp[3] = 0x09;
		resp[4] = 0x3A;
		resp[5] = 0x5D;
		resp[6] = 0x25;
		resp[7] = 0x79;

		resp[8] = 0x90;
		resp[9] = 0x00;

		AppendCrcB(resp, 10);

		X_14443B_Tag_SendData(resp, 12, 256, 200, 1);
	}	
}


#endif