#ifndef     __X_ISO14B_APP_H__
#define     __X_ISO14B_APP_H__


int16_t X_RF14443B_reqb();
int16_t X_RF14443B_attrib();
int16_t X_RF14443B_getuid();

#endif
