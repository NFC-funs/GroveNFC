#ifndef     __X_FELICA_APP_H__
#define     __X_FELICA_APP_H__

int16_t X_Felica_wup();  //
int16_t X_Felica_req();

#endif
