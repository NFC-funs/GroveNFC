#include <stdio.h>
#include <string.h>

#include "libNFC/X_Core0.h"

#include "libNFC/Felica/X_FELICA_HW.h"

#include "X_FELICA_App.h"

bool u8FelicaTagEnable;
//////////////////////////////////////////////////////////////////////////////

#define FELICA_READER
#ifdef FELICA_READER
	//////////////////////////////////////////////////////////////
	int16_t X_Felica_wup()
	{
		/////////////////////////LEN                 AFI             CRCH CRCL
		uint8_t u8ArrayWup[9] = {7, 0xD6, 0x04, 0xAA,0x00,0x00,0x00, 0x00,0x00};//

		uint16_t i, crc;
		int16_t len;

		AppendCrcF(u8ArrayWup, 7);

		printf("felica wup: %d, %02x %02x %02x %02x %02x %02x %02x %02x\n", \
		u8ArrayWup[0], u8ArrayWup[1], u8ArrayWup[2], u8ArrayWup[3], u8ArrayWup[4], u8ArrayWup[5], u8ArrayWup[6], u8ArrayWup[7], u8ArrayWup[8]);
		FELICA_Reader_SendData(u8ArrayWup, 9, 0);
		printf("felica wup1: %d, %02x %02x %02x %02x %02x %02x %02x %02x\n", \
		u8ArrayWup[0], u8ArrayWup[1], u8ArrayWup[2], u8ArrayWup[3], u8ArrayWup[4], u8ArrayWup[5], u8ArrayWup[6], u8ArrayWup[7], u8ArrayWup[8]);
		
		return -3;
	}
	int16_t X_Felica_req()
	{
		/////////////////////////LEN                          CRCH CRCL
		uint8_t u8ArrayReq[8] = {6, 0x00,0xFF,0xFF,0x00,0x00, 0x00,0x00};//AAFF?
		uint8_t u8ReqRsp[32];

		uint16_t i, crc;
		int16_t len;

		AppendCrcF(u8ArrayReq, 6);

		printf("Felica req: %d, %02x %02x %02x %02x %02x %02x %02x\n", \
		u8ArrayReq[0], u8ArrayReq[1], u8ArrayReq[2], u8ArrayReq[3], u8ArrayReq[4], u8ArrayReq[5], u8ArrayReq[6], u8ArrayReq[7]);
		FELICA_Reader_SendData(u8ArrayReq, 8, 0);
		len = FELICA_Reader_RecvData(u8ReqRsp, 0, 0);

		printf("Felica recv len: %d\n",len);

		if (len > 2){
			//remove sync code B2 4D
			memmove(u8ReqRsp, u8ReqRsp + 2, len - 2);
			len = len-2;
			////////////////////////////////////////
			printf("felica req recv length: %d\n", len);
			for (i=0;i<len;i++){
				printf("%02x ", u8ReqRsp[i]);
			}
			printf("\n");
			if (HasValidCrcF(u8ReqRsp, len)){
				printf("crc ok\n");
			}
			else{
				printf("crc error\n");
			}				
		}
		
		return -3;
	}

#endif
/////////////////////////////////////////////////////////////////
