#include <stdio.h>
#include <string.h>

#include "libNFC/X_Core0.h"

#include "libNFC/ISO15/X_15693_HW.h"

#include "X_ISO15_App.h"

///////////////////////////////////////////////////////////////////////////////////////////////
// REQUEST FLAGS
#define ISO15_REQ_SUBCARRIER_SINGLE      0x00 // Tag should respond using one subcarrier (ASK)
#define ISO15_REQ_SUBCARRIER_TWO         0x01 // Tag should respond using two subcarriers (FSK)
#define ISO15_REQ_DATARATE_LOW           0x00 // Tag should respond using low data rate
#define ISO15_REQ_DATARATE_HIGH          0x02 // Tag should respond using high data rate
#define ISO15_REQ_NONINVENTORY           0x00
#define ISO15_REQ_INVENTORY              0x04 // This is an inventory request - see inventory flags
#define ISO15_REQ_PROTOCOL_NONEXT        0x00
#define ISO15_REQ_PROTOCOL_EXT           0x08 // RFU

// REQUEST FLAGS when INVENTORY is not set
#define ISO15_REQ_SELECT                 0x10 // only selected cards response
#define ISO15_REQ_ADDRESS                0x20 // this req contains an address
#define ISO15_REQ_OPTION                 0x40 // Command specific option selector

//REQUEST FLAGS when INVENTORY is set
#define ISO15_REQINV_AFI                 0x10 // AFI Field is present
#define ISO15_REQINV_SLOT1               0x20 // 1 Slot
#define ISO15_REQINV_SLOT16              0x00 // 16 Slots
#define ISO15_REQINV_OPTION              0x40 // Command specific option selector

//RESPONSE FLAGS
#define ISO15_RES_ERROR                  0x01
#define ISO15_RES_EXT                    0x08 // Protocol Extension

// RESPONSE ERROR CODES
#define ISO15_NOERROR                    0x00
#define ISO15_ERROR_CMD_NOT_SUP          0x01 // Command not supported
#define ISO15_ERROR_CMD_NOT_REC          0x02 // Command not recognized (eg. parameter error)
#define ISO15_ERROR_CMD_OPTION           0x03 // Command option not supported
#define ISO15_ERROR_GENERIC              0x0F // No additional Info about this error
#define ISO15_ERROR_BLOCK_UNAVAILABLE    0x10
#define ISO15_ERROR_BLOCK_LOCKED_ALREADY 0x11 // cannot lock again
#define ISO15_ERROR_BLOCK_LOCKED         0x12 // cannot be changed
#define ISO15_ERROR_BLOCK_WRITE          0x13 // Writing was unsuccessful
#define ISO15_ERROR_BLOCL_WRITELOCK      0x14 // Locking was unsuccessful
///////////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////////////
//First byte is 26
#define ISO15693_INVENTORY     0x01
#define ISO15693_STAYQUIET     0x02
//First byte is 02
#define ISO15693_READBLOCK                   0x20
#define ISO15693_WRITEBLOCK                  0x21
#define ISO15693_LOCKBLOCK                   0x22
#define ISO15693_READ_MULTI_BLOCK            0x23
#define ISO15693_WRITE_MULTI_BLOCK           0x24
#define ISO15693_SELECT                      0x25
#define ISO15693_RESET_TO_READY              0x26
#define ISO15693_WRITE_AFI                   0x27
#define ISO15693_LOCK_AFI                    0x28
#define ISO15693_WRITE_DSFID                 0x29
#define ISO15693_LOCK_DSFID                  0x2A
#define ISO15693_GET_SYSTEM_INFO             0x2B
#define ISO15693_READ_MULTI_SECSTATUS        0x2C
// NXP/Philips custom commands
#define ISO15693_INVENTORY_READ              0xA0
#define ISO15693_FAST_INVENTORY_READ         0xA1
#define ISO15693_SET_EAS                     0xA2
#define ISO15693_RESET_EAS                   0xA3
#define ISO15693_LOCK_EAS                    0xA4
#define ISO15693_EAS_ALARM                   0xA5
#define ISO15693_PASSWORD_PROTECT_EAS        0xA6
#define ISO15693_WRITE_EAS_ID                0xA7
#define ISO15693_READ_EPC                    0xA8
#define ISO15693_GET_NXP_SYSTEM_INFO         0xAB
#define ISO15693_INVENTORY_PAGE_READ         0xB0
#define ISO15693_FAST_INVENTORY_PAGE_READ    0xB1
#define ISO15693_GET_RANDOM_NUMBER           0xB2
#define ISO15693_SET_PASSWORD                0xB3
#define ISO15693_WRITE_PASSWORD              0xB4
#define ISO15693_LOCK_PASSWORD               0xB5
#define ISO15693_PROTECT_PAGE                0xB6
#define ISO15693_LOCK_PAGE_PROTECTION        0xB7
#define ISO15693_GET_MULTI_BLOCK_PROTECTION  0xB8
#define ISO15693_DESTROY                     0xB9
#define ISO15693_ENABLE_PRIVACY              0xBA
#define ISO15693_64BIT_PASSWORD_PROTECTION   0xBB
#define ISO15693_STAYQUIET_PERSISTENT        0xBC
#define ISO15693_READ_SIGNATURE              0xBD
////////////////////////////////////////////////////////////////////////////////////////////////

#define CHECK_VALUE  0x0F47//0xF0B8
//////////////////////////////////////////////////////////////////////////////
#define ISO15_READER
#ifdef ISO15_READER

	int16_t X_15693_getuid(uint8_t *uid15693, uint8_t mode)
	{
		uint8_t u8ArrayGetID[5] = {0x26,ISO15693_INVENTORY,0x00,0x00,0x00};//read id
		uint8_t u8RecvData[32];

		uint8_t  i;
		uint16_t crc;
		int16_t recv_len;

		if (mode&0x01) u8ArrayGetID[0]=0x27;  //FSK

		AppendCrcV(u8ArrayGetID, 3);

		if (mode&0x01)printf("15693FSK read uid: %02x %02x %02x %02x %02x\n", u8ArrayGetID[0], u8ArrayGetID[1], u8ArrayGetID[2], u8ArrayGetID[3], u8ArrayGetID[4]);
		else printf("15693ASK read uid: %02x %02x %02x %02x %02x\n", u8ArrayGetID[0], u8ArrayGetID[1], u8ArrayGetID[2], u8ArrayGetID[3], u8ArrayGetID[4]);

		RF15693_Reader_SendData(u8ArrayGetID, 5, mode);

		{
			recv_len = RF15693_Reader_RecvData(u8RecvData, mode);

			printf("15693 recv len: %d\n",recv_len);

			if (recv_len > 0)
			{
				for (i=0;i<recv_len;i++){
					printf("%02x ", u8RecvData[i]);
				}
				if (HasValidCrcV(u8RecvData, recv_len)){	 //u815693IDArray[0]=0xE0 PS-20230318
					uid15693[0] = u8RecvData[9];
					uid15693[1] = u8RecvData[8];
					uid15693[2] = u8RecvData[7];
					uid15693[3] = u8RecvData[6];
					uid15693[4] = u8RecvData[5];
					uid15693[5] = u8RecvData[4];
					uid15693[6] = u8RecvData[3];
					uid15693[7] = u8RecvData[2];
					printf("crc ok\n");	
				} 
				else printf("crc error\n");
			}			
		}

		return recv_len;
	}

	int16_t X_15693_readsingleblock(uint8_t *uid15693, uint8_t block, uint8_t *data15693, uint8_t mode)
	{
		uint8_t u8ArrayRead[13] = {0x22,ISO15693_READBLOCK,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};//block-[10]
		uint8_t u8RecvData[32];

		uint8_t  i;
		uint16_t crc;
		int16_t recv_len;

		for (i=0;i<8;i++) u8ArrayRead[i+2] = uid15693[7-i]; //u815693IDArray[0]=0xE0 PS-20230318
		u8ArrayRead[10] = block;

		AppendCrcV(u8ArrayRead, 11);

		RF15693_Reader_SendData(u8ArrayRead, 13, mode);
		recv_len = RF15693_Reader_RecvData(u8RecvData, mode);

		printf("15693 recv len: %d\n",recv_len);

		if (recv_len > 0)
		{
			for (i=0;i<recv_len;i++){
				printf("%02x ", u8RecvData[i]);
			}
			if (HasValidCrcV(u8RecvData, recv_len)) printf("crc ok\n");
			else printf("crc error\n");
		}

		return recv_len;
	}

	int16_t X_15693_writesingleblock(uint8_t *uid15693, uint8_t block, uint8_t *data15693, uint8_t mode)
	{
		uint8_t u8ArrayWriteSingleBlock[17] = { 0x62,ISO15693_WRITEBLOCK,  //62--Ti 42--NXP
												0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,  //UID
												0x08,  //Block Address
												0x01,0x02,0x03,0x04,  //Data
												0x00,0x00};//
		uint8_t u8RecvData[32];

		uint8_t  i;
		uint16_t j;
		uint16_t crc;
		int16_t recv_len;

		for (i=0;i<8;i++) u8ArrayWriteSingleBlock[i+2] = uid15693[7-i]; //u815693IDArray[0]=0xE0 PS-20230318

		u8ArrayWriteSingleBlock[10] = block;

		u8ArrayWriteSingleBlock[11] = data15693[0];
		u8ArrayWriteSingleBlock[12] = data15693[1];
		u8ArrayWriteSingleBlock[13] = data15693[2];
		u8ArrayWriteSingleBlock[14] = data15693[3];

		AppendCrcV(u8ArrayWriteSingleBlock, 15);

		RF15693_Reader_SendData(u8ArrayWriteSingleBlock, 17, mode);

		//wait >20ms to send EOF, unit 9.44us
		RF15693_Carrier_On_Delay(2560);
		RF15693_Reader_SendEOF();  //Note: it delay 4*9.44us
		
		recv_len = RF15693_Reader_RecvData(u8RecvData, mode);

		printf("15693 recv len: %d\n",recv_len);

		if (recv_len > 0)
		{
			for (i=0;i<recv_len;i++){
				printf("%02x ", u8RecvData[i]);
			}
			if (HasValidCrcV(u8RecvData, recv_len)) printf("crc ok\n");
			else printf("crc error\n");
		}

		return recv_len;
	}

	int16_t X_15693_readmultiblock(uint8_t *uid15693, uint8_t block, uint8_t number, uint8_t *data15693, uint8_t mode)
	{
		uint8_t u8ArrayRead[14] = {0x22,ISO15693_READ_MULTI_BLOCK,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};//read block 10
		uint8_t u8RecvData[32];

		uint8_t  i;
		uint16_t crc;
		int16_t recv_len;

		for (i=0;i<8;i++) u8ArrayRead[i+2] = uid15693[7-i]; //u815693IDArray[0]=0xE0 PS-20230318
		u8ArrayRead[10] = block;
		u8ArrayRead[11] = number;

		AppendCrcV(u8ArrayRead, 12);

		RF15693_Reader_SendData(u8ArrayRead, 14, mode);
		recv_len = RF15693_Reader_RecvData(u8RecvData, mode);

		printf("15693 recv len: %d\n",recv_len);

		if (recv_len > 0)
		{
			for (i=0;i<recv_len;i++){
				printf("%02x ", u8RecvData[i]);
			}
			if (HasValidCrcV(u8RecvData, recv_len)) printf("crc ok\n");
			else printf("crc error\n");
		}

		return recv_len;
	}

#endif
/////////////////////////////////////////////////////////////////


#define RF15693_TAG
#ifdef RF15693_TAG

	#define ISO15TAG_DATA_FROM_CONST
	//0E-07-00
	const uint8_t ISO15_Sim_Data[] = {
		//UID
		0xC1, 0xC6, 0x02, 0xB9,
		0x50, 0x00, 0x07, 0xE0,
		//Resv-EAS-AFI-DSFID
		0x00, 0x00, 0x00, 0x00,
		//write protect
		0x00, 0x00, 0x00, 0x00,
		//data 0-63(3F)
		0x00, 0x00, 0x00, 0x00,
		0x01, 0x01, 0x01, 0x01,
		0x02, 0x02, 0x02, 0x02,
		0x03, 0x03, 0x03, 0x03,
		0x04, 0x04, 0x04, 0x04,
		0x05, 0x05, 0x05, 0x05,
		0x06, 0x06, 0x06, 0x06,
		0x07, 0x07, 0x07, 0x07,
		0x08, 0x08, 0x08, 0x08,
		0x09, 0x09, 0x09, 0x09,
		0x0A, 0x0A, 0x0A, 0x0A,
		0x0B, 0x0B, 0x0B, 0x0B,
		0x0C, 0x0C, 0x0C, 0x0C,
		0x0D, 0x0D, 0x0D, 0x0D,
		0x0E, 0x0E, 0x0E, 0x0E,
		0x0F, 0x0F, 0x0F, 0x0F,
		0x10, 0x10, 0x10, 0x10,
		0x11, 0x11, 0x11, 0x11,
		0x12, 0x12, 0x12, 0x12,
		0x13, 0x13, 0x13, 0x13,
		0x14, 0x14, 0x14, 0x14,
		0x15, 0x15, 0x15, 0x15,
		0x16, 0x16, 0x16, 0x16,
		0x17, 0x17, 0x17, 0x17,
		0x18, 0x18, 0x18, 0x18,
		0x19, 0x19, 0x19, 0x19,
		0x1A, 0x1A, 0x1A, 0x1A,
		0x1B, 0x1B, 0x1B, 0x1B,
		0x1C, 0x1C, 0x1C, 0x1C,
		0x1D, 0x1D, 0x1D, 0x1D,
		0x1E, 0x1E, 0x1E, 0x1E,
		0x1F, 0x1F, 0x1F, 0x1F,
		0x20, 0x20, 0x20, 0x20,
		0x21, 0x21, 0x21, 0x21,
		0x22, 0x22, 0x22, 0x22,
		0x23, 0x23, 0x23, 0x23,
		0x24, 0x24, 0x24, 0x24,
		0x25, 0x25, 0x25, 0x25,
		0x26, 0x26, 0x26, 0x26,
		0x27, 0x27, 0x27, 0x27,
		0x28, 0x28, 0x28, 0x28,
		0x29, 0x29, 0x29, 0x29,
		0x2A, 0x2A, 0x2A, 0x2A,
		0x2B, 0x2B, 0x2B, 0x2B,
		0x2C, 0x2C, 0x2C, 0x2C,
		0x2D, 0x2D, 0x2D, 0x2D,
		0x2E, 0x2E, 0x2E, 0x2E,
		0x2F, 0x2F, 0x2F, 0x2F,
		0x30, 0x30, 0x30, 0x30,
		0x31, 0x31, 0x31, 0x31,
		0x32, 0x32, 0x32, 0x32,
		0x33, 0x33, 0x33, 0x33,
		0x34, 0x34, 0x34, 0x34,
		0x35, 0x35, 0x35, 0x35,
		0x36, 0x36, 0x36, 0x36,
		0x37, 0x37, 0x37, 0x37,
		0x38, 0x38, 0x38, 0x38,
		0x39, 0x39, 0x39, 0x39,
		0x3A, 0x3A, 0x3A, 0x3A,
		0x3B, 0x3B, 0x3B, 0x3B,
		0x3C, 0x3C, 0x3C, 0x3C,
		0x3D, 0x3D, 0x3D, 0x3D,
		0x3E, 0x3E, 0x3E, 0x3E,
		0x3F, 0x3F, 0x3F, 0x3F
		};

	extern uint8_t u8TagRecvCmd[];
	extern uint8_t u8TagSimData[];

	//extern uint8_t u8Card15693BlockCount;  //
	uint8_t u8Card15693BlockCount = 0x3F;  //
	uint8_t block_size = 4;	 //

	int __not_in_flash_func(X_15693_Tag_Emul)(uint16_t len)
	{
		//printf("15693 Tag Emul: %d", len);
		uint16_t crc;
		uint8_t resp[256];
		uint16_t i,resplen;
		uint8_t address_offset, block_idx, block_count, security_offset, work_offset;

		if ( crc16_V(u8TagRecvCmd, len) == CHECK_VALUE )
		{
			switch(u8TagRecvCmd[1])
			{
				case ISO15693_INVENTORY:
					//if ( u8CmdVcd2Vicc[0] == (ISO15_REQ_INVENTORY|ISO15_REQ_DATARATE_HIGH|ISO15_REQINV_SLOT1) ) //0x26
					if ( (u8TagRecvCmd[0] & (ISO15_REQ_INVENTORY|ISO15_REQ_DATARATE_HIGH|ISO15_REQINV_SLOT1)) == 0x26)//0x26
					{
						resp[0] = 0; // No error, no protocol format extension
						resp[1] = 0; // DSFID (data storage format identifier).  0x00 = not supported
						#ifdef ISO15TAG_DATA_FROM_CONST
						memcpy(u8TagSimData, ISO15_Sim_Data, sizeof(ISO15_Sim_Data));
						#endif
						//64-bit UID--Ti--NXP
						resp[2] = u8TagSimData[0];//0xEE;//0x6A;//uid[7];
						resp[3] = u8TagSimData[1];//0xBC;//0xC4;//uid[6];
						resp[4] = u8TagSimData[2];//0xCE;//0x02;//uid[5];
						resp[5] = u8TagSimData[3];//0x20;//0xB9;//uid[4];
						resp[6] = u8TagSimData[4];//0x00;//0x50;//uid[3];
						resp[7] = u8TagSimData[5];//0x00;//0x01;//uid[2];
						resp[8] = u8TagSimData[6];//0x07;//0x04;//uid[1];
						resp[9] = u8TagSimData[7];//0xE0;//0xE0;//uid[0];

						AppendCrcV(resp, 10);
						X_15693_Tag_SendData(resp, 12, u8TagRecvCmd[0]&0x01);
					}
					break;

				case ISO15693_GET_SYSTEM_INFO:
					{
						resp[0] = 0;    // Response flags.
						resp[1] = 0x0F; // Information flags (0x0F - DSFID, AFI, Mem size, IC)

						//64-bit UID--Ti--NXP
						resp[2] = u8TagSimData[0];//0xEE;//0x6A;//uid[7];
						resp[3] = u8TagSimData[1];//0xBC;//0xC4;//uid[6];
						resp[4] = u8TagSimData[2];//0xCE;//0x02;//uid[5];
						resp[5] = u8TagSimData[3];//0x20;//0xB9;//uid[4];
						resp[6] = u8TagSimData[4];//0x00;//0x50;//uid[3];
						resp[7] = u8TagSimData[5];//0x00;//0x01;//uid[2];
						resp[8] = u8TagSimData[6];//0x07;//0x04;//uid[1];
						resp[9] = u8TagSimData[7];//0xE0;//0xE0;//uid[0];

						resp[10] = u8TagSimData[11];//0;    // DSFID
						resp[11] = u8TagSimData[10];//0;    // AFI

						resp[12] = u8Card15693BlockCount;  //0x3F;  // Block count, ic type, PS-20250203

						resp[13] = block_size - 1; // Block size.
						resp[14] = 0x01; // IC reference.

						AppendCrcV(resp, 15);

						X_15693_Tag_SendData(resp, 17, u8TagRecvCmd[0]&0x01);
					}
					break;

				case ISO15693_READBLOCK:
				case ISO15693_READ_MULTI_BLOCK:
					{
						address_offset = 0;

						if (u8TagRecvCmd[0] & ISO15_REQ_ADDRESS){
							address_offset = 8;
						}

						block_idx = u8TagRecvCmd[2 + address_offset];
						block_count = 1;

						if (u8TagRecvCmd[1] == ISO15693_READ_MULTI_BLOCK) {
							block_count = u8TagRecvCmd[3 + address_offset] + 1;
						}

						// Build READ_(MULTI_)BLOCK response
						resplen = 1 + block_size * block_count;
						security_offset = 0;

						if (u8TagRecvCmd[0] & ISO15_REQ_OPTION) {
							resplen += block_count;
							security_offset = 1;
						}
						//overstep the boundary, PS-20241030
						if ( (block_idx + block_count) >= (u8Card15693BlockCount + 1 + 1) )  //first block_count = 1;
						{
							;
						}
						else
						{
							resp[0] = 0;    // Response flags
							for (i = 0; i < block_count; i++)
							{
								// where to put the data of the current block
								work_offset = 1 + i * (block_size + security_offset);

								if (u8TagRecvCmd[0] & ISO15_REQ_OPTION) {
									resp[work_offset] = 0;    // Security status
								}

								// Block data
								//if (block_size * (block_idx + i + 1) <= CARD_MEMORY_SIZE) {
								if ((block_idx + i) <= u8Card15693BlockCount) {
									//fill data
									memcpy(resp + work_offset + security_offset, u8TagSimData + 0x10 + block_size * (block_idx + i), block_size);  //tag data, PS-20241005
								}
								else {
									memset(resp + work_offset + security_offset, 3, block_size);
								}


							}
							AppendCrcV(resp, resplen);

							X_15693_Tag_SendData(resp, resplen+2, u8TagRecvCmd[0]&0x01);
						}
					}
					break;

				case ISO15693_WRITEBLOCK:
					{
						address_offset = 0;

						if (u8TagRecvCmd[0] & ISO15_REQ_ADDRESS){
							address_offset = 8;
						}

						block_idx = u8TagRecvCmd[2 + address_offset];

						u8TagSimData[0x10 + block_idx*block_size + 0] = u8TagRecvCmd[2 + address_offset + 1];
						u8TagSimData[0x10 + block_idx*block_size + 1] = u8TagRecvCmd[2 + address_offset + 2];
						u8TagSimData[0x10 + block_idx*block_size + 2] = u8TagRecvCmd[2 + address_offset + 3];
						u8TagSimData[0x10 + block_idx*block_size + 3] = u8TagRecvCmd[2 + address_offset + 4];

						if (address_offset == 0)  //u8CmdVcd2Vicc[0]==02 ,exclude UID
						{
							resp[0] = 0x00;
							AppendCrcV(resp, 1);

							X_15693_Tag_SendData(resp, 3, u8TagRecvCmd[0]&0x01);
						}
					}
					break;

				case ISO15693_READ_MULTI_SECSTATUS:
					{
						address_offset = 0;

						if (u8TagRecvCmd[0] & ISO15_REQ_ADDRESS){
							address_offset = 8;
						}

						block_idx = u8TagRecvCmd[2 + address_offset];
						block_count = u8TagRecvCmd[3 + address_offset];  //some reader is FF
						if (block_count >= (u8Card15693BlockCount - block_idx))
						{
							block_count = (u8Card15693BlockCount - block_idx) + 1;
						}

						resp[0] = 0;    // Response flags
						for (i = 0; i < block_count; i++){
							resp[1+i] = 0x00;
						}
						resplen = block_count + 1;

						AppendCrcV(resp, resplen);

						X_15693_Tag_SendData(resp, resplen+2, u8TagRecvCmd[0]&0x01);
					}
					break;

				default:
					break;
			}
		}//CRC OK		
	}

#endif