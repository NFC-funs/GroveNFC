#ifndef     __X_ISO15_APP_H__
#define     __X_ISO15_APP_H__

//#define ISO15TAG_DATA_FROM_CONST  //const uint8_t ISO15_Sim_Data[], else from flash

int16_t X_15693_getuid(uint8_t *uid15693, uint8_t mode);
int16_t X_15693_readsingleblock(uint8_t *uid15693, uint8_t block, uint8_t *data15693, uint8_t mode);
int16_t X_15693_writesingleblock(uint8_t *uid15693, uint8_t block, uint8_t *data15693, uint8_t mode);
int16_t X_15693_readmultiblock(uint8_t *uid15693, uint8_t block, uint8_t number, uint8_t *data15693, uint8_t mode);
int16_t X_15693_magicuid(uint8_t *uid15693, uint8_t mode);

#endif
