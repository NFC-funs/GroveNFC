#include <stdio.h>

#include "pico/stdlib.h"
#include "hardware/uart.h"
#include "hardware/adc.h" 

#include "libNFC/X_Core0.h"
#include "libNFC/Comm/X_Comm.h"

//#define TEST_14443A
//#define TEST_14443B
//#define TEST_FELICA
//#define TEST_15693ASK
//#define TEST_15693FSK

#ifdef TEST_14443A
    #include "libNFC/ISO14A/X_14443A_HW.h"
    #include "2-NFC/ISO14A/X_ISO14A_App.h"
    #include "2-NFC/ISO14A/Ntag/X_Ntag.h"
    uint8_t u814443AIDArray[10];//10-7B 5-4B
    uint8_t u8NtagDataTest[4] = {1, 2, 3, 4};
    uint8_t u8NtagDataRead[16];
#endif

#ifdef TEST_14443B
    #include "libNFC/ISO14B/X_14443B_HW.h"
    #include "2-NFC/ISO14B/X_ISO14B_App.h"  
#endif

#ifdef TEST_FELICA
    #include "libNFC/Felica/X_FELICA_HW.h"
    #include "2-NFC/Felica/X_FELICA_App.h"  
#endif

#if defined(TEST_15693ASK) || defined(TEST_15693FSK)
    #include "libNFC/ISO15/X_15693_HW.h"
    #include "2-NFC/ISO15/X_ISO15_App.h"
    uint8_t u815693IDArray[12];//FLAGS(1B) + DSFID(1B) + UID(8B) +CRC(2B)
    uint8_t u815693Data[32];
#endif

//#define TEST_NTAGEMUL
//#define TEST_15693EMUL
//#define TEST_CHINAIDEMUL

#ifdef TEST_NTAGEMUL
    #include "libNFC/ISO14A/X_14443A_HW.h"
    #include "2-NFC/ISO14A/X_ISO14A_App.h"
    #include "2-NFC/ISO14A/Ntag/X_Ntag.h"
#endif

#ifdef TEST_15693EMUL
    #include "libNFC/ISO15/X_15693_HW.h"
    #include "2-NFC/ISO15/X_ISO15_App.h"
#endif

#ifdef TEST_CHINAIDEMUL
    #include "libNFC/ISO14B/X_14443B_HW.h"
    #include "2-NFC/ISO14B/X_ISO14B_App.h"
#endif

int main()
{
    X_SystemInit();

    extern void stdio_uart_init_full (uart_inst_t *uart, uint baud_rate, int tx_pin, int rx_pin);
    stdio_uart_init_full(uart1, 921600, 4, 5);

    X_NFCInit();
    sleep_ms(10);
    X_NFCFiledOff();

    #ifdef TEST_NTAGEMUL
        X_NFCFiledOff();
        X_PIOCapture0filterInit();  //start emulator
    #endif

    #ifdef TEST_15693EMUL
        X_NFCFiledOff();
        X_PIOCapture15filterInit();  //start 15693 emulator
    #endif

    while (true) 
    {
        #ifdef TEST_14443A
            printf("14443A Reader Mode:\n");
            sleep_ms(1000);
            RF14443A_Carrier_On_Delay(2000);  //4.72ms
            X_PIOCapture1Init();
            if (0==X_RF14443A_GetUid(u814443AIDArray))
            {
                Ntag215_read(8, u8NtagDataRead);
                Ntag215_write(8, u8NtagDataTest);
            }
            X_PIOCapture1Deinit();
            X_NFCFiledOff();
        #endif

        #ifdef TEST_14443B
            printf("14443B Reader Mode:\n");
            sleep_ms(1000);
            X_NFCFiledOn();
            RF14443B_Carrier_On_Delay(2000); //18.8ms
            printf("China ID\n");
            X_PIOCapture14bInit();

                if (X_RF14443B_reqb() == 0){
                    if (X_RF14443B_attrib() == 0){
                        X_RF14443B_getuid();
                    }  
                }

            X_PIOCapture14bDeinit();
            X_NFCFiledOff();   
        #endif

        #ifdef TEST_FELICA
            printf("FELICA Reader Mode:\n");
            sleep_ms(1000);
            X_NFCFiledOn();
            RFFelica_Carrier_On_Delay(2000);  //4.72ms
            X_PIOFelica1Init();
            X_Felica_req();
            X_PIOFelica1Deinit();
            X_NFCFiledOff();
        #endif

        #ifdef TEST_15693ASK
            printf("15693 ASK Reader Mode:\n");
            sleep_ms(1000);
            X_NFCFiledOn();
            RF15693_Carrier_On_Delay(200); //1.88ms
            X_PIOCapture15Init();
            //X_15693_getuid(u815693IDArray, 0);
            if (X_15693_getuid(u815693IDArray, 0) == 12){
                X_15693_readsingleblock(u815693IDArray, 8, u815693Data, 0);
                X_15693_readmultiblock(u815693IDArray, 8, 3, u815693Data, 0);
                uint8_t test15693[4] = {1,3,5,7};
                X_15693_writesingleblock(u815693IDArray, 8, test15693, 0);
            }
            X_PIOCapture15Deinit();
            X_NFCFiledOff();
        #endif

        #ifdef TEST_15693FSK
            printf("15693 FSK Reader Mode:\n");
            sleep_ms(1000);
            X_NFCFiledOn();
            RF15693_Carrier_On_Delay(200); //1.88ms
            X_PIOCapture15Init();
            X_15693_getuid(u815693IDArray, 1);
            X_PIOCapture15Deinit();
            X_NFCFiledOff();
        #endif

        #ifdef TEST_CHINAIDEMUL
            uint16_t onecounter = 0, zerocounter = 0;
            uint32_t testcounter = 0;

            {
                sleep_ms(1);
                if (gpio_get(IOI_14443AREADER_REQ))
                {
                    onecounter ++ ;
                    zerocounter = 0;
                    if (onecounter == 10)
                    {
                        onecounter = 0;
                        printf("IOI_READER_REQ Rising ...\n");
                        uint16_t adcvalue = 0;
                        for (uint8_t i=0;i<14;i++) adcvalue += adc_read();
                        X_NFCSetRef(adcvalue/8);
                        X_PIOCapture14bfilterInit();
                    }
                    if (onecounter > 10) onecounter = 11;
                }
                else 
                {
                    zerocounter ++ ;
                    onecounter = 0;
                    if (zerocounter == 10)
                    {
                        X_NFCSetRef(2048);
                        X_PIOCapture14bfilterDeinit();
                    }
                    if (zerocounter > 10) zerocounter = 11;
                }
                
            }
        #endif
    }

    return 0;
}
