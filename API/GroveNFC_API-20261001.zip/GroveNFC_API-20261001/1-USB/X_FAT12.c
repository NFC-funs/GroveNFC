/*
 * This sample formats Pico's onboard flash memory with FAT12 to enable the
 * following operations:
 *
 * - Read/write files from/to host PC with USB Mass Storage class
 * - Read/write files from inside Pico with FatFs library
 *
 * Pressing the BOOTSEL button on Pico reads a file and releasing it updates the
 * file. Also, holding the button down for about 10 seconds initializes the file
 * system.
 */
#include <stdlib.h>
#include <string.h>
#include <pico/stdlib.h>
#include <tusb.h>
//#include <ff.h>

#include "1-USB/flash.h"
#include "X_FAT12.h"

static FATFS filesystem;

/*
 * `fatfs_flash_driver.c:disk_initialize()` is called to test the file
 * system and initialize it if necessary.
 */
void test_and_init_filesystem(void) {
    f_mount(&filesystem, "/", 1);
    //f_unmount("/");
}

#if 0
/**
 * @brief 从指定文件的第 offset 字节开始读取 len 字节数据
 * @param path  文件路径 (例如 "0:/EMULDATA.CSV")
 * @param offset 起始偏移量 (字节)
 * @param len    要读取的字节数
 * @param buffer 存放读取数据的缓冲区 (必须至少 len 字节)
 * @return FRESULT 返回 FatFs 操作结果 (FR_OK 表示成功)
 */
FRESULT read_file_part(const char* path, uint32_t offset, uint16_t len, void* buffer) {
    FIL file;          // 文件对象
    FRESULT res;
    UINT bytes_read;

    // 0. 加载文件
    /*res = f_mount(&filesystem, "/", 1);
    if (res != FR_OK) {
        printf("f_mount fail rc=%d\n", res);
        return res;
    }*/

    // 1. 以只读方式打开文件
    res = f_open(&file, path, FA_READ);
    if (res != FR_OK) {
        return res;   // 打开失败
    }

    // 2. 检查文件大小是否足够
    DWORD file_size = f_size(&file);
    if (offset + len > file_size) {
        f_close(&file);
        return FR_INVALID_PARAMETER;   // 要读取的范围超出文件末尾
    }

    // 3. 移动文件指针到目标偏移量
    res = f_lseek(&file, offset);
    if (res != FR_OK) {
        f_close(&file);
        return res;
    }

    // 4. 读取 len 字节数据到 buffer
    res = f_read(&file, buffer, len, &bytes_read);
    if (res != FR_OK) {
        f_close(&file);
        return res;
    }

    // 5. 检查是否真的读到了 len 字节 (可能因为文件结束等原因少读了)
    if (bytes_read != len) {
        f_close(&file);
        return FR_DISK_ERR;   // 实际读取字节数不符预期
    }

    // 6. 关闭文件
    f_close(&file);
    return FR_OK;
}
#endif
/* 获取剩余空间大小
// 使用示例
DWORD total, free;
get_disk_space("0:", &total, &free);
printf("总容量: %lu KB, 剩余: %lu KB\n", total / 1024, free / 1024);
*/
void get_disk_space(const char* path, uint32_t* total_bytes, uint32_t* free_bytes) {
    FATFS *fs;
    DWORD free_clusters;
    FRESULT res;

    // 1. 获取空闲簇数
    res = f_getfree(path, &free_clusters, &fs);
    if (res != FR_OK) {
        printf("f_getfree failed: %d\n", res);
        return;
    }

    // 2. 计算总簇数（n_fatent 包含保留簇 0 和 1，需减去 2）
    DWORD total_clusters = fs->n_fatent - 2;

    // 3. 计算每簇字节数
    DWORD bytes_per_cluster = fs->csize * 512;  // 假设扇区大小为 512 字节

    // 4. 计算总容量和剩余容量
    *total_bytes = total_clusters * bytes_per_cluster;
    *free_bytes = free_clusters * bytes_per_cluster;
}

/**
 * @brief 从指定文件的第 offset 字节开始读取 len 个字节，并返回文件总大小
 * @param path          文件路径 (例如 "0:/EMULDATA.CSV")
 * @param offset        起始偏移量（字节，从0开始）
 * @param len           要读取的字节数
 * @param buffer        存放读取数据的缓冲区（必须至少 len 字节）
 * @param file_size_out 输出参数：文件总字节数（若为 NULL 则不返回）
 * @return FRESULT      操作结果（FR_OK 表示成功）
 */
FRESULT read_file_part(const char* path, uint32_t offset, uint32_t len, void* buffer, uint32_t* file_size_out) {
    FIL file;
    FRESULT res;
    UINT bytes_read;
    DWORD file_size = 0;

    // 1. 以只读方式打开文件
    res = f_open(&file, path, FA_READ);
    if (res != FR_OK) {
        if (file_size_out) *file_size_out = 0; // 打开失败，文件大小未知
        return res;
    }

    // 2. 获取文件大小并返回给调用者
    file_size = f_size(&file);
    if (file_size_out) *file_size_out = file_size;

    // 3. 检查读取范围是否越界
    if (offset + len > file_size) {
        f_close(&file);
        return FR_INVALID_PARAMETER;
    }

    // 4. 移动文件指针到目标偏移量
    res = f_lseek(&file, offset);
    if (res != FR_OK) {
        f_close(&file);
        return res;
    }

    // 5. 读取 len 个字节
    res = f_read(&file, buffer, len, &bytes_read);
    if (res != FR_OK) {
        f_close(&file);
        return res;
    }

    // 6. 检查实际读取字节数
    if (bytes_read != len) {
        f_close(&file);
        return FR_DISK_ERR;   // 读取字节数不符预期
    }

    // 7. 关闭文件
    f_close(&file);
    return FR_OK;
}

/**
 * @brief 向指定文件的第 offset 字节开始写入 len 字节数据
 * @param path   文件路径 (例如 "0:/EMULDATA.CSV")
 * @param offset 起始偏移量 (字节)
 * @param len    要写入的字节数
 * @param data   指向待写入数据的指针 (必须至少 len 字节)
 * @return FRESULT 返回 FatFs 操作结果 (FR_OK 表示成功)
 */
FRESULT write_file_part(const char* path, uint32_t offset, uint32_t len, const void* data) {
    FIL file;
    FRESULT res;
    UINT bytes_written;

    // 0. 加载文件
    /*res = f_mount(&filesystem, "/", 1);
    if (res != FR_OK) {
        printf("f_mount fail rc=%d\n", res);
        return res;
    }*/

    // 1. 以读写方式打开文件 (文件必须存在，否则返回错误)
    res = f_open(&file, path, FA_READ | FA_WRITE);
    if (res != FR_OK) {
        return res;
    }

    // 2. 移动文件指针到目标偏移量
    res = f_lseek(&file, offset);
    if (res != FR_OK) {
        f_close(&file);
        return res;
    }

    // 3. 写入 len 字节数据
    res = f_write(&file, data, len, &bytes_written);
    if (res != FR_OK) {
        f_close(&file);
        return res;
    }

    // 4. 检查是否真的写入了 len 字节 (理论上应该，但以防万一)
    if (bytes_written != len) {
        f_close(&file);
        return FR_DISK_ERR;   // 写入字节数不符预期
    }

    // 5. 关闭文件 (自动刷新缓存)
    f_close(&file);
    return FR_OK;
}

/**
 * @brief 创建一个新文件（如果文件已存在则退出，不覆盖）
 * @param path  文件路径 (例如 "0:/NEWFILE.TXT")
 * @param data  要写入的初始数据（可为 NULL）
 * @param len   数据长度（字节）
 * @return FRESULT 操作结果：
 *         - FR_OK       : 文件成功创建并写入（或已存在）
 *         - FR_EXIST    : 文件已存在（若需要区分，可返回此值）
 *         - 其他        : 错误码
 */
FRESULT create_file(const char* path, const void* data, uint32_t len) {
    FIL file;
    FRESULT res;
    UINT bytes_written;

    // 1. 尝试以 "创建新文件" 模式打开
    //    FA_CREATE_NEW : 如果文件已存在，f_open 返回 FR_EXIST
    //    FA_WRITE      : 允许写入
    res = f_open(&file, path, FA_CREATE_NEW | FA_WRITE);
    
    // 2. 如果文件已存在，直接退出（不执行任何操作）
    if (res == FR_EXIST) {
        // 此处返回 FR_OK 表示“已存在，未操作”，也可根据需求返回 FR_EXIST
        return FR_OK;   // 或者 return FR_EXIST; 
    }
    
    // 3. 其他错误则直接返回
    if (res != FR_OK) {
        return res;
    }

    // 4. 如果提供了初始数据，写入文件
    if (data != NULL && len > 0) {
        res = f_write(&file, data, len, &bytes_written);
        if (res != FR_OK || bytes_written != len) {
            f_close(&file);
            return (res == FR_OK) ? FR_DISK_ERR : res;
        }
    }

    // 5. 关闭文件（自动保存）
    f_close(&file);
    return FR_OK;
}

//Deepseek AI Program The Function
#ifdef DEEPSEEK
#include "ff.h"   // FatFs 核心 API

/**
 * @brief 从指定文件的第 offset 字节开始读取 len 字节数据
 * @param path  文件路径 (例如 "0:/EMULDATA.CSV")
 * @param offset 起始偏移量 (字节)
 * @param len    要读取的字节数
 * @param buffer 存放读取数据的缓冲区 (必须至少 len 字节)
 * @return FRESULT 返回 FatFs 操作结果 (FR_OK 表示成功)
 */
FRESULT read_file_part(const char* path, DWORD offset, UINT len, void* buffer) {
    FIL file;          // 文件对象
    FRESULT res;
    UINT bytes_read;

    // 1. 以只读方式打开文件
    res = f_open(&file, path, FA_READ);
    if (res != FR_OK) {
        return res;   // 打开失败
    }

    // 2. 检查文件大小是否足够
    DWORD file_size = f_size(&file);
    if (offset + len > file_size) {
        f_close(&file);
        return FR_INVALID_PARAMETER;   // 要读取的范围超出文件末尾
    }

    // 3. 移动文件指针到目标偏移量
    res = f_lseek(&file, offset);
    if (res != FR_OK) {
        f_close(&file);
        return res;
    }

    // 4. 读取 len 字节数据到 buffer
    res = f_read(&file, buffer, len, &bytes_read);
    if (res != FR_OK) {
        f_close(&file);
        return res;
    }

    // 5. 检查是否真的读到了 len 字节 (可能因为文件结束等原因少读了)
    if (bytes_read != len) {
        f_close(&file);
        return FR_DISK_ERR;   // 实际读取字节数不符预期
    }

    // 6. 关闭文件
    f_close(&file);
    return FR_OK;
}

// 在调用前需要先挂载文件系统 (通常在 main 中执行)
FATFS fs;
f_mount(&fs, "0:", 1);

// 准备一个 100 字节的缓冲区
uint8_t data[100];

// 读取文件 "EMULDATA.CSV" 从第 1000 字节开始的 100 个字节
FRESULT res = read_file_part("0:/EMULDATA.CSV", 1000, 100, data);
if (res == FR_OK) {
    // 数据已存于 data 数组中，可以进一步处理
    printf("成功读取 %d 字节\n", 100);
} else {
    printf("读取失败，错误码: %d\n", res);
}

#include "ff.h"   // FatFs 核心 API

/**
 * @brief 向指定文件的第 offset 字节开始写入 len 字节数据
 * @param path   文件路径 (例如 "0:/EMULDATA.CSV")
 * @param offset 起始偏移量 (字节)
 * @param len    要写入的字节数
 * @param data   指向待写入数据的指针 (必须至少 len 字节)
 * @return FRESULT 返回 FatFs 操作结果 (FR_OK 表示成功)
 */
FRESULT write_file_part(const char* path, DWORD offset, UINT len, const void* data) {
    FIL file;
    FRESULT res;
    UINT bytes_written;

    // 1. 以读写方式打开文件 (文件必须存在，否则返回错误)
    res = f_open(&file, path, FA_READ | FA_WRITE);
    if (res != FR_OK) {
        return res;
    }

    // 2. 移动文件指针到目标偏移量
    res = f_lseek(&file, offset);
    if (res != FR_OK) {
        f_close(&file);
        return res;
    }

    // 3. 写入 len 字节数据
    res = f_write(&file, data, len, &bytes_written);
    if (res != FR_OK) {
        f_close(&file);
        return res;
    }

    // 4. 检查是否真的写入了 len 字节 (理论上应该，但以防万一)
    if (bytes_written != len) {
        f_close(&file);
        return FR_DISK_ERR;   // 写入字节数不符预期
    }

    // 5. 关闭文件 (自动刷新缓存)
    f_close(&file);
    return FR_OK;
}

// 准备要写入的数据 (例如 100 个字节)
uint8_t my_data[100] = { /* ... 初始化数据 ... */ };

// 写入到文件 "EMULDATA.CSV" 的第 1000 字节处
FRESULT res = write_file_part("0:/EMULDATA.CSV", 1000, 100, my_data);
if (res == FR_OK) {
    printf("成功写入 100 字节\n");
} else {
    printf("写入失败，错误码: %d\n", res);
}


#include "ff.h"   // FatFs 核心 API

/**
 * @brief 创建一个新文件（如果文件已存在则覆盖）
 * @param path  文件路径 (例如 "0:/NEWFILE.TXT")
 * @param data  要写入的初始数据（可为 NULL）
 * @param len   数据长度（字节）
 * @return FRESULT 操作结果 (FR_OK 表示成功)
 */
FRESULT create_file(const char* path, const void* data, UINT len) {
    FIL file;
    FRESULT res;
    UINT bytes_written;

    // 1. 以 "创建并写入" 模式打开文件
    //    FA_CREATE_ALWAYS : 若文件存在则覆盖，不存在则新建
    //    FA_WRITE        : 允许写入
    res = f_open(&file, path, FA_CREATE_ALWAYS | FA_WRITE);
    if (res != FR_OK) {
        return res;
    }

    // 2. 如果提供了初始数据，写入文件
    if (data != NULL && len > 0) {
        res = f_write(&file, data, len, &bytes_written);
        if (res != FR_OK || bytes_written != len) {
            f_close(&file);
            return (res == FR_OK) ? FR_DISK_ERR : res;
        }
    }

    // 3. 关闭文件（自动保存）
    f_close(&file);
    return FR_OK;
}

// 创建一个空文件
FRESULT res = create_file("0:/EMPTY.TXT", NULL, 0);
if (res == FR_OK) {
    printf("空文件创建成功\n");
}

// 创建一个带初始数据的文件
char initial_data[] = "Hello, FAT12!";
res = create_file("0:/HELLO.TXT", initial_data, sizeof(initial_data)-1);
if (res == FR_OK) {
    printf("带数据的文件创建成功\n");
}

#include "ff.h"   // FatFs 核心 API

/**
 * @brief 创建一个新文件（如果文件已存在则退出，不覆盖）
 * @param path  文件路径 (例如 "0:/NEWFILE.TXT")
 * @param data  要写入的初始数据（可为 NULL）
 * @param len   数据长度（字节）
 * @return FRESULT 操作结果：
 *         - FR_OK       : 文件成功创建并写入（或已存在）
 *         - FR_EXIST    : 文件已存在（若需要区分，可返回此值）
 *         - 其他        : 错误码
 */
FRESULT create_file(const char* path, const void* data, UINT len) {
    FIL file;
    FRESULT res;
    UINT bytes_written;

    // 1. 尝试以 "创建新文件" 模式打开
    //    FA_CREATE_NEW : 如果文件已存在，f_open 返回 FR_EXIST
    //    FA_WRITE      : 允许写入
    res = f_open(&file, path, FA_CREATE_NEW | FA_WRITE);
    
    // 2. 如果文件已存在，直接退出（不执行任何操作）
    if (res == FR_EXIST) {
        // 此处返回 FR_OK 表示“已存在，未操作”，也可根据需求返回 FR_EXIST
        return FR_OK;   // 或者 return FR_EXIST; 
    }
    
    // 3. 其他错误则直接返回
    if (res != FR_OK) {
        return res;
    }

    // 4. 如果提供了初始数据，写入文件
    if (data != NULL && len > 0) {
        res = f_write(&file, data, len, &bytes_written);
        if (res != FR_OK || bytes_written != len) {
            f_close(&file);
            return (res == FR_OK) ? FR_DISK_ERR : res;
        }
    }

    // 5. 关闭文件（自动保存）
    f_close(&file);
    return FR_OK;
}

#endif

#if 0  // This is a test button function to read/write files from inside Pico with FatFs library.
static void read_write_task(void) {
    static bool last_status = false;
    static int count = 0;
    static uint64_t long_push = 0;

    bool button = bb_get_bootsel_button();
    if (last_status != button && button) {  // Push BOOTSEL button
        task_read_file_content(&count);
    } else if (last_status != button && !button) { // Release BOOTSEL button
        task_write_file_content(count);
    }
    last_status = button;

    if (button) {
        long_push++;
    } else {
        long_push = 0;
    }
    if (long_push > 125000) { // Long-push BOOTSEL button
        printf("Formate FAT12 on flash memory\n");
        flash_fat_initialize();
        count = 0;
        long_push = 0;
    }
}
#endif