// SPDX-License-Identifier: MIT
/*
 * Copyright (c) 2024 Thomas Grech <thomas@grechtech.co.uk>
 */

#if !defined(_USB_COMM_H_)
#define _USB_COMM_H_

#include <stdint.h>

extern uint8_t u8CDCTxBuf[];
extern uint8_t u8CDCRxBuf[];

// UART RX to USB CDC
extern void cdc_task_read(void); 
// USB CDC to UART TX
extern void cdc_task_write(void); 

#endif /* _USB_COMM_H_ */