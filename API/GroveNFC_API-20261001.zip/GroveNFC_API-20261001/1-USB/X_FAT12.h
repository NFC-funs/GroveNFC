#ifndef     __X_FAT12_H__
#define     __X_FAT12_H__

#include <ff.h>

void test_and_init_filesystem(void);

void get_disk_space(const char* path, uint32_t* total_bytes, uint32_t* free_bytes);
FRESULT read_file_part(const char* path, uint32_t offset, uint32_t len, void* buffer, uint32_t* file_size_out);
FRESULT write_file_part(const char* path, uint32_t offset, uint32_t len, const void* data);
FRESULT create_file(const char* path, const void* data, uint32_t len);

//ISO14A///////////////////////////////////////////////////////////////
#define FAT12_FileName_MF1_4B1K     "ISO14A/MF1_4B1K.BIN"
#define FAT12_FileName_MF1_7B1K     "ISO14A/MF1_7B1K.BIN"
#define FAT12_FileName_MF1_4B4K     "ISO14A/MF1_4B4K.BIN"
#define FAT12_FileName_MF1_7B4K     "ISO14A/MF1_7B4K.BIN"
#define FAT12_FileName_SNIFFOFF     "ISO14A/SNIFFOFF.BIN"
//#define FAT12_FileName_SNIFFON      "ISO14A/SNIFFON.BIN"
    #define FAT12_FileName_MF1_4B1K_NAME     "ISO14A/MF1_4B1K_NAME.TXT"

#define FAT12_FileName_NTAG21X      "ISO14A/NTAG21X.BIN"
///////////////////////////////////////////////////////////////////////

//ISO14B///////////////////////////////////////////////////////////////
#define FAT12_FileName_CHINA_ID     "ISO14B/CHINA_ID.BIN"
///////////////////////////////////////////////////////////////////////

//ISO15////////////////////////////////////////////////////////////////
#define FAT12_FileName_ISO15        "ISO15/ISO15.BIN"

//Amiibo///////////////////////////////////////////////////////////////
#define FAT12_FileName_AMIIBO_KEY           "Amiibo/key_retail.bin"
#define FAT12_FileName_AMIIBO_DATA          "Amiibo/all.bin"
#define FAT12_FileName_AMIIBO_DATA_NAME     "Amiibo/allname.txt"
///////////////////////////////////////////////////////////////////////

#endif