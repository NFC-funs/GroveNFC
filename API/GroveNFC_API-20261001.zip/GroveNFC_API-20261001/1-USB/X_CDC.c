#include <stdio.h>
#include <pico/stdlib.h>
#include <tusb.h>

uint8_t buf_rx[CFG_TUD_CDC_TX_BUFSIZE];
uint8_t buf_tx[CFG_TUD_CDC_RX_BUFSIZE];


void cdc_task_read(void) 
{

}


void cdc_task_write(void) 
{
  
}