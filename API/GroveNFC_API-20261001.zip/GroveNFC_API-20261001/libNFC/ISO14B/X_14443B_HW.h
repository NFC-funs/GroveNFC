#ifndef     __X_14443BHW_H__
#define     __X_14443BHW_H__

#include <stdint.h>
#include <stdio.h>

#include "pico/stdlib.h"

///////////////////////////////////////////////////////
//PS-20220918
//PCD --> PICC timing
//etu -- 128/Fc
//logic 0 -- 1 etu low
//logic 1 -- 1 etu high
//START -- 1 logic 0
//CHAR -- LSB first
//STOP -- 1 logic 1
//EGT -- 0-57us
//EOF -- 10.5 logic 0
///////////////////////////////////////////////////////

/* ###################################### */
/*Call this function after X_NFCFiledOn();*/
/*Delay time = u16timer * 9.44us          */
/* ###################################### */
extern void RF14443B_Carrier_On_Delay(uint16_t u16timer); //unit -- 128/fc

/* ###################################### */
/* return ISO14443B crc16                 */
/* high byte transmit first               */
/* ###################################### */
extern uint16_t crc16_B(uint8_t *data, uint16_t len);

/* ###################################### */
/* return true or false                   */
/* ###################################### */
extern bool HasValidCrcB(uint8_t *receivedCmd, uint16_t receivedCmd_len);

/* ###################################### */
/* append crc to the end of data          */
/* ###################################### */
extern void AppendCrcB(uint8_t *data, uint16_t len);

/* ######################################### */
/* transmit clear txt data                   */
/* uint8_t *buf: transmit data buffer        */
/* uint16_t len: length of transmit data     */
/* uint8_t egt: egt euts "1" after stop bit  */
/* ######################################### */
extern void __not_in_flash_func(RF14443B_Reader_SendData)(uint8_t *buf, uint16_t len, uint8_t egt);  //egt<=20

/* ######################################### */
/* receive clear txt data in FWI             */
/* return length of receive data             */
/* uint8_t *recv_buf: receive data buffer    */
/* uint8_t u8FWI: TR0 - (256/fs)*2^FWI(0-14) */
/* ######################################### */
extern int16_t __not_in_flash_func(RF14443B_Reader_RecvData)(uint8_t *recv_buf, uint8_t u8FWI);

/* ######################################### */
/* PIO: receive tag's data in reader mode    */
/* ######################################### */
extern void X_PIOCapture14bInit();
extern void X_PIOCapture14bDeinit();
////////////////////////////////////////////////////////////////////////////

//PS-20220918
//PICC --> PCD delay
//EGT -- 0-19us 1.5 etu  //PS-20220925
//SOF - 10.5bit"0" 2.5bit"1"  //PS-20220925
//PS-20221001
// ISO/IEC 14443-2, 9.2.5.
//TR0 -- >= 64/Fs <=256/Fs(ATQB 302us) (256/fs)*2^FWI(the others)
//TR1 -- >= 80/Fs <=200/Fs
///////////////////////////////////////////////////////
//////////////////////////////////////////
//Tag mode////////////////////////////////
/* ######################################### */
/* response data in tag mode                 */
/* uint8_t *resp: response data buffer       */
/* uint16_t len: length of response data     */
/* uint32_t tr0: undefined                   */
/* uint32_t tr1: 80~200                      */
/* uint8_t egt: egt euts "1" after stop bit  */
/* ######################################### */
extern void __not_in_flash_func(X_14443B_Tag_SendData)(uint8_t *resp, uint16_t len, uint32_t tr0, uint8_t tr1, uint8_t egt);//tr0--fs tr1--fs egt-etu

/* ######################################### */
/* callback function in tag mode             */
/* ######################################### */
//X_ISO14B_Tag_Emul call back function
extern int __not_in_flash_func(X_ISO14B_Tag_Emul)(uint16_t len);

/* ######################################### */
/* PIO: receive reader's command in tag mode */
/* ######################################### */
//capture falling edge and filter inter-pulse
extern void X_PIOCapture14bfilterInit();
extern void X_PIOCapture14bfilterDeinit();
#endif
