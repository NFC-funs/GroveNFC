#ifndef     __X_15693_H__
#define     __X_15693_H__

#include <stdint.h>
#include <stdio.h>

#include "pico/stdlib.h"

//timing for 15693
///////////////////////////////////////////////////////
//PS-20221023
//VCD --> VICC timing 100%-ASK 1/4
//pause -- 128/Fc no carrier
//00 -- 128/Fc + pause + 128*6/Fc
//01 -- 128*3/Fc + pause + 128*4/Fc
//10 -- 128*5/Fc + pause + 128*2/Fc
//11 -- 128*7/Fc + pause
//SOF -- pause + 128*3/Fc + 128/Fc + pause + 128*2/Fc
//EOF -- 128*2/Fc + pause + 128/Fc
///////////////////////////////////////////////////////

///////////////////////////////////////////////////////
//PS-20221023
//VICC --> VCD timing, only one sub carrier, fs=Fc/32, 26.48kbps(Fc/512)
//logic 0 -- 8fs + 8nc
//logic 1 -- 8nc + 8fs
//SOF -- 24nc + 24fs + 8nc + 8fs
//EOF -- 8fs + 8nc + 24fs + 24nc
//////////////////////////////////////////////////////

///////////////////////////////////////////////////////
//PS-20221023
//VICC --> VCD delay from EOF rising edge
//T1--wait for transmite: nomal -- 4352/Fc, min -- 4320/Fc, max -- 4384/Fc
//4352/13.56=320.94us, Ti--322.08 NXP--320.58

//first VCD --> VICC
//carrier on > 1ms
//wait for next VCD --> VICC
//4192/Fc
//turn on carrier delay 9.44us*u16timer
extern void RF15693_Carrier_On_Delay(uint16_t u16timer); //unit -- 128/fc

/* ###################################### */
/* return ISO15693 crc16                  */
/* low byte transmit first                */
/* ###################################### */
extern uint16_t crc16_V(uint8_t *data, uint16_t len);
extern bool HasValidCrcV(uint8_t *receivedCmd, uint16_t receivedCmd_len);
extern void AppendCrcV(uint8_t *data, uint16_t len);

//reader mode:  capture rising edge
extern void X_PIOCapture15Init();
extern void X_PIOCapture15Deinit();
//mode: 0-ASK 1-FSK
extern void __not_in_flash_func(RF15693_Reader_SendData)(uint8_t *buf, uint16_t len, uint8_t mode);
extern int16_t __not_in_flash_func(RF15693_Reader_RecvData)(uint8_t *recv_buf, uint8_t mode);
extern void __not_in_flash_func(RF15693_Reader_SendEOF)();


//tag mode: capture falling edge(filter 3us)
extern void X_PIOCapture15filterInit();
extern void X_PIOCapture15filterDeinit();
extern void __not_in_flash_func(X_15693_Tag_SendData)(uint8_t *resp, uint16_t len, uint8_t mode);


//X_15693_Tag_Emul call back function, task time < 188.8us
extern int __not_in_flash_func(X_15693_Tag_Emul)(uint16_t len);  //recv buffer: uint8_t u8CmdVcd2Vicc[256];

#endif

