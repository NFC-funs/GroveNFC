#ifndef __XCOMM_H__
#define __XCOMM_H__

extern uint8_t X_SystemInit(void);
extern uint8_t X_NFCInit();
extern void X_NFCFiledOn();
extern void X_NFCFiledOff();
extern void X_NFCSetRef(uint16_t voltage);
extern uint8_t X_NFCMf1ToolInit(uint8_t type);

#endif
