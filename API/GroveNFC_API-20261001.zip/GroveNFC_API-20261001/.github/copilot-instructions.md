# Copilot / AI agent guidance for Pico_NFC

This file gives concise, actionable hints for AI coding agents working on this Raspberry Pi Pico NFC project.

## Big picture
- Project is a Pico SDK C project; main entry is [Pico_NFC.c](Pico_NFC.c#L1).
- Multi-core split: `core0` runs NFC/protocol stack, `core1` runs host interface (I2C or UART). See [0-Core1/X_Core1.c](0-Core1/X_Core1.c#L1).
- Interface module prefixes: most custom modules use `X_` prefix and are grouped in numbered folders `0-Core1`, `1-USB`, `2-NFC`, etc. Treat those as independent components.
- Hardware/low-level code lives in `libNFC/` (prebuilt static libs and PIO headers). The project links prebuilt archives from `libNFC/*.a` in [CMakeLists.txt](CMakeLists.txt#L1).

## Critical flows & integration points
- Multicore communication: uses `pico/multicore` FIFO. Core1 pushes commands to core0; core0 processes and may reply. See `multicore_launch_core1()` in [Pico_NFC.c](Pico_NFC.c#L1) and FIFO handlers in `X_Core1.c`/`X_I2c.c`.
- I2C slave: default address `0x48`, SDA pin 16, SCL pin 17; data/control registers defined in [0-Core1/X_I2c.h](0-Core1/X_I2c.h#L1).
- USB/tinyusb: tinyusb config is in `1-USB/tusb_config.h`; USB stdio may be enabled/disabled in CMake via `pico_enable_stdio_usb`.
- PIO usage: PIO programs are included as headers in `libNFC/*/pio_*.pio.h` — avoid duplicating PIO state; follow existing PIO wrappers in `libNFC`.

## Build / flash / debug workflows (explicit)
- Primary build (VS Code tasks provided): run the `Compile Project` task (uses ninja). Equivalent command:

```powershell
ninja -C build
```

- Produce UF2 in `build/` (a timestamped copy is created by CMake). Flashing is provided by the `Run Project` task which calls the picotool in your local pico SDK setup; consult the `Run Project` task in VS Code tasks for the exact path on your machine.

- For SWD flashing via OpenOCD the `Flash` task runs `openocd.exe` with CMSIS-DAP scripts (see VS Code tasks). Use that for debug/program-verify flows.

## Project conventions & patterns (concrete)
- Numeric folder prefixes (e.g., `0-Core1`, `1-USB`, `2-NFC`) represent subsystem order and responsibility — follow this grouping when adding features.
- Public APIs use `X_` prefix (e.g., `X_InitI2cSlave`, `X_NFCInit`). Search for `X_` to find cross-module interfaces.
- Low-level registers and small config structs live in `*.h` (example: [0-Core1/X_I2c.h](0-Core1/X_I2c.h#L1)). Keep ABI-stable changes minimal to avoid breaking multicore messages.
- Native libs: NFC protocol implementations are provided as prebuilt `lib_ps_*.a` archives under `libNFC/`. Prefer using those or adding corresponding wrappers rather than reimplementing core protocol logic.

## Examples (how to modify safely)
- To add a new host command: extend the multicore FIFO message format and update handlers in `X_I2c.c` (core1) and `Pico_NFC.c` (core0) — maintain backward-compatible IDs.
- To use a new PIO program, add its pio header in `libNFC` and follow existing init patterns (search for `pio_add_program` in repo).

## Files to inspect first
- [CMakeLists.txt](CMakeLists.txt#L1) — build flags, libs, and tasks integration.
- [Pico_NFC.c](Pico_NFC.c#L1) — main loop and core0 responsibilities.
- [0-Core1/X_Core1.c](0-Core1/X_Core1.c#L1) and [0-Core1/X_I2c.h](0-Core1/X_I2c.h#L1) — interface selection and I2C specifics.
- `libNFC/` — static libs and PIO headers; critical for NFC protocol behavior.

## What not to change without caution
- Avoid rebuilding or replacing `libNFC/*.a` without running corresponding tests — they encapsulate critical protocol logic.
- Don't change multicore message encoding or `X_` public APIs without updating both cores.

## If you need to run or test locally
- Use the provided VS Code tasks: `Compile Project`, `Run Project`, and `Flash` for the common flows.
- Unit tests: none present — prefer manual hardware validation; document any new test harness you add under `tests/`.

---
If any section is unclear or you want examples in Chinese, tell me which parts to expand or correct.
