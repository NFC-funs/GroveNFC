#include <stdio.h>
#include "pico/stdlib.h"
#include "pico/multicore.h"
#include "hardware/sync.h"
#include "pico/flash.h"

#include "tusb.h"
#include "flash.h"

#include "libNFC/X_Core0.h"
#include "libNFC/Comm/X_Comm.h"

#include "1-USB/X_FAT12.h"
#include "1-USB/X_CDC.h"
#include "1-USB/flash.h"

#include "4-I2C/X_I2C.h"
#include "4-I2C/X_RegPara.h"
#include "4-I2C/I2C_Function.h"

void core1_entry(void);
void X_I2cWriteFlashTask(void);  //I2c mode, write tags' data

int main()
{
    stdio_uart_init_full(uart1, 921600, 4, 5);
    X_SystemInit();
    stdio_uart_init_full(uart1, 921600, 4, 5);

    tusb_init();
    sleep_ms(200); // wait for USB enumeration

    test_and_init_filesystem();  //FAT12

    multicore_launch_core1(core1_entry);

    X_NFCInit();
    X_InitI2cSlave();

    while (true) 
    {
        X_I2cWriteFlashTask();

        tud_task();
        cdc_task_read();
        cdc_task_write(); 
    }

    return 0;
}

/////////////////////////////////////////////////////////////////

void core1_entry(void)// Core1 Task, mainly used for I2C interrupt handling, and it will not access Flash
{
    irq_set_mask_enabled(USBCTRL_IRQ, false);

    while(1)
    {
        //I2C handle///////////////////////////////////////////////////////////////////////
        {
            sleep_us(1);  //Can't enter HandleI2c without delay!!! I don't know the reason -- maybe sync? PS-20260219
            if (0 != u32I2cSwapCore0)  //i2c interrupt handle
            {    
                INDICATOR_LED_TOG; 
                X_HandleI2c(u32I2cSwapCore0);
                u32I2cSwapCore0 = 0;
            }             
        }
        /////////////////////////////////////////////////////////////////////////////////// 
    }
}


void X_I2cWriteFlashTask(void)
{
    //I2C write tag-data in core0
    if (X_I2cMiscReg.EpWrite == MISC_REG_EPWRITE_WRITE){
        printf("write eeprom start...\n");

        // 1. reset Core 1
        multicore_reset_core1();

        uint32_t ints = save_and_disable_interrupts();
        //erase one sector -- 4096 bytes, 45-400ms
        flash_range_erase(FLASH_TARGET_OFFSET + X_I2cSysReg.TagAddr, FLASH_SECTOR_SIZE);  //4096
        //write data to flash -- Must be a multiple of 256 bytes (one page). 0.4-3ms
        //flash_range_program(FLASH_TARGET_OFFSET + addr, u8TagSimData, FLASH_PAGE_SIZE);  //256
        flash_range_program(FLASH_TARGET_OFFSET + X_I2cSysReg.TagAddr, u8TagSimData, FLASH_SECTOR_SIZE);  //4096
        restore_interrupts(ints);

        printf("write eeprom end.\n");
        X_I2cMiscReg.EpWrite = 0x00;

        // 3. restart Core 1
        multicore_launch_core1(core1_entry);
    }    
}
