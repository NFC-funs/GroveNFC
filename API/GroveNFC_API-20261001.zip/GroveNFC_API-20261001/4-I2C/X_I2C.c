#include <stdio.h>

#include "pico/stdlib.h"
#include "hardware/i2c.h"

#include "X_Ver.h"
#include "X_RegPara.h"
#include "X_I2c.h"

//I2C Slave mode GPIO-Pin//////
#define I2C_SDA_PIN 		16
#define I2C_SCL_PIN 		17
///////////////////////////////

I2cSysReg 	X_I2cSysReg;
I2cMiscReg 	X_I2cMiscReg;
static volatile char* sysreg_start = (char*)&X_I2cSysReg;  //the start address of the struct, used to calculate the offset of each register
static volatile char* miscreg_start = (char*)&X_I2cMiscReg;
uint8_t u8I2cDataBuf[256];  //the buffer to store the data received from I2C master

//the value is the offset of the register written by master,
//which is used by core1 to know which register is written and how many bytes are written
uint32_t u32I2cSwapCore0 = 0;  //trigger core1,  the value is the offset of the register written by master, which is used by core1 to know which register is written and how many bytes are written

// Interrupt handler
static void __not_in_flash_func(i2c0_irq_handler)() {

    static uint16_t recv_counter, trans_counter;
    static uint8_t highaddr, lowaddr;
    static bool restart;

    // Get interrupt status
    uint32_t status = i2c0->hw->intr_stat;
    if (status == 0) return;

    if (status & I2C_IC_INTR_STAT_R_TX_ABRT_BITS) {
        i2c0->hw->clr_tx_abrt;
    }
    if (status & I2C_IC_INTR_STAT_R_START_DET_BITS) {
        i2c0->hw->clr_start_det;
        recv_counter = 0;
        restart = false;
    }
    if (status & I2C_IC_INTR_STAT_R_RESTART_DET_BITS) {
        i2c0->hw->clr_restart_det;
        trans_counter = 0;
        restart = true;
    }
    if (status & I2C_IC_INTR_STAT_R_STOP_DET_BITS) {
        i2c0->hw->clr_stop_det;
        
        if (restart){  //do nothing when read register
            //printf("read register %02x-%02x: %d\n", highaddr, lowaddr, trans_counter);
        }
        else{   //dont support single-byte address
            if (recv_counter < 3)
            {
                recv_counter = 0;
            }
            //write data to register
            if (recv_counter > 2)
            {
                //printf("write register %02x-%02x: %d\n", highaddr, lowaddr, recv_counter-2);
                //for (uint16_t i=0;i<(recv_counter-2);i++) printf(" %02x ", u8I2cRecvBuf[i]);
                //printf("\n");
                //trigger core0 after receive "write" stop signal, and send the offset and length of the register written by master through FIFO
                u32I2cSwapCore0 = (uint32_t)(highaddr<<24) + (uint32_t)(lowaddr<<16) + (recv_counter-2);
                //printf("u32I2cSwapCore0: %08x\n", u32I2cSwapCore0);
            }        
        }

    }
    // Check to see if we have received data from the I2C controller
    if (status & I2C_IC_INTR_STAT_R_RX_FULL_BITS) {
        // Read the data (this will clear the interrupt)
        uint32_t value = i2c0->hw->data_cmd;

        if (restart){  //first data is device address, ignore it
            //printf("device addr: %04x\n", value);
        }
        else{
            // Check if this is the 1st byte we have received
            if (value & I2C_IC_DATA_CMD_FIRST_DATA_BYTE_BITS) {
                // If so treat it as the high address to use
                highaddr = (uint8_t)(value & I2C_IC_DATA_CMD_DAT_BITS);
                recv_counter = 1;
            } else {
                // 2nd byte as the low address
                if (recv_counter == 1){
                    lowaddr = (uint8_t)(value & I2C_IC_DATA_CMD_DAT_BITS);
                    recv_counter = 2;
                }
                else{
                    if (((highaddr<<8) + lowaddr) >= I2cEpromReg_Addr)
                    {
                        u8I2cDataBuf[recv_counter-2] = (uint8_t)(value & I2C_IC_DATA_CMD_DAT_BITS);
                    }
                    else if ( ((highaddr<<8) + lowaddr) == I2cDataReg_Addr )  //write to data reg
                    {
                        u8I2cDataBuf[recv_counter-2] = (uint8_t)(value & I2C_IC_DATA_CMD_DAT_BITS);
                    }
                    else if ( ((highaddr<<8) + lowaddr) >= I2cMiscReg_Base_Addr )  //write to misc reg
                    {
                        miscreg_start[(highaddr<<8) + lowaddr -I2cMiscReg_Base_Addr + (recv_counter-2)] = (uint8_t)(value & I2C_IC_DATA_CMD_DAT_BITS);
                        //printf("write misc reg %02x-%02x: %02x\n", highaddr, lowaddr, (uint8_t)(value & I2C_IC_DATA_CMD_DAT_BITS));
                    }
                    else  //write to sys reg
                    {
                        sysreg_start[(highaddr<<8) + lowaddr + (recv_counter-2)] = (uint8_t)(value & I2C_IC_DATA_CMD_DAT_BITS);  
                    }
                    
                    recv_counter ++;
                }
            }             
        }
   
    }
    if (status & I2C_IC_INTR_STAT_R_RD_REQ_BITS) {
        i2c0->hw->clr_rd_req;
        if ( ((highaddr<<8) + lowaddr) == I2cDataReg_Addr )
        {
            i2c0->hw->data_cmd = u8I2cDataBuf[trans_counter];
        }
        else if ( ((highaddr<<8) + lowaddr) >= I2cMiscReg_Base_Addr )  //read misc reg
        {
            i2c0->hw->data_cmd = miscreg_start[(highaddr<<8) + lowaddr + trans_counter];
        }
        else  //read sys reg
        {
            i2c0->hw->data_cmd = sysreg_start[(highaddr<<8) + lowaddr + trans_counter];
        }

        trans_counter ++;
    }
}


void X_InitI2cReg()
{
    /////////////parameter init//////////////
    X_I2cSysReg.VerHardware = X_VER_HARDWARE;
    X_I2cSysReg.VerFirmware = X_VER_FIRMWARE;
    X_I2cSysReg.Mode = SYS_REG_MODE_DEFAULT;
    //X_I2cSysReg.TagAddr
    X_I2cSysReg.RfConfig = SYS_REG_RFCONFIG_READER_DEFAULT|SYS_REG_RFCONFIG_TAG_DEFAULT;
    X_I2cSysReg.FWI = 0x0009;  //default FWI is 9, which means 2^9=512 symbols, about 5.12ms for 106k
    X_I2cSysReg.TxCrcEn = SYS_REG_TXCRCEN_DEFAULT;
    X_I2cSysReg.RxCrcEn = SYS_REG_RXCRCEN_DEFAULT;
    X_I2cSysReg.NFCStatus = SYS_REG_NFCSTATUS_DEFAULT;
    //X_I2cSysReg.RxLen

    X_I2cMiscReg.RFOn = MISC_REG_RFON_DEFAULT;
    X_I2cMiscReg.TxLastBit = MISC_REG_TXLASTBIT_DEFAULT;
    X_I2cMiscReg.Thru = MISC_REG_THRU_DEFAULT;
    X_I2cMiscReg.EGT = MISC_REG_EGT_DEFAULT;
    X_I2cMiscReg.Slot = MISC_REG_SLOT_DEFAULT;
    //////////////////////////////////////////////    
}
void X_InitI2cSlave()
{
    X_InitI2cReg();

    // Setup I2C0 as slave (peripheral)
    i2c_init(i2c0, 100 * 1000);
    i2c_set_slave_mode(i2c0, true, I2C_SLAVE_ADDR);

    // 初始化GPIO引脚
    gpio_set_function(I2C_SDA_PIN, GPIO_FUNC_I2C);
    gpio_set_function(I2C_SCL_PIN, GPIO_FUNC_I2C);
    gpio_pull_up(I2C_SDA_PIN);
    gpio_pull_up(I2C_SCL_PIN);

    // Enable the I2C interrupts we want to process
    //i2c0->hw->intr_mask = (I2C_IC_INTR_MASK_M_RD_REQ_BITS | I2C_IC_INTR_MASK_M_RX_FULL_BITS);
    // unmask necessary interrupts
    i2c0->hw->intr_mask = I2C_IC_INTR_MASK_M_RX_FULL_BITS \
                    | I2C_IC_INTR_MASK_M_RD_REQ_BITS \
                    | I2C_IC_INTR_MASK_M_TX_ABRT_BITS \
                    | I2C_IC_INTR_MASK_M_STOP_DET_BITS \
                    | I2C_IC_INTR_MASK_M_START_DET_BITS \
                    | I2C_IC_INTR_MASK_M_RESTART_DET_BITS;


    // Set up the interrupt handler to service I2C interrupts
    irq_set_exclusive_handler(I2C0_IRQ, i2c0_irq_handler);

    // Enable I2C interrupt
    irq_set_enabled(I2C0_IRQ, true);
}