#ifndef __I2CFUNC_H__
#define __I2CFUNC_H__

#define UARTSETWORKMODE_FLAG  0xF0000000

extern void X_HandleI2c(uint32_t swap);
extern uint32_t gSetWorkMode;  //uart set work mode 
extern uint32_t gWriteToFile;  //high 16bits -- file, low 16bits -- slot
extern uint16_t u16TagMode;  //record tag mode, remove pio when from tag mode to default mode
#endif