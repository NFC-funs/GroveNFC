#ifndef __XVER_H__
#define __XVER_H__

#define X_VER_HARDWARE		( (6<<12)|(1<<8)|(2<<4)|(3<<0) ) //0x6123--20260123;  
#define X_VER_FIRMWARE		( (6<<12)|(9<<8)|(3<<4)|(0<<0) ) //0x6913--20260930;

//Compatible with PN532Killer
#define VER_YEAR    26 
#define VER_MONTH   9
#define VER_DAY     30

#endif