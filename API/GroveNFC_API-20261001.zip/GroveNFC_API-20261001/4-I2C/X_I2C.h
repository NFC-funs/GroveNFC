#ifndef __XI2C_H__
#define __XI2C_H__

#include <stdint.h>

////////I2C Slave mode///////////
#define I2C_SLAVE_ADDR 		0x48
#define I2cDataReg_Addr			0x0100
#define I2cEpromReg_Addr		0x1000 //0x1000-0x1FFF, 4K bytes buffer

#define I2cSysReg_Base_Addr		0x0000  //0x0000-0x001F
#define I2cSysReg_GetHardwareVersion_Addr   (I2cSysReg_Base_Addr + 0x0000)
#define I2cSysReg_GetFirmwareVersion_Addr   (I2cSysReg_Base_Addr + 0x0002)
#define I2cSysReg_SetMode_Addr              (I2cSysReg_Base_Addr + 0x0004)
#define I2cSysReg_SetTagAddr_Addr           (I2cSysReg_Base_Addr + 0x0006)
#define I2cSysReg_SetRFConfig_Addr          (I2cSysReg_Base_Addr + 0x0008)
#define I2cSysReg_SetFWI_Addr               (I2cSysReg_Base_Addr + 0x000A)
#define I2cSysReg_SetTxCrcEn_Addr           (I2cSysReg_Base_Addr + 0x000C)
#define I2cSysReg_SetRxCrcEn_Addr           (I2cSysReg_Base_Addr + 0x000E)
#define I2cSysReg_GetNFCStatus_Addr         (I2cSysReg_Base_Addr + 0x0010)
#define I2cSysReg_ClrNFCStatus_Addr         (I2cSysReg_Base_Addr + 0x0010)
#define I2cSysReg_GetRxLen_Addr             (I2cSysReg_Base_Addr + 0x0012)
#define I2cSysReg_Shortcut_Addr             (I2cSysReg_Base_Addr + 0x0014)

typedef struct {
    uint16_t VerHardware;  //RO
	uint16_t VerFirmware;  //RO
    uint16_t Mode;
    //Mode is SYS_REG_MODE_TAG, TagAddr: 0000-FFFF, 64K for 16 tags, must be a multiple of 4096 bytes (one sector).
    //Mode is SYS_REG_MODE_FILE_TAG, TagAddr: Slot 0000-xxxx
    uint16_t TagAddr;  
    uint16_t RfConfig;
	uint16_t FWI;
    uint16_t TxCrcEn;
	uint16_t RxCrcEn;
    uint16_t NFCStatus;  //RO
    uint16_t RxLen;  //RO
    uint16_t Command;
} I2cSysReg;

#define I2cMiscReg_Base_Addr	0x0020  //0x0020-0x0023
#define I2cMiscReg_SetRFOn_Addr             (I2cMiscReg_Base_Addr + 0x0000)
#define I2cMiscReg_SetTxLastBit_Addr        (I2cMiscReg_Base_Addr + 0x0001)
#define I2cMiscReg_SetThru_Addr             (I2cMiscReg_Base_Addr + 0x0002)
#define I2cMiscReg_SetEGT_Addr              (I2cMiscReg_Base_Addr + 0x0003)
#define I2cMiscReg_SetSlot_Addr             (I2cMiscReg_Base_Addr + 0x0004)
#define I2cMiscReg_SetResv0_Addr            (I2cMiscReg_Base_Addr + 0x0005)
#define I2cMiscReg_SetResv1_Addr            (I2cMiscReg_Base_Addr + 0x0006)
#define I2cMiscReg_SetResv2_Addr            (I2cMiscReg_Base_Addr + 0x0007)
#define I2cMiscReg_SetResv3_Addr            (I2cMiscReg_Base_Addr + 0x0008)
#define I2cMiscReg_SetEpWrite_Addr          (I2cMiscReg_Base_Addr + 0x0009)


typedef struct {
    uint8_t RFOn;
	uint8_t TxLastBit;
	uint8_t Thru;
	uint8_t EGT;
    uint8_t Slot;
    uint8_t Resv0;
    uint8_t Resv1;
    uint8_t Resv2;
    uint8_t Resv3;
    uint8_t EpWrite;  //write data to flash/read data from flash
} I2cMiscReg;

extern I2cSysReg 	X_I2cSysReg;
extern I2cMiscReg 	X_I2cMiscReg;
extern uint8_t u8I2cDataBuf[256];
extern uint32_t u32I2cSwapCore0;

extern void X_InitI2cSlave();
extern void X_InitI2cReg();

#endif