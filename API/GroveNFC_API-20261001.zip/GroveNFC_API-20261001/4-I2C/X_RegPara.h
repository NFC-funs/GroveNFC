#ifndef __XREGPARA_H__
#define __XREGPARA_H__

////SysRegister for i2c slave mode/////////////////////
    //Mode
    #define SYS_REG_MODE_DEFAULT            0x0000
    #define SYS_REG_MODE_READER             0x0100
    #define SYS_REG_MODE_TAG                0x0200  //Tag data from Flash
    #define SYS_REG_MODE_MIFARE1_READER     0x0300
    #define SYS_REG_MODE_FILE_TAG           0x0400  //Tag data from FAT12 file
        //Tag type only, valid when Mode is set to SYS_REG_MODE_TAG
        #define SYS_REG_MODE_TAG_NONE                    0x0000
        #define SYS_REG_MODE_TAG_NTAG213                 0x0001
        #define SYS_REG_MODE_TAG_NTAG215                 0x0002
        #define SYS_REG_MODE_TAG_NTAG216                 0x0003
        #define SYS_REG_MODE_TAG_NTAG21X                 0x0003  //add it, PS-20260831
        #define SYS_REG_MODE_TAG_MIFARE1_4B1K            0x0004
        #define SYS_REG_MODE_TAG_MIFARE1_7B1K            0x0005
        #define SYS_REG_MODE_TAG_MIFARE1_4B4K            0x0006
        #define SYS_REG_MODE_TAG_MIFARE1_7B4K            0x0007

        #define SYS_REG_MODE_TAG_iSLI                      0x0008  //(28+4)*4
        #define SYS_REG_MODE_TAG_iSLIX                     0x0009  //(28+4)*4
        #define SYS_REG_MODE_TAG_iSLIX2                    0x000A  //(80+4)*4
        #define SYS_REG_MODE_TAG_iSLI_L                    0x000B  //(8+4)*4
        #define SYS_REG_MODE_TAGIT_HF_I_Plus               0x000C  //(64+4)*4
        #define SYS_REG_MODE_TAG_ISO15                     0x000F  //add it, PS-20260831

        #define SYS_REG_MODE_TAG_CHINA_II                  0x0020
        
    //RFConfig, modulation&coding scheme
        //reader config,high 8 bits
        #define SYS_REG_RFCONFIG_READER_DEFAULT            0x0000
        #define SYS_REG_RFCONFIG_READER_ISO14A_106K        0x0100
        #define SYS_REG_RFCONFIG_READER_ISO14A_212K        0x0200
        #define SYS_REG_RFCONFIG_READER_ISO14A_424K        0x0300
        #define SYS_REG_RFCONFIG_READER_ISO14A_848K        0x0400

        #define SYS_REG_RFCONFIG_READER_ISO14B_106K        0x0500
        #define SYS_REG_RFCONFIG_READER_ISO14B_212K        0x0600
        #define SYS_REG_RFCONFIG_READER_ISO14B_424K        0x0700
        #define SYS_REG_RFCONFIG_READER_ISO14B_848K        0x0800

        #define SYS_REG_RFCONFIG_READER_FELICA_212K        0x0900
        #define SYS_REG_RFCONFIG_READER_FELICA_424K        0x0A00

        #define SYS_REG_RFCONFIG_READER_ISO15_26K_ASK100       0x0B00
        #define SYS_REG_RFCONFIG_READER_ISO15_26K_ASK10        0x0C00

        //tag config, low 8 bits
        #define SYS_REG_RFCONFIG_TAG_DEFAULT                0x0000
        #define SYS_REG_RFCONFIG_TAG_ISO14443A_106K         0x0001
        #define SYS_REG_RFCONFIG_TAG_ISO14443A_212K         0x0002
        #define SYS_REG_RFCONFIG_TAG_ISO14443A_424K         0x0003
        #define SYS_REG_RFCONFIG_TAG_ISO14443A_848K         0x0004
        #define SYS_REG_RFCONFIG_TAG_ISO14443B_106K         0x0005
        #define SYS_REG_RFCONFIG_TAG_ISO14443B_212K         0x0006
        #define SYS_REG_RFCONFIG_TAG_ISO14443B_424K         0x0007
        #define SYS_REG_RFCONFIG_TAG_ISO14443B_848K         0x0008
        #define SYS_REG_RFCONFIG_TAG_FELICA_212K            0x0009
        #define SYS_REG_RFCONFIG_TAG_FELICA_424K            0x000A
        #define SYS_REG_RFCONFIG_TAG_ISO15693_26K_ASK       0x000B  //single subcarrier 512/Fs
        #define SYS_REG_RFCONFIG_TAG_ISO15693_26K_FSK       0x000C  //two subcarrier 512/Fs & 508/Fs

    //TxCrcEn
    #define SYS_REG_TXCRCEN_DEFAULT             0x0000
    #define SYS_REG_TXCRCEN_DISABLE             0x0000
    #define SYS_REG_TXCRCEN_14A_ENABLE          0x0001   
    #define SYS_REG_TXCRCEN_14B_ENABLE          0x0002
    #define SYS_REG_TXCRCEN_FELICA_ENABLE       0x0004
    #define SYS_REG_TXCRCEN_ISO15_ENABLE        0x0008
    //RxCrcEn
    #define SYS_REG_RXCRCEN_DEFAULT             0x0000
    #define SYS_REG_RXCRCEN_DISABLE             0x0000
    #define SYS_REG_RXCRCEN_14A_ENABLE          0x0001   
    #define SYS_REG_RXCRCEN_14B_ENABLE          0x0002
    #define SYS_REG_RXCRCEN_FELICA_ENABLE       0x0004
    #define SYS_REG_RXCRCEN_ISO15_ENABLE        0x0008

    //NFCStatus
    #define SYS_REG_NFCSTATUS_DEFAULT           0x0000
    #define SYS_REG_NFCSTATUS_BUSY              0x8000
    #define SYS_REG_NFCSTATUS_RECV_TIMEOUT      0x4000
    #define SYS_REG_NFCSTATUS_RECV_CRCERR       0x2000
    #define SYS_REG_NFCSTATUS_RECV_BITERR       0x1000
    #define SYS_REG_NFCSTATUS_MIFARE1_AUTHOK            0x0800
    #define SYS_REG_NFCSTATUS_MIFARE1_AUTHERR           0x0400
    #define SYS_REG_NFCSTATUS_MIFARE1_WRITEOK           0x0200
    #define SYS_REG_NFCSTATUS_MIFARE1_WRITEERR          0x0100
    #define SYS_REG_NFCSTATUS_RECV_DONE         0x0001
    #define SYS_REG_NFCSTATUS_RECV_NORESP       0x0002
    //NFCStatus for PN532Killer
    #define SYS_REG_NFCSTATUS_PN532_DONE        0x0080  //no data means NORESP!!!

    //Shortcut Command
    #define SYS_REG_COMMAND_NESTED              0x0001
    #define SYS_REG_COMMAND_STATICNESTED        0x0002
    #define SYS_REG_COMMAND_HARDNESTED          0x0003
    #define SYS_REG_COMMAND_DARKSIDE            0x0004
    #define SYS_REG_COMMAND_TAGONSNIFF          0x0005
    #define SYS_REG_COMMAND_TAGOFFSNIFF         0x0006
    #define SYS_REG_COMMAND_TAGONSNIFF_Q        0x0007
    #define SYS_REG_COMMAND_TAGOFFSNIFF_Q       0x0008
    #define SYS_REG_COMMAND_MFKEY32             0x0009
    #define SYS_REG_COMMAND_MFKEY32_Q           0x000A
    #define SYS_REG_COMMAND_MFKEY64             0x000B
    #define SYS_REG_COMMAND_MFKEY64_Q           0x000C
    #define SYS_REG_COMMAND_FUDAN               0x000D
    #define SYS_REG_COMMAND_FUDAN_Q             0x000E
    #define SYS_REG_COMMAND_STATICNESTED_CRACK  0x000F

    #define SYS_REG_COMMAND_PN532KILLER         0x0020
/////////////////////////////////////////////////////////////////////////

////MiscRegister for i2c slave mode/////////////////////
    //RFOn
    #define MISC_REG_RFON_DEFAULT              0x00
    #define MISC_REG_RFON_OFF                  0x00
    #define MISC_REG_RFON_ON                   0x01
    //TxLastBit (only valid when TxCrcEn is disabled)
    #define MISC_REG_TXLASTBIT_DEFAULT         0x00  //8bit data
    #define MISC_REG_TXLASTBIT_0               0x00
    #define MISC_REG_TXLASTBIT_1               0x01
    #define MISC_REG_TXLASTBIT_2               0x02
    #define MISC_REG_TXLASTBIT_3               0x03
    #define MISC_REG_TXLASTBIT_4               0x04
    #define MISC_REG_TXLASTBIT_5               0x05
    #define MISC_REG_TXLASTBIT_6               0x06
    #define MISC_REG_TXLASTBIT_7               0x07
    //Thru
    #define MISC_REG_THRU_DEFAULT              0x00 //disable thru mode
    #define MISC_REG_THRU_DISABLE              0x00 //disable thru mode
    #define MISC_REG_THRU_ENABLE               0x01 //enable thru mode, data received from RF will be sent to I2C master directly without CRC check, and the length is determined by RxLen register
    //EGT
    #define MISC_REG_EGT_DEFAULT               0x00 //default EGT, only valid when 14B is enabled
    #define MISC_REG_EGT_0                     0x00
    #define MISC_REG_EGT_1                     0x01
    #define MISC_REG_EGT_2                     0x02
    #define MISC_REG_EGT_3                     0x03
    #define MISC_REG_EGT_4                     0x04
    #define MISC_REG_EGT_5                     0x05
    #define MISC_REG_EGT_6                     0x06
    #define MISC_REG_EGT_7                     0x07

    //Slot (only valid when Felica is enabled)
    #define MISC_REG_SLOT_DEFAULT              0x00 //default slot, only valid when Felica is enabled
    #define MISC_REG_SLOT_0                    0x00
    #define MISC_REG_SLOT_1                    0x01
    #define MISC_REG_SLOT_2                    0x02
    #define MISC_REG_SLOT_3                    0x03
    #define MISC_REG_SLOT_4                    0x04
    #define MISC_REG_SLOT_5                    0x05
    #define MISC_REG_SLOT_6                    0x06
    #define MISC_REG_SLOT_7                    0x07

    //EpWrite
    #define MISC_REG_EPWRITE_WRITE              0x01
    #define MISC_REG_EPWRITE_READ               0x02


/////////////////////////////////////////////////////////////////////////


#endif