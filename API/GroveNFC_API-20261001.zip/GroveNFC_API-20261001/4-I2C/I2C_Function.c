#include "libNFC/X_Core0.h"
#include "libNFC/Comm/X_Comm.h"

#include "pico/stdlib.h"
#include "hardware/flash.h"
#include "hardware/adc.h" 
#include "hardware/timer.h"

#include "X_I2c.h"
#include "X_RegPara.h"
#include "I2C_Function.h"

#include "libNFC/ISO14A/X_14443A_HW.h"
#include "libNFC/ISO14B/X_14443B_HW.h"
#include "libNFC/ISO15/X_15693_HW.h"
#include "libNFC/Felica/X_FELICA_HW.h"

#include "2-NFC/Felica/X_FELICA_App.h"
#include "2-NFC/ISO15/X_ISO15_App.h"
#include "2-NFC/ISO14B/X_ISO14B_App.h"
#include "2-NFC/ISO14A/X_ISO14A_App.h"


#include "1-USB/flash.h"
#include "1-USB/X_FAT12.h"
#include <ff.h>

const uint8_t *flash_target_contents = (const uint8_t *) (XIP_BASE + FLASH_TARGET_OFFSET);

uint32_t gWriteToFile = 0;  //high 16bits -- file, low 16bits -- slot

//////////////////////////////////////////////////////////////////////////////////////////////////////////

void X_FlashReadTagData(uint16_t addr)
{
    for (uint16_t i=0;i<FLASH_SECTOR_SIZE;i++)
        u8TagSimData[i] = flash_target_contents[i + addr];
    printf("read from flash: %04X -- %02X %02X %02X %02X\n", addr, u8TagSimData[0], u8TagSimData[1], u8TagSimData[2], u8TagSimData[3]);
}


//////////////////////////////////////////////////////////////////////////////////////////////////////////////
uint16_t u16TagMode = 0;  //record tag mode, remove pio when from tag mode to default mode

void X_AddReaderPIO()
{
    X_NFCFiledOn();
    switch(X_I2cSysReg.RfConfig)
    {
        case (SYS_REG_RFCONFIG_READER_ISO14A_106K|SYS_REG_RFCONFIG_TAG_ISO14443A_106K):
            RF14443A_Carrier_On_Delay(1000); //2.36ms   //32/fc
            X_PIOCapture1Init();
            printf("Load Reader PIO--14A\n");
            break;
        case (SYS_REG_RFCONFIG_READER_ISO14B_106K|SYS_REG_RFCONFIG_TAG_ISO14443B_106K):
            RF14443B_Carrier_On_Delay(200); //1.88ms    //128/fc
            X_PIOCapture14bInit();
            printf("Load Reader PIO--14B\n");
            break; 
        case (SYS_REG_RFCONFIG_READER_FELICA_212K|SYS_REG_RFCONFIG_TAG_FELICA_212K):
            RFFelica_Carrier_On_Delay(1000); //2.36ms unit -- 32/fc
            X_PIOFelica1Init();
            printf("Load Reader PIO--Felica\n");
            break;
        case (SYS_REG_RFCONFIG_READER_ISO15_26K_ASK100|SYS_REG_RFCONFIG_TAG_ISO15693_26K_ASK):
        case (SYS_REG_RFCONFIG_READER_ISO15_26K_ASK10|SYS_REG_RFCONFIG_TAG_ISO15693_26K_FSK):
        case (SYS_REG_RFCONFIG_READER_ISO15_26K_ASK100|SYS_REG_RFCONFIG_TAG_ISO15693_26K_FSK):
        case (SYS_REG_RFCONFIG_READER_ISO15_26K_ASK10|SYS_REG_RFCONFIG_TAG_ISO15693_26K_ASK):
            RF15693_Carrier_On_Delay(200); //1.88ms unit -- 128/fc
            X_PIOCapture15Init();
            printf("Load Reader PIO--15\n");
            break;

        default:
            printf("Load Reader PIO--Unkown\n");
            break;
    }    
}
void X_RemoveReaderPIO()
{
    switch(X_I2cSysReg.RfConfig)
    {
        case (SYS_REG_RFCONFIG_READER_ISO14A_106K|SYS_REG_RFCONFIG_TAG_ISO14443A_106K):
            X_PIOCapture1Deinit();
            printf("Remove Reader PIO--14A\n");
            break;
        case (SYS_REG_RFCONFIG_READER_ISO14B_106K|SYS_REG_RFCONFIG_TAG_ISO14443B_106K):
            X_PIOCapture14bDeinit();
            printf("Remove Reader PIO--14B\n");
            break; 
        case (SYS_REG_RFCONFIG_READER_FELICA_212K|SYS_REG_RFCONFIG_TAG_FELICA_212K):
            X_PIOFelica1Deinit();
            printf("Remove Reader PIO--Felica\n");
            break;
        case (SYS_REG_RFCONFIG_READER_ISO15_26K_ASK100|SYS_REG_RFCONFIG_TAG_ISO15693_26K_ASK):
        case (SYS_REG_RFCONFIG_READER_ISO15_26K_ASK10|SYS_REG_RFCONFIG_TAG_ISO15693_26K_FSK):
        case (SYS_REG_RFCONFIG_READER_ISO15_26K_ASK100|SYS_REG_RFCONFIG_TAG_ISO15693_26K_FSK):
        case (SYS_REG_RFCONFIG_READER_ISO15_26K_ASK10|SYS_REG_RFCONFIG_TAG_ISO15693_26K_ASK):
            X_PIOCapture15Deinit();
            printf("Remove Reader PIO--15\n");
            break;

        default:
            printf("Remove Unknown PIO--\n");
            break;
    }
    X_NFCFiledOff();
}

void X_RemoveTagPIO()
{
    X_NFCFiledOff();
    X_InitI2cReg();
    
    //remove pio of tag mode//////////////////////////
    switch(u16TagMode)
    {
        case SYS_REG_MODE_TAG_NTAG213:
        case SYS_REG_MODE_TAG_NTAG215:
        case SYS_REG_MODE_TAG_NTAG216:
        case SYS_REG_MODE_TAG_MIFARE1_4B1K:
        case SYS_REG_MODE_TAG_MIFARE1_4B4K:
        case SYS_REG_MODE_TAG_MIFARE1_7B1K:
        case SYS_REG_MODE_TAG_MIFARE1_7B4K:
            X_PIOCapture0filterDeinit();  //remove 14A emulator
            break;

        case SYS_REG_MODE_TAGIT_HF_I_Plus:
        case SYS_REG_MODE_TAG_ISO15:
            X_PIOCapture15filterDeinit();  //remove 15693 emulator
            break;
        case SYS_REG_MODE_TAG_CHINA_II:
            X_NFCSetRef(2048);
            X_PIOCapture14bfilterDeinit();  //remove 14B emulator
            //extern bool u8ISO14BTagEnable;
            //u8ISO14BTagEnable = false;
            break;
        default:
            break;
    }
    ///////////////////////////////////////////////////

    u16TagMode = 0;
    printf("Set to default mode\n");    
}

//run in core1
void X_HandleI2c(uint32_t swap)
{
    uint16_t regDataLen = swap & 0xFFFF;
    uint16_t regAddr = (swap >> 16) & 0xFFFF;
    uint16_t i;
    int16_t recv_len;
    uint8_t par[256], tempuid[5], tempbuf[20];
    uint32_t g;
    uint64_t tempkey;

    if (regAddr >= I2cEpromReg_Addr){  //write data to eeprom
        //printf("I2C Command: write Eprom addr: %04X length: %d\n", regAddr, regDataLen);
        for (i=0;i<regDataLen;i++) u8TagSimData[regAddr - I2cEpromReg_Addr + i] = u8I2cDataBuf[i];
    }
    else
    {
        //printf("I2C Command: write Register addr: %04X length: %d\n", regAddr, regDataLen);
        switch(regAddr)
        {
            case I2cSysReg_SetMode_Addr:
                {
                    //printf("I2C Command Mode: %04x\n", X_I2cSysReg.Mode);
                    if (X_I2cSysReg.Mode == (SYS_REG_MODE_DEFAULT|SYS_REG_MODE_TAG_NONE))
                    {
                        X_RemoveTagPIO();
                    }
                    if (  (X_I2cSysReg.Mode == (SYS_REG_MODE_DEFAULT|SYS_REG_MODE_TAG_NTAG213))
                        ||(X_I2cSysReg.Mode == (SYS_REG_MODE_DEFAULT|SYS_REG_MODE_TAG_NTAG215))
                        ||(X_I2cSysReg.Mode == (SYS_REG_MODE_DEFAULT|SYS_REG_MODE_TAG_NTAG216))
                        ||(X_I2cSysReg.Mode == (SYS_REG_MODE_DEFAULT|SYS_REG_MODE_TAG_MIFARE1_4B1K))
                        ||(X_I2cSysReg.Mode == (SYS_REG_MODE_DEFAULT|SYS_REG_MODE_TAG_MIFARE1_4B4K))
                        ||(X_I2cSysReg.Mode == (SYS_REG_MODE_DEFAULT|SYS_REG_MODE_TAG_MIFARE1_7B1K))
                        ||(X_I2cSysReg.Mode == (SYS_REG_MODE_DEFAULT|SYS_REG_MODE_TAG_MIFARE1_7B4K))
                        ||(X_I2cSysReg.Mode == (SYS_REG_MODE_DEFAULT|SYS_REG_MODE_TAGIT_HF_I_Plus)) 
                        ||(X_I2cSysReg.Mode == (SYS_REG_MODE_DEFAULT|SYS_REG_MODE_TAG_CHINA_II))
                    )
                    {
                        //printf("Emulator data from flash...\n");
                        u16TagMode = (X_I2cSysReg.Mode & 0x00FF);
                        X_FlashReadTagData(X_I2cSysReg.TagAddr);
                        X_NFCFiledOff();

                        switch(u16TagMode)
                        {
                            case SYS_REG_MODE_TAG_NTAG213:
                            case SYS_REG_MODE_TAG_NTAG215:
                            case SYS_REG_MODE_TAG_NTAG216:
                            case SYS_REG_MODE_TAG_MIFARE1_4B1K:
                            case SYS_REG_MODE_TAG_MIFARE1_4B4K:
                            case SYS_REG_MODE_TAG_MIFARE1_7B1K:
                            case SYS_REG_MODE_TAG_MIFARE1_7B4K:
                                X_NFCSetRef(4096*2/16);
                                X_PIOCapture0filterInit();  //start 14A emulator
                                break;

                            case SYS_REG_MODE_TAGIT_HF_I_Plus:
                                X_15693_info(u8TagSimData, &u8ISO15Type, &u8ISO15BlockSize, &u8ISO15BlockCount);
                                X_NFCSetRef(4096*2/16);
                                X_PIOCapture15filterInit();  //start 15693 emulator
                                break;

                            case SYS_REG_MODE_TAG_CHINA_II:
                                //extern bool u8ISO14BTagEnable;
                                //u8ISO14BTagEnable = true;  //start scan RF
                                break;

                            case SYS_REG_MODE_TAG_NONE:
                                break;

                            default:
                                break;
                        }  
                    }
                    if (  (X_I2cSysReg.Mode == (SYS_REG_MODE_FILE_TAG|SYS_REG_MODE_TAG_NTAG21X))
                        ||(X_I2cSysReg.Mode == (SYS_REG_MODE_FILE_TAG|SYS_REG_MODE_TAG_MIFARE1_4B1K))
                        ||(X_I2cSysReg.Mode == (SYS_REG_MODE_FILE_TAG|SYS_REG_MODE_TAG_MIFARE1_4B4K))
                        ||(X_I2cSysReg.Mode == (SYS_REG_MODE_FILE_TAG|SYS_REG_MODE_TAG_MIFARE1_7B1K))
                        ||(X_I2cSysReg.Mode == (SYS_REG_MODE_FILE_TAG|SYS_REG_MODE_TAG_MIFARE1_7B4K))
                        ||(X_I2cSysReg.Mode == (SYS_REG_MODE_FILE_TAG|SYS_REG_MODE_TAG_ISO15)) 
                        ||(X_I2cSysReg.Mode == (SYS_REG_MODE_FILE_TAG|SYS_REG_MODE_TAG_CHINA_II))
                    )
                    {
                        //printf("Emulator data from bin file...\n");
                        u16TagMode = (X_I2cSysReg.Mode & 0x00FF);
                        X_NFCFiledOff();

                        switch(u16TagMode)
                        {
                            case SYS_REG_MODE_TAG_NTAG21X:
                            case SYS_REG_MODE_TAG_MIFARE1_4B1K:
                            case SYS_REG_MODE_TAG_MIFARE1_4B4K:
                            case SYS_REG_MODE_TAG_MIFARE1_7B1K:
                            case SYS_REG_MODE_TAG_MIFARE1_7B4K:
                                X_NFCSetRef(4096*2/16);
                                X_PIOCapture0filterInit();  //start 14A emulator
                                break;

                            case SYS_REG_MODE_TAG_ISO15:
                                X_NFCSetRef(4096*2/16);
                                X_PIOCapture15filterInit();  //start 15693 emulator
                                break;

                            case SYS_REG_MODE_TAG_CHINA_II:
                                //extern bool u8ISO14BTagEnable;
                                //u8ISO14BTagEnable = true;  //start scan RF
                                break;

                            case SYS_REG_MODE_TAG_NONE:
                                break;

                            default:
                                break;
                        }  
                    }                
                }

                break;
            case I2cSysReg_SetTagAddr_Addr:
                //printf("I2C Command: write TagAddr reg: %04X\n", X_I2cSysReg.TagAddr);
                break;
            case I2cSysReg_SetRFConfig_Addr:
                //printf("I2C Command RFConfig: %04x\n", X_I2cSysReg.RfConfig);
                break;
            case I2cSysReg_SetFWI_Addr:
                //printf("I2C Command FWI: %04x\n", X_I2cSysReg.FWI);
                break;
            case I2cSysReg_SetTxCrcEn_Addr:
                //printf("I2C Command TxCrcEn: %04x\n", X_I2cSysReg.TxCrcEn);
                break;
            case I2cSysReg_SetRxCrcEn_Addr:
                //printf("I2C Command RxCrcEn: %04x\n", X_I2cSysReg.RxCrcEn);
                break;
            case I2cSysReg_GetNFCStatus_Addr:
                //printf("I2C Command GetNFCStatus: %04x\n", X_I2cSysReg.NFCStatus);
                break;
            //case I2cSysReg_ClrNFCStatus_Addr:
            //        X_I2cSysReg.NFCStatus = 0;
            //        break;

            case I2cMiscReg_SetRFOn_Addr:
                {
                    printf("I2C Command RFOn-RfConfig: %04x-%04x\n", X_I2cMiscReg.RFOn, X_I2cSysReg.RfConfig);
                    if ((X_I2cMiscReg.RFOn == 1) && (X_I2cSysReg.Mode == SYS_REG_MODE_READER))
                    {
                        X_AddReaderPIO();
                    }
                    else
                    {
                        X_RemoveReaderPIO();
                    }                
                }

                break;
            case I2cMiscReg_SetTxLastBit_Addr:
                //printf("I2C Command TxLastBit: %04x\n", X_I2cMiscReg.TxLastBit);
                break;
            case I2cMiscReg_SetThru_Addr:
                //printf("I2C Command Thru: %04x\n", X_I2cMiscReg.Thru);
                break;
            case I2cMiscReg_SetEGT_Addr:
                //printf("I2C Command EGT: %04x\n", X_I2cMiscReg.EGT);
                break;
            case I2cMiscReg_SetSlot_Addr:
                //printf("I2C Command Slot: %04x\n", X_I2cMiscReg.Slot);
                break;
            case I2cMiscReg_SetEpWrite_Addr:
                //printf("I2C Command EpWrite: %04x\n", X_I2cMiscReg.EpWrite);
                /*
                if (X_I2cMiscReg.EpWrite == MISC_REG_EPWRITE_WRITE){
                    //printf("write eeprom start...\n");
                    X_FlashWriteTagData(X_I2cSysReg.TagAddr);
                    //printf("write eeprom end.\n");
                }*/
                
                if (X_I2cMiscReg.EpWrite == MISC_REG_EPWRITE_READ){
                    X_FlashReadTagData(X_I2cSysReg.TagAddr);
                }
                break;
            case I2cSysReg_Shortcut_Addr:
                IOO_BUSY_ASSERT;
                X_I2cSysReg.NFCStatus = SYS_REG_NFCSTATUS_BUSY;

                switch(X_I2cSysReg.Command)
                {
                    case SYS_REG_COMMAND_NESTED:


                        X_I2cSysReg.NFCStatus = SYS_REG_NFCSTATUS_RECV_DONE;
                        IOO_BUSY_DESASSERT;
                        break;

                    case SYS_REG_COMMAND_STATICNESTED:


                        X_I2cSysReg.NFCStatus = SYS_REG_NFCSTATUS_RECV_DONE;
                        IOO_BUSY_DESASSERT;
                        break;
                    
                    case SYS_REG_COMMAND_HARDNESTED:


                        X_I2cSysReg.NFCStatus = SYS_REG_NFCSTATUS_RECV_DONE;
                        IOO_BUSY_DESASSERT;
                        break;
                    
                    case SYS_REG_COMMAND_DARKSIDE:


                        X_I2cSysReg.NFCStatus = SYS_REG_NFCSTATUS_RECV_DONE;
                        IOO_BUSY_DESASSERT;
                        break;

                    case SYS_REG_COMMAND_TAGONSNIFF:
                        X_NFCFiledOff();
                        X_I2cSysReg.Mode = SYS_REG_MODE_FILE_TAG|SYS_REG_MODE_TAG_MIFARE1_4B1K;
                        X_NFCSetRef(4096*2/16);
                        X_PIOCapture0filterInit();  //start 14A emulator
                        X_PIOCapture1Init();  //Capture Tag responce data
                        break;

                    case SYS_REG_COMMAND_TAGOFFSNIFF:
                        X_NFCFiledOff();
                        X_I2cSysReg.Mode = SYS_REG_MODE_FILE_TAG|SYS_REG_MODE_TAG_MIFARE1_4B1K;
                        X_NFCSetRef(4096*2/16);
                        X_PIOCapture0filterInit();  //start 14A emulator
                        break;

                    case SYS_REG_COMMAND_TAGOFFSNIFF_Q:
                        //X_NFCFiledOff();
                        X_I2cSysReg.Mode = SYS_REG_MODE_DEFAULT|SYS_REG_MODE_TAG_NONE;
                        //X_NFCSetRef(4096*2/16);
                        X_PIOCapture0filterDeinit();  //remove 14A emulator
                        X_I2cSysReg.NFCStatus = SYS_REG_NFCSTATUS_RECV_DONE;
                        IOO_BUSY_DESASSERT;
                        break;

                    case SYS_REG_COMMAND_TAGONSNIFF_Q:
                        //X_NFCFiledOff();
                        X_I2cSysReg.Mode = SYS_REG_MODE_DEFAULT|SYS_REG_MODE_TAG_NONE;
                        //X_NFCSetRef(4096*2/16);
                        X_PIOCapture0filterDeinit();  //remove 14A emulator
                        X_PIOCapture1Deinit();  //remove Capture Tag responce data
                        X_I2cSysReg.NFCStatus = SYS_REG_NFCSTATUS_RECV_DONE;
                        IOO_BUSY_DESASSERT;
                        break;

                    case SYS_REG_COMMAND_MFKEY32:
                        printf("Mfkey32 cracking...\n");
                        X_I2cSysReg.NFCStatus = SYS_REG_NFCSTATUS_RECV_DONE;
                        IOO_BUSY_DESASSERT;
                        break;

                    case SYS_REG_COMMAND_MFKEY32_Q:
                        printf("Quit Mfkey32\n");
                        X_I2cSysReg.NFCStatus = SYS_REG_NFCSTATUS_RECV_DONE;
                        IOO_BUSY_DESASSERT;
                        break;

                    case SYS_REG_COMMAND_MFKEY64:
                        printf("Mfkey64 cracking...\n");
                        X_I2cSysReg.NFCStatus = SYS_REG_NFCSTATUS_RECV_DONE;
                        IOO_BUSY_DESASSERT;
                        break;

                    case SYS_REG_COMMAND_MFKEY64_Q:
                        printf("Quit Mfkey64\n");
                        X_I2cSysReg.NFCStatus = SYS_REG_NFCSTATUS_RECV_DONE;
                        IOO_BUSY_DESASSERT;
                        break;

                    case SYS_REG_COMMAND_FUDAN:
                        

                        X_I2cSysReg.NFCStatus = SYS_REG_NFCSTATUS_RECV_DONE;
                        IOO_BUSY_DESASSERT;
                        break;

                    case SYS_REG_COMMAND_FUDAN_Q:
                        

                        X_I2cSysReg.NFCStatus = SYS_REG_NFCSTATUS_RECV_DONE;
                        IOO_BUSY_DESASSERT;
                        break;

                    case SYS_REG_COMMAND_STATICNESTED_CRACK:

                        X_I2cSysReg.NFCStatus = SYS_REG_NFCSTATUS_RECV_DONE;
                        IOO_BUSY_DESASSERT;
                        break;

                    case SYS_REG_COMMAND_PN532KILLER:

                        break;
                }
                break;

            case I2cDataReg_Addr:
                IOO_BUSY_ASSERT;
                X_I2cSysReg.NFCStatus = SYS_REG_NFCSTATUS_BUSY;
                //printf("I2C Command Data: %d bytes FWI: %04X\n", regDataLen, X_I2cSysReg.FWI);
                
                if (X_I2cSysReg.Mode == SYS_REG_MODE_READER)
                {
                    switch(X_I2cSysReg.RfConfig)
                    {
                        case (SYS_REG_RFCONFIG_READER_ISO14A_106K|SYS_REG_RFCONFIG_TAG_ISO14443A_106K):
                            if (X_I2cSysReg.TxCrcEn & SYS_REG_TXCRCEN_14A_ENABLE)
                            {
                                uint8_t recv_nbit;
                                if (X_I2cSysReg.RxCrcEn & 0xFF00)   recv_nbit = 8;
                                else recv_nbit = 9;
                                AppendCrcA(u8I2cDataBuf, regDataLen);
                                regDataLen += 2;
                                for (i=0;i<regDataLen;i++) par[i] = oddparity(u8I2cDataBuf[i]);
                                RF14443A_Reader_SendData(u8I2cDataBuf, par, 1, regDataLen,  X_I2cMiscReg.TxLastBit);
                                //recv_len = RF14443A_Reader_RecvData(u8I2cDataBuf, 9, 0, 18);//X_I2cSysReg.FWI 
                                //recv_len = RF14443A_Reader_RecvData(u8I2cDataBuf, recv_nbit, 0, 2000);
                                recv_len = RF14443A_Reader_RecvData(u8I2cDataBuf, recv_nbit, 0, X_I2cSysReg.FWI + 9);

                                if(recv_len > 0)  //3, SAK+CRC
                                {
                                    //printf("Received from tag, length: %d %02X\n", recv_len, u8I2cDataBuf[0]);
                                    if (X_I2cSysReg.RxCrcEn & SYS_REG_RXCRCEN_14A_ENABLE)
                                    {
                                        if (HasValidCrcA(u8I2cDataBuf, recv_len))
                                        {
                                            //printf("SAK: %02x\n", u8I2cDataBuf[0]);
                                            X_I2cSysReg.NFCStatus = SYS_REG_NFCSTATUS_RECV_DONE;
                                            X_I2cSysReg.RxLen = recv_len-2;  //exclude CRC
                                        }
                                        else
                                        {
                                            //printf("CRC error\n");
                                            X_I2cSysReg.NFCStatus = SYS_REG_NFCSTATUS_RECV_CRCERR;
                                            X_I2cSysReg.RxLen = recv_len;
                                        }                                        
                                    }
                                    else
                                    {
                                        X_I2cSysReg.NFCStatus = SYS_REG_NFCSTATUS_RECV_DONE;
                                        X_I2cSysReg.RxLen = recv_len;    
                                    }
                                }
                                else if (recv_len = -1)
                                {
                                    X_I2cSysReg.NFCStatus = SYS_REG_NFCSTATUS_RECV_NORESP;
                                    X_I2cSysReg.RxLen = 0;
                                }
                                else
                                {
                                    X_I2cSysReg.NFCStatus = SYS_REG_NFCSTATUS_RECV_TIMEOUT;
                                    X_I2cSysReg.RxLen = 0;
                                }
                            }
                            else
                            {
                                if (regDataLen == 1)  //for WUPA/REQA, which has no CRC, and the length is determined by TxLastBit register
                                {
                                    RF14443A_Reader_SendData(u8I2cDataBuf, NULL, 0, regDataLen, X_I2cMiscReg.TxLastBit); 
                                    recv_len = RF14443A_Reader_RecvData(u8I2cDataBuf, 9, 0, 18); 
                                    if(recv_len == 2)
                                    {
                                        //printf("WUPA-ATQA: %02x %02x \n",u8I2cDataBuf[0],u8I2cDataBuf[1]);  //0400
                                        X_I2cSysReg.NFCStatus = SYS_REG_NFCSTATUS_RECV_DONE;
                                        X_I2cSysReg.RxLen = recv_len;
                                    }
                                    else
                                    {
                                        X_I2cSysReg.NFCStatus = SYS_REG_NFCSTATUS_RECV_TIMEOUT;
                                        X_I2cSysReg.RxLen = 0;
                                    }
                                }
                                else
                                {
                                    for (i=0;i<regDataLen;i++) par[i] = oddparity(u8I2cDataBuf[i]);
                                    RF14443A_Reader_SendData(u8I2cDataBuf, par, 1, regDataLen, X_I2cMiscReg.TxLastBit); 
                                    recv_len = RF14443A_Reader_RecvData(u8I2cDataBuf, 9, 0, 18); 
                                    if(recv_len > 0)
                                    {
                                        //printf("Received from tag, length: %d\n", recv_len);
                                        X_I2cSysReg.NFCStatus = SYS_REG_NFCSTATUS_RECV_DONE;
                                        X_I2cSysReg.RxLen = recv_len;
                                    }
                                    else
                                    {
                                        X_I2cSysReg.NFCStatus = SYS_REG_NFCSTATUS_RECV_TIMEOUT;
                                        X_I2cSysReg.RxLen = 0;
                                    }
                                }
                            }
                            break;

                        case (SYS_REG_RFCONFIG_READER_ISO14B_106K|SYS_REG_RFCONFIG_TAG_ISO14443B_106K):
                            if (X_I2cSysReg.TxCrcEn & SYS_REG_TXCRCEN_14B_ENABLE)
                            {
                                AppendCrcB(u8I2cDataBuf, regDataLen);
                                regDataLen += 2;
                                RF14443B_Reader_SendData(u8I2cDataBuf, regDataLen, X_I2cMiscReg.EGT);
                                recv_len = RF14443B_Reader_RecvData(u8I2cDataBuf,  X_I2cSysReg.FWI);
                                if(recv_len > 0)
                                {
                                    if (HasValidCrcB(u8I2cDataBuf, recv_len))
                                    {
                                        //printf("Received from tag, length(exclude CRC): %d\n", recv_len-2);  //exclude CRC
                                        X_I2cSysReg.NFCStatus = SYS_REG_NFCSTATUS_RECV_DONE;
                                        X_I2cSysReg.RxLen = recv_len-2;  //exclude CRC
                                    }
                                    else
                                    {
                                        //printf("CRC error\n");
                                        X_I2cSysReg.NFCStatus = SYS_REG_NFCSTATUS_RECV_CRCERR;
                                        X_I2cSysReg.RxLen = recv_len;
                                    }
                                }
                                else
                                {
                                    X_I2cSysReg.NFCStatus = SYS_REG_NFCSTATUS_RECV_TIMEOUT;
                                    X_I2cSysReg.RxLen = 0;
                                }
                            }
                            else
                            {
                                RF14443B_Reader_SendData(u8I2cDataBuf, regDataLen, X_I2cMiscReg.EGT);
                                recv_len = RF14443B_Reader_RecvData(u8I2cDataBuf,  X_I2cSysReg.FWI);
                                if(recv_len > 0)
                                {
                                    //printf("Received from tag, length: %d\n", recv_len);
                                    X_I2cSysReg.NFCStatus = SYS_REG_NFCSTATUS_RECV_DONE;
                                    X_I2cSysReg.RxLen = recv_len;
                                }
                                else
                                {
                                    X_I2cSysReg.NFCStatus = SYS_REG_NFCSTATUS_RECV_TIMEOUT;
                                    X_I2cSysReg.RxLen = 0;
                                }
                            }
                            break; 

                        case (SYS_REG_RFCONFIG_READER_FELICA_212K|SYS_REG_RFCONFIG_TAG_FELICA_212K):
                            if (X_I2cSysReg.TxCrcEn & SYS_REG_TXCRCEN_FELICA_ENABLE)
                            {
                                AppendCrcF(u8I2cDataBuf, regDataLen);
                                regDataLen += 2;
                                FELICA_Reader_SendData(u8I2cDataBuf, regDataLen, 0);
                                recv_len = FELICA_Reader_RecvData(u8I2cDataBuf, X_I2cMiscReg.Slot, 0);
                                if(recv_len > 2)
                                {
                                    if ((u8I2cDataBuf[0]==0xB2)&&(u8I2cDataBuf[1]==0x4D))  //remove sync code B2 4D
                                    {
                                        memmove(u8I2cDataBuf, u8I2cDataBuf + 2, recv_len - 2);
                                        recv_len = recv_len - 2;
                                        if (HasValidCrcF(u8I2cDataBuf, recv_len))
                                        {
                                            //printf("Received from tag, length(exclude CRC): %d\n", recv_len-2);  //exclude CRC
                                            X_I2cSysReg.NFCStatus = SYS_REG_NFCSTATUS_RECV_DONE;
                                            X_I2cSysReg.RxLen = recv_len-2;  //exclude CRC
                                        }
                                        else
                                        {
                                            //printf("CRC error\n");
                                            X_I2cSysReg.NFCStatus = SYS_REG_NFCSTATUS_RECV_CRCERR;
                                            X_I2cSysReg.RxLen = recv_len;
                                        }                                  
                                    }
                                    else{
                                            //printf("Sync code error\n");
                                            X_I2cSysReg.NFCStatus = SYS_REG_NFCSTATUS_RECV_BITERR;
                                            X_I2cSysReg.RxLen = recv_len;
                                    }
                                }
                                else
                                { 
                                    X_I2cSysReg.NFCStatus = SYS_REG_NFCSTATUS_RECV_TIMEOUT;
                                    X_I2cSysReg.RxLen = 0;
                                }
                            }
                            else
                            {
                                FELICA_Reader_SendData(u8I2cDataBuf, regDataLen, 0);
                                recv_len = FELICA_Reader_RecvData(u8I2cDataBuf, 0, 0);
                                if(recv_len > 0)
                                {
                                    //printf("Received from tag, length: %d\n", recv_len);
                                    X_I2cSysReg.NFCStatus = SYS_REG_NFCSTATUS_RECV_DONE;
                                    X_I2cSysReg.RxLen = recv_len;
                                }
                                else
                                {
                                    X_I2cSysReg.NFCStatus = SYS_REG_NFCSTATUS_RECV_TIMEOUT;
                                    X_I2cSysReg.RxLen = 0;
                                }
                            }
                            break;
                        
                        case (SYS_REG_RFCONFIG_READER_ISO15_26K_ASK100|SYS_REG_RFCONFIG_TAG_ISO15693_26K_ASK):
                        case (SYS_REG_RFCONFIG_READER_ISO15_26K_ASK10|SYS_REG_RFCONFIG_TAG_ISO15693_26K_FSK):
                        case (SYS_REG_RFCONFIG_READER_ISO15_26K_ASK100|SYS_REG_RFCONFIG_TAG_ISO15693_26K_FSK):
                        case (SYS_REG_RFCONFIG_READER_ISO15_26K_ASK10|SYS_REG_RFCONFIG_TAG_ISO15693_26K_ASK):
                            if (X_I2cSysReg.TxCrcEn & SYS_REG_TXCRCEN_ISO15_ENABLE)
                            {
                                AppendCrcV(u8I2cDataBuf, regDataLen);
                                regDataLen += 2;
                                RF15693_Reader_SendData(u8I2cDataBuf, regDataLen, 0);
                                recv_len = RF15693_Reader_RecvData(u8I2cDataBuf, 0);
                                if(recv_len > 0)
                                {
                                    if (HasValidCrcV(u8I2cDataBuf, recv_len))
                                    {
                                        //printf("Received from tag, length(exclude CRC): %d\n", recv_len-2);  //exclude CRC
                                        X_I2cSysReg.NFCStatus = SYS_REG_NFCSTATUS_RECV_DONE;
                                        X_I2cSysReg.RxLen = recv_len-2;  //exclude CRC
                                    }
                                    else
                                    {
                                        //printf("CRC error\n");
                                        X_I2cSysReg.NFCStatus = SYS_REG_NFCSTATUS_RECV_CRCERR;
                                        X_I2cSysReg.RxLen = recv_len;
                                    }
                                }
                                else
                                {
                                    X_I2cSysReg.NFCStatus = SYS_REG_NFCSTATUS_RECV_TIMEOUT;
                                    X_I2cSysReg.RxLen = 0;
                                }
                            }
                            else
                            {
                                if (X_I2cSysReg.TxCrcEn & (1<<8))
                                {
		                            RF15693_Carrier_On_Delay(2560); //wait >20ms to send EOF, unit 9.44us
                                    RF15693_Reader_SendEOF();  //Note: it delay 4*9.44us
		                            recv_len = RF15693_Reader_RecvData(u8I2cDataBuf, 0);
                                    if(recv_len > 0)
                                    {
                                        //printf("Received from tag, length: %d\n", recv_len);
                                        X_I2cSysReg.NFCStatus = SYS_REG_NFCSTATUS_RECV_DONE;
                                        X_I2cSysReg.RxLen = recv_len;
                                    }
                                    else
                                    {
                                        X_I2cSysReg.NFCStatus = SYS_REG_NFCSTATUS_RECV_TIMEOUT;
                                        X_I2cSysReg.RxLen = 0;
                                    } 
                                }
                                else
                                {
                                    RF15693_Reader_SendData(u8I2cDataBuf, regDataLen, 0);
                                    recv_len = RF15693_Reader_RecvData(u8I2cDataBuf, 0);
                                    if(recv_len > 0)
                                    {
                                        //printf("Received from tag, length: %d\n", recv_len);
                                        X_I2cSysReg.NFCStatus = SYS_REG_NFCSTATUS_RECV_DONE;
                                        X_I2cSysReg.RxLen = recv_len;
                                    }
                                    else
                                    {
                                        X_I2cSysReg.NFCStatus = SYS_REG_NFCSTATUS_RECV_TIMEOUT;
                                        X_I2cSysReg.RxLen = 0;
                                    }                                    
                                }
                            }                        
                            break;

                        default:
                            break;
                    }
                    IOO_BUSY_DESASSERT;
                }
                
                else if(X_I2cSysReg.Mode == SYS_REG_MODE_MIFARE1_READER)
                {
                    switch(u8I2cDataBuf[0])  //command code
                    {
                        default:
                            printf("Unknown Mifare command: %02x\n", u8I2cDataBuf[0]);
                            break;
                    }
                    IOO_BUSY_DESASSERT;
                }
                
                break;

            default:
                printf("I2C Command: write unknown reg 0x%04x, length: %d\n", regAddr, regDataLen);
                IOO_BUSY_DESASSERT;
                break;
        }
    }

}