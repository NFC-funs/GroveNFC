#ifndef     __X_NTAG_H__
#define     __X_NTAG_H__

//#define NTAG_DATA_FROM_CONST  //const uint8_t Ntag215_Data[], else from flash

int __not_in_flash_func(Ntag_Emul)(uint16_t len);

#endif