#ifndef     __X_ISO14A_APP_H__
#define     __X_ISO14A_APP_H__

extern uint8_t gISO14A_Atqa[2];
extern uint8_t gISO14A_Sak;
extern uint8_t gISO14A_Uid[10];  //include bbc //10-7B [5];//-4B

uint16_t X_RF14443A_Reqa(void);  //return atqa--b[16:1]
uint8_t X_RF14443A_AntiCL1(uint8_t *CardNo);
uint8_t X_RF14443A_AntiCL2(uint8_t *CardNo);
uint8_t X_RF14443A_SelCL1(uint8_t *CardNo);
uint8_t X_RF14443A_SelCL2(uint8_t *CardNo);
uint8_t X_RF14443A_GetUid(uint8_t *CardNo);

#endif
