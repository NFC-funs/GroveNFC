#include <stdio.h>
#include <string.h>
#include <stdint.h>

#include "libNFC/X_Core0.h"
#include "libNFC/ISO15/X_15693_HW.h"
#include "X_ISO15_App.h"

#define CHECK_VALUE  0x0F47//0xF0B8

uint8_t gISO15_Uid[8];

void X_15693_info(uint8_t *uid15693, uint8_t *type, uint8_t *blocksize, uint8_t *blockcount)
{
            if ( (uid15693[7] == 0xE0) && (uid15693[6] == 0x07) && (uid15693[5] == 0x00) )  //Plus
            {
                printf("Tag-it HF-I PLUS 1\n");
                *blockcount = 0x3F;
				*blocksize = 4;
				*type = 1;
			}
            else if ( (uid15693[7] == 0xE0) && (uid15693[6] == 0x07) && (uid15693[5] == 0x01) ) //Plus
            {
                printf("Tag-it HF-I PLUS 2\n");
                *blockcount = 0x3F;
				*blocksize = 4;
				*type = 1;
            }
            else if ( (uid15693[7] == 0xE0) && (uid15693[6] == 0x07) && (uid15693[5] == 0x80) )  //Plus (RF-HDT-DVBB tag or Third Party Products)
            {
                printf("Tag-it HF-I PLUS 3\n");
                *blockcount = 0x1B;
				*blocksize = 4;
				*type = 2;
            }
            else if ( (uid15693[7] == 0xE0) && (uid15693[6] == 0x07) && (uid15693[5] == 0x81) )  //Plus (RF-HDT-DVBB tag or Third Party Products)
            {
                printf("Tag-it HF-I PLUS 4\n");
                *blockcount = 0x3F;
				*blocksize = 4;
				*type = 3;
			}
            else if ( (uid15693[7] == 0xE0) && (uid15693[6] == 0x07) && (uid15693[5] == 0xC0) )  //standard IC
            {
                printf("Tag-it HF-I PLUS 5\n");
                *blockcount = 0x07;
				*blocksize = 4;
				*type = 4;
            }
            else if ( (uid15693[7] == 0xE0) && (uid15693[6] == 0x07) && (uid15693[5] == 0xC1) )  //standard IC
            {
                printf("Tag-it HF-I PLUS 6\n");
                *blockcount = 0x07;
				*blocksize = 4;
				*type = 4;
            }
            else if ( (uid15693[7] == 0xE0) && (uid15693[6] == 0x07) && (uid15693[5] == 0xC4) )  //Pro IC
            {
                printf("Tag-it HF-I PLUS 7\n");
                *blockcount = 0x07;
				*blocksize = 4;
				*type = 4;
			}
            else if ( (uid15693[7] == 0xE0) && (uid15693[6] == 0x07) && (uid15693[5] == 0xC5) )  //Pro IC
            {
                printf("Tag-it HF-I PLUS 8\n");
                *blockcount = 0x07;
				*blocksize = 4;
				*type = 4;
			}
            else if ( (uid15693[7] == 0xE0) && (uid15693[6] == 0x04) && (uid15693[5] == 0x01)  && ((uid15693[4]&0x18) == 0x08))
            {
                printf("ICODE SLIX2     \n");
                *blockcount = 0x4F;
				*blocksize = 4;
				*type = 5;
			}
            else if ( (uid15693[7] == 0xE0) && (uid15693[6] == 0x04) && (uid15693[5] == 0x01)  && ((uid15693[4]&0x18) == 0x10))
            {
                printf("ICODE SLIX      \n");
                *blockcount = 0x1B;
				*blocksize = 4;
				*type = 6;
            }
            else if ( (uid15693[7] == 0xE0) && (uid15693[6] == 0x04) && (uid15693[5] == 0x01)  && ((uid15693[4]&0x18) == 0x00))
            {
                printf("ICODE SLI       \n");
                *blockcount = 0x1B;
				*blocksize = 4;
				*type = 6;
			}
            else if ( (uid15693[7] == 0xE0) && (uid15693[6] == 0x04) && (uid15693[5] == 0x01))
            {
                printf("ICODE SLI       \n");
                *blockcount = 0x1B;
				*blocksize = 4;
				*type = 6;
			}
            else if ( (uid15693[7] == 0xE0) && (uid15693[6] == 0x04) && (uid15693[5] == 0x03) )
            {
                printf("ICODE SLIX-L    \n");
                *blockcount = 0x07;
				*blocksize = 4;
				*type = 7;
                /*
				//pricapy mode
                if (uid15693[50] == 0x04)
                {
                    if ((uid15693[48]^uid15693[49]^uid15693[50]) == uid15693[51])   u8PasswordMode = 0x04;
                }
				*/
            }
            else if ( (uid15693[7] == 0xE0) && (uid15693[6] == 0x02) )
            {
                printf("LRI2K           \n");
                *blockcount = 0x3F;
				*blocksize = 4;
				*type = 8;
			}
            else
            {
                printf("Unknown Type    \n");
                *blockcount = 0x1B;
                *blocksize = 4;
                *type = 0xFF;
            }

}
////////////////////////////////////////////////////////////////
#define ISO15_READER
#ifdef ISO15_READER

	int16_t X_15693_getuid(uint8_t *uid15693, uint8_t mode)
	{
		uint8_t u8ArrayGetID[5] = {0x26,ISO15693_INVENTORY,0x00,0x00,0x00};//read id
		uint8_t u8RecvData[32];

		uint8_t  i;
		uint16_t crc;
		int16_t recv_len;

		if (mode&0x01) u8ArrayGetID[0]=0x27;  //FSK

		AppendCrcV(u8ArrayGetID, 3);

		if (mode&0x01)printf("15693FSK read uid: %02x %02x %02x %02x %02x\n", u8ArrayGetID[0], u8ArrayGetID[1], u8ArrayGetID[2], u8ArrayGetID[3], u8ArrayGetID[4]);
		else printf("15693ASK read uid: %02x %02x %02x %02x %02x\n", u8ArrayGetID[0], u8ArrayGetID[1], u8ArrayGetID[2], u8ArrayGetID[3], u8ArrayGetID[4]);

		RF15693_Reader_SendData(u8ArrayGetID, 5, mode);

		{
			recv_len = RF15693_Reader_RecvData(u8RecvData, mode);

			printf("15693 recv len: %d\n",recv_len);

			if (recv_len > 0)
			{
				for (i=0;i<recv_len;i++){
					printf("%02x ", u8RecvData[i]);
				}
				if (HasValidCrcV(u8RecvData, recv_len)){	 //uid15693[0]=0xE0 PS-20230318
					uid15693[0] = u8RecvData[9];
					uid15693[1] = u8RecvData[8];
					uid15693[2] = u8RecvData[7];
					uid15693[3] = u8RecvData[6];
					uid15693[4] = u8RecvData[5];
					uid15693[5] = u8RecvData[4];
					uid15693[6] = u8RecvData[3];
					uid15693[7] = u8RecvData[2];
					printf("crc ok\n");	
				} 
				else printf("crc error\n");
			}			
		}

		return recv_len;
	}

	int16_t X_15693_readsingleblock(uint8_t *uid15693, uint8_t block, uint8_t *data15693, uint8_t mode)
	{
		uint8_t u8ArrayRead[13] = {0x22,ISO15693_READBLOCK,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};//block-[10]
		uint8_t u8RecvData[32];

		uint8_t  i;
		uint16_t crc;
		int16_t recv_len;

		for (i=0;i<8;i++) u8ArrayRead[i+2] = uid15693[7-i]; //u815693IDArray[0]=0xE0 PS-20230318
		u8ArrayRead[10] = block;

		AppendCrcV(u8ArrayRead, 11);

		RF15693_Reader_SendData(u8ArrayRead, 13, mode);
		recv_len = RF15693_Reader_RecvData(u8RecvData, mode);

		printf("15693 recv len: %d\n",recv_len);

		if (recv_len > 0)
		{
			for (i=0;i<recv_len;i++){
				printf("%02x ", u8RecvData[i]);
			}
			if (HasValidCrcV(u8RecvData, recv_len)) printf("crc ok\n");
			else printf("crc error\n");
		}

		return recv_len;
	}

	int16_t X_15693_writesingleblock(uint8_t *uid15693, uint8_t block, uint8_t *data15693, uint8_t mode)
	{
		uint8_t u8ArrayWriteSingleBlock[17] = { 0x62,ISO15693_WRITEBLOCK,  //62--Ti 42--NXP
												0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,  //UID
												0x08,  //Block Address
												0x01,0x02,0x03,0x04,  //Data
												0x00,0x00};//
		uint8_t u8RecvData[32];

		uint8_t  i;
		uint16_t j;
		uint16_t crc;
		int16_t recv_len;

		for (i=0;i<8;i++) u8ArrayWriteSingleBlock[i+2] = uid15693[7-i]; //u815693IDArray[0]=0xE0 PS-20230318

		u8ArrayWriteSingleBlock[10] = block;

		u8ArrayWriteSingleBlock[11] = data15693[0];
		u8ArrayWriteSingleBlock[12] = data15693[1];
		u8ArrayWriteSingleBlock[13] = data15693[2];
		u8ArrayWriteSingleBlock[14] = data15693[3];

		AppendCrcV(u8ArrayWriteSingleBlock, 15);

		RF15693_Reader_SendData(u8ArrayWriteSingleBlock, 17, mode);

		//wait >20ms to send EOF, unit 9.44us
		RF15693_Carrier_On_Delay(2560);
		RF15693_Reader_SendEOF();  //Note: it delay 4*9.44us
		
		recv_len = RF15693_Reader_RecvData(u8RecvData, mode);

		printf("15693 recv len: %d\n",recv_len);

		if (recv_len > 0)
		{
			for (i=0;i<recv_len;i++){
				printf("%02x ", u8RecvData[i]);
			}
			if (HasValidCrcV(u8RecvData, recv_len)) printf("crc ok\n");
			else printf("crc error\n");
		}

		return recv_len;
	}

	int16_t X_15693_readmultiblock(uint8_t *uid15693, uint8_t block, uint8_t number, uint8_t *data15693, uint8_t mode)
	{
		uint8_t u8ArrayRead[14] = {0x22,ISO15693_READ_MULTI_BLOCK,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};//read block 10
		uint8_t u8RecvData[32];

		uint8_t  i;
		uint16_t crc;
		int16_t recv_len;

		for (i=0;i<8;i++) u8ArrayRead[i+2] = uid15693[7-i]; //u815693IDArray[0]=0xE0 PS-20230318
		u8ArrayRead[10] = block;
		u8ArrayRead[11] = number;

		AppendCrcV(u8ArrayRead, 12);

		RF15693_Reader_SendData(u8ArrayRead, 14, mode);
		recv_len = RF15693_Reader_RecvData(u8RecvData, mode);

		printf("15693 recv len: %d\n",recv_len);

		if (recv_len > 0)
		{
			for (i=0;i<recv_len;i++){
				printf("%02x ", u8RecvData[i]);
			}
			if (HasValidCrcV(u8RecvData, recv_len)) printf("crc ok\n");
			else printf("crc error\n");
		}

		return recv_len;
	}

		//chinese magic uid  PS-20230223
		#define ISO15693_WRITEBLOCK                  0x21
		#define ISO15693_REQ_DATARATE_HIGH           (1<<1)
	
		uint8_t u815693MagicArray[4][9]={
			{ISO15693_REQ_DATARATE_HIGH, ISO15693_WRITEBLOCK, 0x3e, 0x00, 0x00, 0x00, 0x00, 0, 0},  //wait 380us, rsp 01 10 1e 06
			{ISO15693_REQ_DATARATE_HIGH, ISO15693_WRITEBLOCK, 0x3f, 0x69, 0x96, 0x00, 0x00, 0, 0},  //wait 380us, rsp 01 10 1e 06
			{ISO15693_REQ_DATARATE_HIGH, ISO15693_WRITEBLOCK, 0x38, 0x08, 0x07, 0x06, 0x05, 0, 0},  //wait 3.7ms, 00 78 f0
			{ISO15693_REQ_DATARATE_HIGH, ISO15693_WRITEBLOCK, 0x39, 0x04, 0x22, 0x02, 0xE0, 0, 0}  //0xE0--15693//wait 3.7ms, 00 78 f0
			};
		int16_t X_15693_magicuid(uint8_t *uid15693, uint8_t mode)
		{
			uint8_t u8ArrayMagicID[9] = {0x00};//magic id
			uint8_t u8RecvData[32];
	
			uint8_t  i, j;
			uint16_t k;
			uint16_t crc;
			int16_t recv_len;
	
			for(i=0;i<4;i++){
				for(j=0;j<7;j++) u8ArrayMagicID[j] = u815693MagicArray[i][j];
				
				AppendCrcV(u8ArrayMagicID, 7);

				RF15693_Reader_SendData(u8ArrayMagicID, 9, mode);
				
				recv_len = RF15693_Reader_RecvData(u8RecvData, mode);
	
				printf("15693 magicuid recv len: %d\n",recv_len);
	
				if (recv_len > 0)
				{
					for (k=0;k<recv_len;k++){
						printf("%02x ", u8RecvData[k]);
					}
					if (HasValidCrcV(u8RecvData, recv_len)) printf("crc ok\n");
					else{
						printf("crc error step %d\n", i);
						return -2;	
					} 
				}
				else{
					printf("recv error step %d\n", i);
					return -1;		
				}
			}

			return 0;
		}
#endif
/////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////
#define RF15693_TAG
#ifdef RF15693_TAG


	//0E-07-00
	const uint8_t ISO15_Sim_Data[] = {
		//UID
		0xC1, 0xC6, 0x02, 0xB9,
		0x50, 0x00, 0x07, 0xE0,
		//Resv-EAS-AFI-DSFID
		0x00, 0x00, 0x00, 0x00,
		//write protect
		0x00, 0x00, 0x00, 0x00,
		//data 0-63(3F)
		0x00, 0x00, 0x00, 0x00,
		0x01, 0x01, 0x01, 0x01,
		0x02, 0x02, 0x02, 0x02,
		0x03, 0x03, 0x03, 0x03,
		0x04, 0x04, 0x04, 0x04,
		0x05, 0x05, 0x05, 0x05,
		0x06, 0x06, 0x06, 0x06,
		0x07, 0x07, 0x07, 0x07,
		0x08, 0x08, 0x08, 0x08,
		0x09, 0x09, 0x09, 0x09,
		0x0A, 0x0A, 0x0A, 0x0A,
		0x0B, 0x0B, 0x0B, 0x0B,
		0x0C, 0x0C, 0x0C, 0x0C,
		0x0D, 0x0D, 0x0D, 0x0D,
		0x0E, 0x0E, 0x0E, 0x0E,
		0x0F, 0x0F, 0x0F, 0x0F,
		0x10, 0x10, 0x10, 0x10,
		0x11, 0x11, 0x11, 0x11,
		0x12, 0x12, 0x12, 0x12,
		0x13, 0x13, 0x13, 0x13,
		0x14, 0x14, 0x14, 0x14,
		0x15, 0x15, 0x15, 0x15,
		0x16, 0x16, 0x16, 0x16,
		0x17, 0x17, 0x17, 0x17,
		0x18, 0x18, 0x18, 0x18,
		0x19, 0x19, 0x19, 0x19,
		0x1A, 0x1A, 0x1A, 0x1A,
		0x1B, 0x1B, 0x1B, 0x1B,
		0x1C, 0x1C, 0x1C, 0x1C,
		0x1D, 0x1D, 0x1D, 0x1D,
		0x1E, 0x1E, 0x1E, 0x1E,
		0x1F, 0x1F, 0x1F, 0x1F,
		0x20, 0x20, 0x20, 0x20,
		0x21, 0x21, 0x21, 0x21,
		0x22, 0x22, 0x22, 0x22,
		0x23, 0x23, 0x23, 0x23,
		0x24, 0x24, 0x24, 0x24,
		0x25, 0x25, 0x25, 0x25,
		0x26, 0x26, 0x26, 0x26,
		0x27, 0x27, 0x27, 0x27,
		0x28, 0x28, 0x28, 0x28,
		0x29, 0x29, 0x29, 0x29,
		0x2A, 0x2A, 0x2A, 0x2A,
		0x2B, 0x2B, 0x2B, 0x2B,
		0x2C, 0x2C, 0x2C, 0x2C,
		0x2D, 0x2D, 0x2D, 0x2D,
		0x2E, 0x2E, 0x2E, 0x2E,
		0x2F, 0x2F, 0x2F, 0x2F,
		0x30, 0x30, 0x30, 0x30,
		0x31, 0x31, 0x31, 0x31,
		0x32, 0x32, 0x32, 0x32,
		0x33, 0x33, 0x33, 0x33,
		0x34, 0x34, 0x34, 0x34,
		0x35, 0x35, 0x35, 0x35,
		0x36, 0x36, 0x36, 0x36,
		0x37, 0x37, 0x37, 0x37,
		0x38, 0x38, 0x38, 0x38,
		0x39, 0x39, 0x39, 0x39,
		0x3A, 0x3A, 0x3A, 0x3A,
		0x3B, 0x3B, 0x3B, 0x3B,
		0x3C, 0x3C, 0x3C, 0x3C,
		0x3D, 0x3D, 0x3D, 0x3D,
		0x3E, 0x3E, 0x3E, 0x3E,
		0x3F, 0x3F, 0x3F, 0x3F
		};

	extern uint8_t u8TagRecvCmd[];
	extern uint8_t u8TagSimData[];

	uint8_t u8ISO15BlockCount = 0x3F;  //64-1
	uint8_t u8ISO15BlockSize = 4;	 //
	uint8_t u8ISO15Type = 0xFF;  //unknown

	int __not_in_flash_func(X_15693_Tag_Emul)(uint16_t len)
	{
		//printf("15693 Tag Emul: %d", len);
		uint16_t crc;
		uint8_t resp[256];
		uint16_t i,resplen;
		uint8_t address_offset, block_idx, block_count, security_offset, work_offset;

		if ( crc16_V(u8TagRecvCmd, len) == CHECK_VALUE )
		{
			switch(u8TagRecvCmd[1])
			{
				case ISO15693_INVENTORY:
					//if ( u8CmdVcd2Vicc[0] == (ISO15_REQ_INVENTORY|ISO15_REQ_DATARATE_HIGH|ISO15_REQINV_SLOT1) ) //0x26
					if ( (u8TagRecvCmd[0] & (ISO15_REQ_INVENTORY|ISO15_REQ_DATARATE_HIGH|ISO15_REQINV_SLOT1)) == 0x26)//0x26
					{
						resp[0] = 0; // No error, no protocol format extension
						resp[1] = 0; // DSFID (data storage format identifier).  0x00 = not supported
						#ifdef ISO15TAG_DATA_FROM_CONST
						memcpy(u8TagSimData, ISO15_Sim_Data, sizeof(ISO15_Sim_Data));
						#endif
						//64-bit UID--Ti--NXP
						resp[2] = u8TagSimData[0];//0xEE;//0x6A;//uid[7];
						resp[3] = u8TagSimData[1];//0xBC;//0xC4;//uid[6];
						resp[4] = u8TagSimData[2];//0xCE;//0x02;//uid[5];
						resp[5] = u8TagSimData[3];//0x20;//0xB9;//uid[4];
						resp[6] = u8TagSimData[4];//0x00;//0x50;//uid[3];
						resp[7] = u8TagSimData[5];//0x00;//0x01;//uid[2];
						resp[8] = u8TagSimData[6];//0x07;//0x04;//uid[1];
						resp[9] = u8TagSimData[7];//0xE0;//0xE0;//uid[0];

						AppendCrcV(resp, 10);
						X_15693_Tag_SendData(resp, 12, u8TagRecvCmd[0]&0x01);
					}
					break;

				case ISO15693_GET_SYSTEM_INFO:
					{
						resp[0] = 0;    // Response flags.
						resp[1] = 0x0F; // Information flags (0x0F - DSFID, AFI, Mem size, IC)

						//64-bit UID--Ti--NXP
						resp[2] = u8TagSimData[0];//0xEE;//0x6A;//uid[7];
						resp[3] = u8TagSimData[1];//0xBC;//0xC4;//uid[6];
						resp[4] = u8TagSimData[2];//0xCE;//0x02;//uid[5];
						resp[5] = u8TagSimData[3];//0x20;//0xB9;//uid[4];
						resp[6] = u8TagSimData[4];//0x00;//0x50;//uid[3];
						resp[7] = u8TagSimData[5];//0x00;//0x01;//uid[2];
						resp[8] = u8TagSimData[6];//0x07;//0x04;//uid[1];
						resp[9] = u8TagSimData[7];//0xE0;//0xE0;//uid[0];

						resp[10] = u8TagSimData[11];//0;    // DSFID
						resp[11] = u8TagSimData[10];//0;    // AFI

						resp[12] = u8ISO15BlockCount;  //0x3F;  // Block count, ic type, PS-20250203

						resp[13] = u8ISO15BlockSize - 1; // Block size.
						resp[14] = 0x01; // IC reference.

						AppendCrcV(resp, 15);

						X_15693_Tag_SendData(resp, 17, u8TagRecvCmd[0]&0x01);
					}
					break;

				case ISO15693_READBLOCK:
				case ISO15693_READ_MULTI_BLOCK:
					{
						address_offset = 0;

						if (u8TagRecvCmd[0] & ISO15_REQ_ADDRESS){
							address_offset = 8;
						}

						block_idx = u8TagRecvCmd[2 + address_offset];
						block_count = 1;

						if (u8TagRecvCmd[1] == ISO15693_READ_MULTI_BLOCK) {
							block_count = u8TagRecvCmd[3 + address_offset] + 1;
						}

						// Build READ_(MULTI_)BLOCK response
						resplen = 1 + u8ISO15BlockSize * block_count;
						security_offset = 0;

						if (u8TagRecvCmd[0] & ISO15_REQ_OPTION) {
							resplen += block_count;
							security_offset = 1;
						}
						//overstep the boundary, PS-20241030
						if ( (block_idx + block_count) >= (u8ISO15BlockCount + 1 + 1) )  //first block_count = 1;
						{
							;
						}
						else
						{
							resp[0] = 0;    // Response flags
							for (i = 0; i < block_count; i++)
							{
								// where to put the data of the current block
								work_offset = 1 + i * (u8ISO15BlockSize + security_offset);

								if (u8TagRecvCmd[0] & ISO15_REQ_OPTION) {
									resp[work_offset] = 0;    // Security status
								}

								// Block data
								//if (block_size * (block_idx + i + 1) <= CARD_MEMORY_SIZE) {
								if ((block_idx + i) <= u8ISO15BlockCount) {
									//fill data
									memcpy(resp + work_offset + security_offset, u8TagSimData + 0x10 + u8ISO15BlockSize * (block_idx + i), u8ISO15BlockSize);  //tag data, PS-20241005
								}
								else {
									memset(resp + work_offset + security_offset, 3, u8ISO15BlockSize);
								}


							}
							AppendCrcV(resp, resplen);

							X_15693_Tag_SendData(resp, resplen+2, u8TagRecvCmd[0]&0x01);
						}
					}
					break;

				case ISO15693_WRITEBLOCK:
					{
						address_offset = 0;

						if (u8TagRecvCmd[0] & ISO15_REQ_ADDRESS){
							address_offset = 8;
						}

						block_idx = u8TagRecvCmd[2 + address_offset];

						u8TagSimData[0x10 + block_idx*u8ISO15BlockSize + 0] = u8TagRecvCmd[2 + address_offset + 1];
						u8TagSimData[0x10 + block_idx*u8ISO15BlockSize + 1] = u8TagRecvCmd[2 + address_offset + 2];
						u8TagSimData[0x10 + block_idx*u8ISO15BlockSize + 2] = u8TagRecvCmd[2 + address_offset + 3];
						u8TagSimData[0x10 + block_idx*u8ISO15BlockSize + 3] = u8TagRecvCmd[2 + address_offset + 4];

						if (address_offset == 0)  //u8CmdVcd2Vicc[0]==02 ,exclude UID
						{
							resp[0] = 0x00;
							AppendCrcV(resp, 1);

							X_15693_Tag_SendData(resp, 3, u8TagRecvCmd[0]&0x01);
						}
					}
					break;

				case ISO15693_READ_MULTI_SECSTATUS:
					{
						address_offset = 0;

						if (u8TagRecvCmd[0] & ISO15_REQ_ADDRESS){
							address_offset = 8;
						}

						block_idx = u8TagRecvCmd[2 + address_offset];
						block_count = u8TagRecvCmd[3 + address_offset];  //some reader is FF
						if (block_count >= (u8ISO15BlockCount - block_idx))
						{
							block_count = (u8ISO15BlockCount - block_idx) + 1;
						}

						resp[0] = 0;    // Response flags
						for (i = 0; i < block_count; i++){
							resp[1+i] = 0x00;
						}
						resplen = block_count + 1;

						AppendCrcV(resp, resplen);

						X_15693_Tag_SendData(resp, resplen+2, u8TagRecvCmd[0]&0x01);
						
						//bTagDataWrite = true;
					}
					break;

				default:
					break;
			}
		}//CRC OK		
	}

#endif
////////////////////////////////////////////////////////////////