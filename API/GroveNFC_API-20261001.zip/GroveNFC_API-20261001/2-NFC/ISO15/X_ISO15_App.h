#ifndef     __X_ISO15_APP_H__
#define     __X_ISO15_APP_H__

//#define ISO15TAG_DATA_FROM_CONST  //const uint8_t ISO15_Sim_Data[], else from flash

int16_t X_15693_getuid(uint8_t *uid15693, uint8_t mode);
int16_t X_15693_readsingleblock(uint8_t *uid15693, uint8_t block, uint8_t *data15693, uint8_t mode);
int16_t X_15693_writesingleblock(uint8_t *uid15693, uint8_t block, uint8_t *data15693, uint8_t mode);
int16_t X_15693_readmultiblock(uint8_t *uid15693, uint8_t block, uint8_t number, uint8_t *data15693, uint8_t mode);
int16_t X_15693_magicuid(uint8_t *uid15693, uint8_t mode);

/**
 * @brief 从uid15693获取ISO15693信息
 * @param uid15693    ISO15693标签UID
 * @param type          标签类型
 * @param blocksize     块大小
 * @param blockcount    块数量
 **/
void X_15693_info(uint8_t *uid15693, uint8_t *type, uint8_t *blocksize, uint8_t *blockcount);
extern 	uint8_t u8ISO15BlockCount;
extern 	uint8_t u8ISO15BlockSize;
extern 	uint8_t u8ISO15Type;

extern uint8_t gISO15_Uid[8];

///////////////////////////////////////////////////////////////////////////////////////////////
// REQUEST FLAGS
#define ISO15_REQ_SUBCARRIER_SINGLE      0x00 // Tag should respond using one subcarrier (ASK)
#define ISO15_REQ_SUBCARRIER_TWO         0x01 // Tag should respond using two subcarriers (FSK)
#define ISO15_REQ_DATARATE_LOW           0x00 // Tag should respond using low data rate
#define ISO15_REQ_DATARATE_HIGH          0x02 // Tag should respond using high data rate
#define ISO15_REQ_NONINVENTORY           0x00
#define ISO15_REQ_INVENTORY              0x04 // This is an inventory request - see inventory flags
#define ISO15_REQ_PROTOCOL_NONEXT        0x00
#define ISO15_REQ_PROTOCOL_EXT           0x08 // RFU

// REQUEST FLAGS when INVENTORY is not set
#define ISO15_REQ_SELECT                 0x10 // only selected cards response
#define ISO15_REQ_ADDRESS                0x20 // this req contains an address
#define ISO15_REQ_OPTION                 0x40 // Command specific option selector

//REQUEST FLAGS when INVENTORY is set
#define ISO15_REQINV_AFI                 0x10 // AFI Field is present
#define ISO15_REQINV_SLOT1               0x20 // 1 Slot
#define ISO15_REQINV_SLOT16              0x00 // 16 Slots
#define ISO15_REQINV_OPTION              0x40 // Command specific option selector

//RESPONSE FLAGS
#define ISO15_RES_ERROR                  0x01
#define ISO15_RES_EXT                    0x08 // Protocol Extension

// RESPONSE ERROR CODES
#define ISO15_NOERROR                    0x00
#define ISO15_ERROR_CMD_NOT_SUP          0x01 // Command not supported
#define ISO15_ERROR_CMD_NOT_REC          0x02 // Command not recognized (eg. parameter error)
#define ISO15_ERROR_CMD_OPTION           0x03 // Command option not supported
#define ISO15_ERROR_GENERIC              0x0F // No additional Info about this error
#define ISO15_ERROR_BLOCK_UNAVAILABLE    0x10
#define ISO15_ERROR_BLOCK_LOCKED_ALREADY 0x11 // cannot lock again
#define ISO15_ERROR_BLOCK_LOCKED         0x12 // cannot be changed
#define ISO15_ERROR_BLOCK_WRITE          0x13 // Writing was unsuccessful
#define ISO15_ERROR_BLOCL_WRITELOCK      0x14 // Locking was unsuccessful
///////////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////////////
//First byte is 26
#define ISO15693_INVENTORY     0x01
#define ISO15693_STAYQUIET     0x02
//First byte is 02
#define ISO15693_READBLOCK                   0x20
#define ISO15693_WRITEBLOCK                  0x21
#define ISO15693_LOCKBLOCK                   0x22
#define ISO15693_READ_MULTI_BLOCK            0x23
#define ISO15693_WRITE_MULTI_BLOCK           0x24
#define ISO15693_SELECT                      0x25
#define ISO15693_RESET_TO_READY              0x26
#define ISO15693_WRITE_AFI                   0x27
#define ISO15693_LOCK_AFI                    0x28
#define ISO15693_WRITE_DSFID                 0x29
#define ISO15693_LOCK_DSFID                  0x2A
#define ISO15693_GET_SYSTEM_INFO             0x2B
#define ISO15693_READ_MULTI_SECSTATUS        0x2C
// NXP/Philips custom commands
#define ISO15693_INVENTORY_READ              0xA0
#define ISO15693_FAST_INVENTORY_READ         0xA1
#define ISO15693_SET_EAS                     0xA2
#define ISO15693_RESET_EAS                   0xA3
#define ISO15693_LOCK_EAS                    0xA4
#define ISO15693_EAS_ALARM                   0xA5
#define ISO15693_PASSWORD_PROTECT_EAS        0xA6
#define ISO15693_WRITE_EAS_ID                0xA7
#define ISO15693_READ_EPC                    0xA8
#define ISO15693_GET_NXP_SYSTEM_INFO         0xAB
#define ISO15693_INVENTORY_PAGE_READ         0xB0
#define ISO15693_FAST_INVENTORY_PAGE_READ    0xB1
#define ISO15693_GET_RANDOM_NUMBER           0xB2
#define ISO15693_SET_PASSWORD                0xB3
#define ISO15693_WRITE_PASSWORD              0xB4
#define ISO15693_LOCK_PASSWORD               0xB5
#define ISO15693_PROTECT_PAGE                0xB6
#define ISO15693_LOCK_PAGE_PROTECTION        0xB7
#define ISO15693_GET_MULTI_BLOCK_PROTECTION  0xB8
#define ISO15693_DESTROY                     0xB9
#define ISO15693_ENABLE_PRIVACY              0xBA
#define ISO15693_64BIT_PASSWORD_PROTECTION   0xBB
#define ISO15693_STAYQUIET_PERSISTENT        0xBC
#define ISO15693_READ_SIGNATURE              0xBD
////////////////////////////////////////////////////////////////////////////////////////////////

#endif
