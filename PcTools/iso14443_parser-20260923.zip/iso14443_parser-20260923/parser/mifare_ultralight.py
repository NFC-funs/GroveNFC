#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Mifare Ultralight / NTAG 卡片解析器
"""

class MifareUltralightParser:
    """Mifare Ultralight / NTAG 解析器"""
    
    CMD_READ = 0x30
    CMD_WRITE = 0xA2
    CMD_GET_VERSION = 0x60
    CMD_PWD_AUTH = 0x1A
    
    @staticmethod
    def parse(cmd, payload, data_len, result):
        cmd_desc = ""
        
        if cmd == MifareUltralightParser.CMD_GET_VERSION:
            cmd_desc = "NTAG GetVersion"
        elif cmd == MifareUltralightParser.CMD_PWD_AUTH:
            cmd_desc = "NTAG Password Auth"
        elif cmd == MifareUltralightParser.CMD_WRITE:
            if data_len >= 2:
                page = payload[1]
                cmd_desc = f"NTAG/Ultralight Write Page (page={page})"
            else:
                cmd_desc = "NTAG/Ultralight Write Page"
        elif cmd == MifareUltralightParser.CMD_READ:
            if data_len >= 2:
                page = payload[1]
                cmd_desc = f"NTAG/Ultralight Read Pages (page={page})"
            else:
                cmd_desc = "NTAG/Ultralight Read"
        
        return cmd_desc