#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
主窗口UI
"""

import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox, filedialog
import threading
import time
import struct
import re
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from ui.language import Language
from parser.iso14443_parser import ISO14443AParser
from utils.serial_utils import SerialUtils


class ClickableText(scrolledtext.ScrolledText):
    """支持点击事件和查找功能的自定义文本组件"""
    
    def __init__(self, master=None, **kwargs):
        super().__init__(master, **kwargs)
        self.bind('<Button-1>', self.on_click)
        self.click_callback = None
        self.search_highlight_tags = []
        self.last_search_text = ""
        self.last_case_sensitive = False
        self.last_whole_word = False
        self.current_match_index = -1
        self.match_positions = []
        self.paired_text_widget = None
        self.parent_app = None
        self.find_dialog = None
        
        self.bind('<Control-f>', self.show_find_dialog)
        self.bind('<Control-F>', self.show_find_dialog)
        self.bind('<F3>', self.find_next_shortcut)
        
    def set_paired_text(self, paired_widget):
        self.paired_text_widget = paired_widget
    
    def set_parent_app(self, app):
        self.parent_app = app
    
    def set_click_callback(self, callback):
        self.click_callback = callback
    
    def on_click(self, event):
        if not self.click_callback:
            return
        
        index = self.index(f"@{event.x},{event.y}")
        line = self.get(f"{index} linestart", f"{index} lineend")
        
        match = re.search(r'\[#(\d+)\]', line)
        if match:
            seq_num = int(match.group(1))
            self.click_callback(seq_num)
    
    def find_next_shortcut(self, event=None):
        if self.last_search_text:
            self.find_next(self.last_search_text, self.last_case_sensitive, self.last_whole_word)
        return "break"
    
    def show_find_dialog(self, event=None):
        if self.find_dialog and self.find_dialog.winfo_exists():
            self.find_dialog.lift()
            self.find_dialog.focus_set()
            return
        
        self.find_dialog = FindDialog(self, self.master)
        self.find_dialog.protocol("WM_DELETE_WINDOW", self.on_find_dialog_close)
        return "break"
    
    def on_find_dialog_close(self):
        if self.find_dialog:
            self.find_dialog.destroy()
            self.find_dialog = None
    
    def get_seq_num_from_position(self, pos):
        try:
            line_start = f"{pos} linestart"
            line = self.get(line_start, f"{line_start} lineend")
            match = re.search(r'\[#(\d+)\]', line)
            if match:
                return int(match.group(1))
        except Exception:
            pass
        return None
    
    def sync_to_paired_widget(self, pos):
        if not self.paired_text_widget or not self.parent_app:
            return
        
        seq_num = self.get_seq_num_from_position(pos)
        if seq_num is not None and seq_num in self.parent_app.packet_data:
            if self is self.parent_app.log_text:
                self.parent_app.jump_to_result(seq_num, scroll=True)
            elif self is self.parent_app.result_text:
                self.parent_app.jump_to_log(seq_num, scroll=True)
    
    def find_text(self, search_text, case_sensitive=False, whole_word=False):
        self.clear_highlights()
        
        if not search_text:
            return 0
        
        self.last_search_text = search_text
        self.last_case_sensitive = case_sensitive
        self.last_whole_word = whole_word
        self.match_positions = []
        self.current_match_index = -1
        
        if whole_word:
            search_pattern = r'\b' + re.escape(search_text) + r'\b'
        else:
            search_pattern = search_text
        
        count = 0
        start = "1.0"
        first_match = None
        
        while True:
            try:
                if whole_word:
                    pos = self.search(search_pattern, start, stopindex=tk.END, regexp=True, nocase=(not case_sensitive))
                else:
                    pos = self.search(search_pattern, start, stopindex=tk.END, nocase=(not case_sensitive))
                
                if not pos:
                    break
                
                self.match_positions.append(pos)
                if first_match is None:
                    first_match = pos
                
                if whole_word:
                    end = f"{pos} wordend"
                else:
                    end = f"{pos}+{len(search_text)}c"
                
                tag_name = f"highlight_{count}"
                self.tag_add(tag_name, pos, end)
                self.tag_config(tag_name, background="yellow", foreground="black")
                self.search_highlight_tags.append(tag_name)
                
                count += 1
                start = end
            except Exception:
                break
        
        if count > 0 and first_match:
            try:
                self.see(first_match)
                self.mark_set(tk.INSERT, first_match)
                self.current_match_index = 0
                self.sync_to_paired_widget(first_match)
            except Exception:
                pass
        
        return count
    
    def clear_highlights(self):
        try:
            for tag in self.search_highlight_tags:
                self.tag_delete(tag)
            self.search_highlight_tags = []
        except Exception:
            pass
    
    def _highlight_all_matches(self, search_text, whole_word):
        for tag in self.search_highlight_tags:
            try:
                self.tag_delete(tag)
            except Exception:
                pass
        self.search_highlight_tags = []
        
        for idx, pos in enumerate(self.match_positions):
            try:
                if whole_word:
                    end = f"{pos} wordend"
                else:
                    end = f"{pos}+{len(search_text)}c"
                tag_name = f"highlight_{idx}"
                self.tag_add(tag_name, pos, end)
                self.tag_config(tag_name, background="yellow", foreground="black")
                self.search_highlight_tags.append(tag_name)
            except Exception:
                pass
    
    def find_next(self, search_text, case_sensitive=False, whole_word=False):
        if (search_text != self.last_search_text or 
            case_sensitive != self.last_case_sensitive or 
            whole_word != self.last_whole_word):
            self.find_text(search_text, case_sensitive, whole_word)
            return
        
        if not search_text or not self.match_positions:
            return
        
        self.current_match_index += 1
        if self.current_match_index >= len(self.match_positions):
            self.current_match_index = 0
        
        pos = self.match_positions[self.current_match_index]
        
        try:
            self._highlight_all_matches(search_text, whole_word)
            self.see(pos)
            self.mark_set(tk.INSERT, pos)
            self.sync_to_paired_widget(pos)
        except Exception:
            pass
    
    def find_previous(self, search_text, case_sensitive=False, whole_word=False):
        if (search_text != self.last_search_text or 
            case_sensitive != self.last_case_sensitive or 
            whole_word != self.last_whole_word):
            self.find_text(search_text, case_sensitive, whole_word)
            return
        
        if not search_text or not self.match_positions:
            return
        
        self.current_match_index -= 1
        if self.current_match_index < 0:
            self.current_match_index = len(self.match_positions) - 1
        
        pos = self.match_positions[self.current_match_index]
        
        try:
            self._highlight_all_matches(search_text, whole_word)
            self.see(pos)
            self.mark_set(tk.INSERT, pos)
            self.sync_to_paired_widget(pos)
        except Exception:
            pass


class FindDialog(tk.Toplevel):
    """查找对话框"""
    
    def __init__(self, text_widget, master):
        super().__init__(master)
        self.text_widget = text_widget
        self.title("查找" if Language.current_lang == "ZH" else "Find")
        self.geometry("420x160")
        self.resizable(False, False)
        self.transient(master)
        self.grab_set()
        
        x = master.winfo_x() + (master.winfo_width() - 420) // 2
        y = master.winfo_y() + (master.winfo_height() - 160) // 2
        self.geometry(f"+{x}+{y}")
        
        self.create_widgets()
        
        self.bind('<Escape>', self.on_close)
        self.protocol("WM_DELETE_WINDOW", self.on_close)
        
        self.entry.focus_set()
        
        if hasattr(text_widget, 'last_search_text') and text_widget.last_search_text:
            self.entry.insert(0, text_widget.last_search_text)
            self.entry.select_range(0, tk.END)
    
    def create_widgets(self):
        main_frame = ttk.Frame(self, padding=10)
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        ttk.Label(main_frame, text="查找内容:" if Language.current_lang == "ZH" else "Find:").grid(row=0, column=0, sticky=tk.W, padx=5, pady=5)
        self.entry = ttk.Entry(main_frame, width=35)
        self.entry.grid(row=0, column=1, padx=5, pady=5, sticky=tk.W)
        self.entry.bind('<Return>', self.on_find_all)
        
        options_frame = ttk.Frame(main_frame)
        options_frame.grid(row=1, column=0, columnspan=2, pady=5)
        
        self.case_var = tk.BooleanVar(value=False)
        self.word_var = tk.BooleanVar(value=False)
        
        ttk.Checkbutton(options_frame, text="区分大小写" if Language.current_lang == "ZH" else "Case sensitive", 
                        variable=self.case_var).pack(side=tk.LEFT, padx=10)
        ttk.Checkbutton(options_frame, text="全词匹配" if Language.current_lang == "ZH" else "Whole word", 
                        variable=self.word_var).pack(side=tk.LEFT, padx=10)
        
        btn_frame = ttk.Frame(main_frame)
        btn_frame.grid(row=2, column=0, columnspan=2, pady=10)
        
        ttk.Button(btn_frame, text="查找全部" if Language.current_lang == "ZH" else "Find All", 
                   command=self.on_find_all, width=10).pack(side=tk.LEFT, padx=3)
        ttk.Button(btn_frame, text="上一个" if Language.current_lang == "ZH" else "Previous", 
                   command=self.on_find_previous, width=10).pack(side=tk.LEFT, padx=3)
        ttk.Button(btn_frame, text="下一个" if Language.current_lang == "ZH" else "Next", 
                   command=self.on_find_next, width=10).pack(side=tk.LEFT, padx=3)
        ttk.Button(btn_frame, text="关闭" if Language.current_lang == "ZH" else "Close", 
                   command=self.on_close, width=10).pack(side=tk.LEFT, padx=3)
        
        hint_frame = ttk.Frame(main_frame)
        hint_frame.grid(row=3, column=0, columnspan=2, pady=2)
        ttk.Label(hint_frame, text="F3: 下一个", foreground="gray", font=("", 9)).pack(side=tk.LEFT, padx=5)
    
    def on_find_all(self, event=None):
        search_text = self.entry.get().strip()
        if not search_text:
            return
        
        case_sensitive = self.case_var.get()
        whole_word = self.word_var.get()
        
        count = self.text_widget.find_text(search_text, case_sensitive, whole_word)
        
        if count == 0:
            messagebox.showinfo("查找结果" if Language.current_lang == "ZH" else "Search Result", 
                               f"未找到: {search_text}" if Language.current_lang == "ZH" else f"Not found: {search_text}")
        else:
            msg = f"找到 {count} 个匹配项" if Language.current_lang == "ZH" else f"Found {count} matches"
            messagebox.showinfo("查找结果" if Language.current_lang == "ZH" else "Search Result", msg)
    
    def on_find_next(self):
        search_text = self.entry.get().strip()
        if not search_text:
            return
        
        case_sensitive = self.case_var.get()
        whole_word = self.word_var.get()
        
        self.text_widget.find_next(search_text, case_sensitive, whole_word)
    
    def on_find_previous(self):
        search_text = self.entry.get().strip()
        if not search_text:
            return
        
        case_sensitive = self.case_var.get()
        whole_word = self.word_var.get()
        
        self.text_widget.find_previous(search_text, case_sensitive, whole_word)
    
    def on_close(self, event=None):
        self.text_widget.clear_highlights()
        self.text_widget.find_dialog = None
        self.destroy()


class MainWindow:
    """主窗口类"""
    
    def __init__(self, root):
        self.root = root
        self.root.title(Language.get("app_title"))
        self.root.geometry("1200x900")

        self.packet_data = {}
        self.last_timestamp = None
        self.last_seq_num = None
        
        self.serial_port = tk.StringVar()
        self.serial_conn = None
        self.is_connected = False
        self.receiving = False
        self.recv_thread = None
        self.packet_counter = 0
        self.buffer = b''

        self.create_widgets()
        self.refresh_ports()

    def create_widgets(self):
        top_frame = ttk.Frame(self.root)
        top_frame.pack(fill=tk.X, padx=5, pady=2)
        
        self.lang_zh_btn = ttk.Button(top_frame, text=Language.get("language_zh"), 
                                       command=lambda: self.switch_language("ZH"), width=10)
        self.lang_zh_btn.pack(side=tk.RIGHT, padx=2)
        self.lang_en_btn = ttk.Button(top_frame, text=Language.get("language_en"), 
                                       command=lambda: self.switch_language("EN"), width=10)
        self.lang_en_btn.pack(side=tk.RIGHT, padx=2)
        
        hint_label = ttk.Label(top_frame, text="Ctrl+F 查找 | F3 下一个", foreground="gray")
        hint_label.pack(side=tk.RIGHT, padx=10)

        self.control_frame = ttk.LabelFrame(self.root, text=Language.get("serial_control"), padding=5)
        self.control_frame.pack(fill=tk.X, padx=5, pady=5)

        self.port_label = ttk.Label(self.control_frame, text=Language.get("serial_port"))
        self.port_label.grid(row=0, column=0, padx=5)
        
        self.port_combo = ttk.Combobox(self.control_frame, textvariable=self.serial_port, width=20)
        self.port_combo.grid(row=0, column=1, padx=5)
        
        self.refresh_btn = ttk.Button(self.control_frame, text=Language.get("refresh"), 
                                       command=self.refresh_ports)
        self.refresh_btn.grid(row=0, column=2, padx=5)

        self.connect_btn = ttk.Button(self.control_frame, text=Language.get("connect"), 
                                       command=self.toggle_connect)
        self.connect_btn.grid(row=0, column=3, padx=10)

        self.clear_btn = ttk.Button(self.control_frame, text=Language.get("clear_log"), 
                                     command=self.clear_log)
        self.clear_btn.grid(row=0, column=4, padx=5)
        
        self.save_btn = ttk.Button(self.control_frame, text=Language.get("save_log"), 
                                    command=self.save_log)
        self.save_btn.grid(row=0, column=5, padx=5)

        self.status_frame = ttk.LabelFrame(self.root, text=Language.get("status_info"), padding=5)
        self.status_frame.pack(fill=tk.X, padx=5, pady=5)

        self.status_label = ttk.Label(self.status_frame, 
                                       text=f"{Language.get('status_ready')} | {Language.get('packet_count')}: 0 | {Language.get('buffer_size')}: 0 {Language.get('bytes')}")
        self.status_label.pack(side=tk.LEFT, padx=5)

        self.manual_frame = ttk.LabelFrame(self.root, text=Language.get("manual_input"), padding=5)
        self.manual_frame.pack(fill=tk.X, padx=5, pady=5)

        self.manual_entry = ttk.Entry(self.manual_frame, width=80)
        self.manual_entry.grid(row=0, column=0, padx=5, sticky=tk.W)
        
        self.parse_btn = ttk.Button(self.manual_frame, text=Language.get("parse"), 
                                     command=self.parse_manual)
        self.parse_btn.grid(row=0, column=1, padx=5)

        format_text = Language.get("format_hint")
        self.format_label = ttk.Label(self.manual_frame, text=format_text, foreground="gray")
        self.format_label.grid(row=1, column=0, columnspan=2, padx=5, pady=2, sticky=tk.W)

        main_pane = ttk.PanedWindow(self.root, orient=tk.VERTICAL)
        main_pane.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        self.log_frame = ttk.LabelFrame(main_pane, text=Language.get("log_title"), padding=5)
        main_pane.add(self.log_frame, weight=1)

        self.log_text = ClickableText(self.log_frame, wrap=tk.WORD, font=("Courier", 9))
        self.log_text.set_click_callback(self.jump_to_result)
        self.log_text.set_parent_app(self)
        self.log_text.pack(fill=tk.BOTH, expand=True)
        self.log_text.tag_config("highlight", background="lightgreen", foreground="black")

        self.result_frame = ttk.LabelFrame(main_pane, text=Language.get("result_title"), padding=5)
        main_pane.add(self.result_frame, weight=1)

        self.result_text = ClickableText(self.result_frame, wrap=tk.WORD, font=("Courier", 9))
        self.result_text.set_click_callback(self.jump_to_log)
        self.result_text.set_parent_app(self)
        self.result_text.pack(fill=tk.BOTH, expand=True)
        self.result_text.tag_config("highlight", background="yellow", foreground="black")

        self.log_text.set_paired_text(self.result_text)
        self.result_text.set_paired_text(self.log_text)

    def switch_language(self, lang):
        Language.current_lang = lang
        self.root.title(Language.get("app_title"))
        self.update_ui_labels()
        self.update_status()
        self.refresh_result_display()

    def update_ui_labels(self):
        self.lang_zh_btn.config(text=Language.get("language_zh"))
        self.lang_en_btn.config(text=Language.get("language_en"))
        
        self.control_frame.config(text=Language.get("serial_control"))
        self.port_label.config(text=Language.get("serial_port"))
        self.refresh_btn.config(text=Language.get("refresh"))
        
        if self.is_connected:
            self.connect_btn.config(text=Language.get("disconnect"))
        else:
            self.connect_btn.config(text=Language.get("connect"))
        
        self.clear_btn.config(text=Language.get("clear_log"))
        self.save_btn.config(text=Language.get("save_log"))
        
        self.status_frame.config(text=Language.get("status_info"))
        
        self.manual_frame.config(text=Language.get("manual_input"))
        self.parse_btn.config(text=Language.get("parse"))
        self.format_label.config(text=Language.get("format_hint"))
        
        self.log_frame.config(text=Language.get("log_title"))
        self.result_frame.config(text=Language.get("result_title"))

    def refresh_ports(self):
        ports = SerialUtils.list_ports()
        port_list = [p.device for p in ports]
        self.port_combo['values'] = port_list
        if port_list:
            self.serial_port.set(port_list[0])

    def toggle_connect(self):
        if self.is_connected:
            self.disconnect_serial()
        else:
            self.connect_serial()

    def connect_serial(self):
        port = self.serial_port.get().strip()
        if not port:
            messagebox.showerror(Language.get("error_connect"), Language.get("error_port"))
            return
        try:
            self.serial_conn = SerialUtils.connect(port)
            self.is_connected = True
            self.connect_btn.config(text=Language.get("disconnect"))
            self.packet_counter = 0
            self.buffer = b''
            self.packet_data = {}
            self.last_timestamp = None
            self.last_seq_num = None
            ISO14443AParser.reset_mifare_state()
            self.log_message(f"{Language.get('connected')} {port}")
            self.receiving = True
            self.recv_thread = threading.Thread(target=self.receive_loop, daemon=True)
            self.recv_thread.start()
            self.update_status()
        except Exception as e:
            messagebox.showerror(Language.get("error_connect"), f"{Language.get('error_serial')}: {e}")

    def disconnect_serial(self):
        self.receiving = False
        SerialUtils.disconnect(self.serial_conn)
        self.is_connected = False
        self.connect_btn.config(text=Language.get("connect"))
        self.log_message(Language.get("disconnected"))
        self.update_status()

    def receive_loop(self):
        while self.receiving:
            if not self.serial_conn:
                break
            try:
                data = SerialUtils.read_data(self.serial_conn)
                if data:
                    self.buffer += data
                    self.update_status()
                    self.parse_buffer()
                else:
                    time.sleep(0.01)
            except Exception as e:
                self.log_message(f"Receive error: {e}")
                break

    def parse_buffer(self):
        while len(self.buffer) >= 8:
            data_len = struct.unpack('>H', self.buffer[5:7])[0]
            total_len = 8 + data_len
            
            if len(self.buffer) >= total_len:
                packet = self.buffer[:total_len]
                self.buffer = self.buffer[total_len:]
                self.packet_counter += 1
                self.process_packet(packet)
                self.update_status()
            else:
                break

    def update_status(self):
        status_text = f"{Language.get('status_ready')} | {Language.get('packet_count')}: {self.packet_counter} | {Language.get('buffer_size')}: {len(self.buffer)} {Language.get('bytes')}"
        if self.is_connected:
            status_text += f" | {Language.get('connected')}: {self.serial_port.get()}"
        self.status_label.config(text=status_text)

    def process_packet(self, packet):
        seq_num = self.packet_counter
        
        result = ISO14443AParser.parse_packet(packet)
        hex_str = packet.hex().upper()
        
        dir_char = chr(packet[0]) if 32 <= packet[0] <= 126 else f"0x{packet[0]:02X}"
        
        timestamp_raw = struct.unpack('>I', packet[1:5])[0]
        ts_value = timestamp_raw & 0x00FFFFFF
        
        time_diff = None
        overflow = False
        if self.last_timestamp is not None:
            time_diff, overflow = ISO14443AParser.calculate_time_diff(self.last_timestamp, ts_value)
        
        self.packet_data[seq_num] = {
            "packet": packet,
            "hex_str": hex_str,
            "result": result,
            "timestamp_raw": timestamp_raw,
            "timestamp_value": ts_value,
            "time_diff": time_diff,
            "overflow": overflow
        }
        
        self.last_timestamp = ts_value
        self.last_seq_num = seq_num
        
        log_line = f"[#{seq_num}] {dir_char} {hex_str}\n"
        self.log_text.insert(tk.END, log_line)
        self.log_text.see(tk.END)
        
        self.display_result(seq_num, result, ts_value, time_diff, overflow)

    def display_result(self, seq_num, result, ts_value, time_diff=None, overflow=False):
        if "error" in result:
            self.result_text.insert(tk.END, f"[#{seq_num}] Error: {result['error']}\n")
            self.result_text.see(tk.END)
            return

        lines = []
        lines.append(f"[#{seq_num}] {'='*50}")
        lines.append(f"{Language.get('direction')}: {result['direction']}")
        
        ts_hex = f"0x{ts_value:06X}"
        lines.append(f"{Language.get('timestamp')}: {ts_hex}")
        
        if time_diff is not None:
            if overflow:
                prev_ts = self.packet_data[seq_num - 1]['timestamp_value']
                lines.append(f"   ** {Language.get('overflow_warning')} (prev:0x{prev_ts:06X} -> curr:0x{ts_value:06X})")
                lines.append(f"   {Language.get('time_diff')}: {time_diff:>8d} ({Language.get('overflow_compensated')})")
            else:
                lines.append(f"   {Language.get('time_diff')}: {time_diff:>8d}")
        else:
            lines.append(f"   {Language.get('time_diff')}: ({Language.get('first_packet')})")
        
        lines.append(f"{Language.get('payload_len')}: {result['payload_len']} bytes")
        lines.append(f"{Language.get('payload_data')}: {result['payload_hex']}")
        lines.append(f"{Language.get('commands')}:")
        for cmd in result['commands']:
            lines.append(f"   -> {cmd}")
        if result['extra_info']:
            lines.append(f"{Language.get('extra_info')}:")
            for info in result['extra_info']:
                lines.append(f"   - {info}")
        lines.append("")

        self.result_text.insert(tk.END, "\n".join(lines) + "\n")
        self.result_text.see(tk.END)

    def jump_to_result(self, seq_num, scroll=True):
        if seq_num in self.packet_data:
            self.result_text.tag_remove("highlight", "1.0", tk.END)
            search_pattern = f"[#{seq_num}]"
            start_pos = self.result_text.search(search_pattern, "1.0", tk.END)
            if start_pos:
                end_pos = f"{start_pos} lineend"
                self.result_text.tag_add("highlight", start_pos, end_pos)
                if scroll:
                    self.result_text.see(start_pos)
                    self.result_text.mark_set(tk.INSERT, start_pos)
                
                self.log_text.tag_remove("highlight", "1.0", tk.END)
                log_start = self.log_text.search(f"[#{seq_num}]", "1.0", tk.END)
                if log_start:
                    log_end = f"{log_start} lineend"
                    self.log_text.tag_add("highlight", log_start, log_end)

    def jump_to_log(self, seq_num, scroll=True):
        if seq_num in self.packet_data:
            self.log_text.tag_remove("highlight", "1.0", tk.END)
            search_pattern = f"[#{seq_num}]"
            start_pos = self.log_text.search(search_pattern, "1.0", tk.END)
            if start_pos:
                end_pos = f"{start_pos} lineend"
                self.log_text.tag_add("highlight", start_pos, end_pos)
                if scroll:
                    self.log_text.see(start_pos)
                    self.log_text.mark_set(tk.INSERT, start_pos)
                
                self.result_text.tag_remove("highlight", "1.0", tk.END)
                result_start = self.result_text.search(f"[#{seq_num}]", "1.0", tk.END)
                if result_start:
                    result_end = f"{result_start} lineend"
                    self.result_text.tag_add("highlight", result_start, result_end)

    def refresh_result_display(self):
        self.result_text.delete(1.0, tk.END)
        for seq_num in sorted(self.packet_data.keys()):
            data = self.packet_data[seq_num]
            self.display_result(
                seq_num, 
                data["result"], 
                data["timestamp_value"],
                data.get("time_diff"),
                data.get("overflow", False)
            )

    def parse_manual(self):
        hex_str = self.manual_entry.get().strip().replace(" ", "")
        if not hex_str:
            messagebox.showwarning(Language.get("warning_input"), Language.get("warning_input"))
            return
        
        if len(hex_str) % 2 != 0:
            messagebox.showerror(Language.get("error_hex_format"), Language.get("error_hex_length"))
            return
        
        try:
            packet = bytes.fromhex(hex_str)
        except ValueError as e:
            messagebox.showerror(Language.get("error_hex_format"), f"{Language.get('error_hex_format')}: {e}")
            return
        
        if len(packet) < 8:
            messagebox.showerror(Language.get("error_packet_short"), 
                               "数据包太短，至少需要8字节（方向1+时间戳4+长度2+有效位1）")
            return
        
        self.packet_counter += 1
        self.process_packet(packet)
        self.update_status()

    def log_message(self, msg):
        self.log_text.insert(tk.END, f"[{time.strftime('%H:%M:%S')}] {msg}\n")
        self.log_text.see(tk.END)

    def clear_log(self):
        self.log_text.delete(1.0, tk.END)
        self.result_text.delete(1.0, tk.END)
        self.packet_counter = 0
        self.buffer = b''
        self.packet_data = {}
        self.last_timestamp = None
        self.last_seq_num = None
        ISO14443AParser.reset_mifare_state()
        self.update_status()

    def save_log(self):
        file_path = filedialog.asksaveasfilename(defaultextension=".txt",
                                                 filetypes=[("Text files", "*.txt"), ("All files", "*.*")])
        if not file_path:
            return
        try:
            with open(file_path, "w", encoding="utf-8") as f:
                f.write("=== ISO 14443A Protocol Log ===\n")
                f.write(f"Export time: {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
                f.write(f"Total packets: {self.packet_counter}\n\n")
                f.write("--- Raw Log ---\n")
                f.write(self.log_text.get(1.0, tk.END))
                f.write("\n\n=== Parsed Results ===\n")
                f.write(self.result_text.get(1.0, tk.END))
            messagebox.showinfo(Language.get("save_success"), f"{Language.get('save_success')}: {file_path}")
        except Exception as e:
            messagebox.showerror(Language.get("save_failed"), f"{Language.get('save_failed')}: {e}")

    def on_closing(self):
        self.receiving = False
        if self.serial_conn and self.serial_conn.is_open:
            self.serial_conn.close()
        self.root.destroy()