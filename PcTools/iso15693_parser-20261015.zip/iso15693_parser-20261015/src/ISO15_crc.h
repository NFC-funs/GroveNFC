///////////////////////////////////////////////////
//ISO/IEC 13239, x^16 + x^12 + x^5 + 1 = 8408
#define POLYNOMIAL   0x8408 // x^16 + x^12 + x^5 + 1
#define PRESET_VALUE 0xFFFF
#define CHECK_VALUE  0x0F47//0xF0B8
//#define NUMBER_OF_BYTES 4 // Example: 4 data bytes
//example:{1, 2, 3, 4, 0x91, 0x39};  //crc is 3991,lsb first
//calc_crc is 3991
//check_crc is F0B8
uint16_t crc16_V(uint8_t *data, uint16_t len)
{
	uint16_t current_crc_value = PRESET_VALUE;
    uint16_t i;
	uint8_t j;

	for (i = 0; i < len; i++)
    {
        current_crc_value = current_crc_value^((uint16_t)data[i]);
        for (j = 0; j < 8; j++)
        {
            if (current_crc_value & 0x0001)
            {
                current_crc_value = (current_crc_value >> 1) ^ POLYNOMIAL;
            }
            else
            {
                current_crc_value = (current_crc_value >> 1);
            }
        }
    }

	return (~current_crc_value);  //CHECK_VALUE is current_crc_value, so check its negation. PS-20221023
}
bool HasValidCrcV(uint8_t *receivedCmd, uint16_t receivedCmd_len)
{
	return (crc16_V(receivedCmd, receivedCmd_len) == CHECK_VALUE);
}