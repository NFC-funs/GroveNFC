#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
多语言支持
"""


class Language:
    """多语言支持类"""
    
    ZH = {
        "app_title": "ISO 15693 协议解析器",
        "serial_control": "串口控制",
        "serial_port": "串口:",
        "refresh": "刷新",
        "connect": "连接",
        "disconnect": "断开",
        "clear_log": "清空日志",
        "save_log": "保存日志",
        "status_info": "状态信息",
        "status_ready": "就绪",
        "packet_count": "接收包数",
        "buffer_size": "缓冲区",
        "bytes": "字节",
        "manual_input": "手动输入数据包",
        "parse": "解析",
        "format_hint": "格式: [方向][时间戳4(BE)][长度2(BE)][有效位1][数据]",
        "log_title": "原始数据日志 (点击行跳转到解析结果)",
        "result_title": "解析结果 (点击行跳转到原始数据)",
        "direction": "方向",
        "timestamp": "时间戳",
        "time_diff": "时间差",
        "first_packet": "首条数据",
        "overflow_warning": "时间戳溢出恢复!",
        "overflow_compensated": "经过溢出补偿",
        "payload_len": "载荷长度",
        "payload_data": "载荷数据",
        "commands": "解析的命令",
        "extra_info": "附加信息",
        "direction_pcd_to_picc": "PCD -> PICC (阅读器->卡片)",
        "direction_picc_to_pcd": "PICC -> PCD (卡片->阅读器)",
        "error_packet_too_short": "数据包太短，至少需要8字节头部",
        "error_payload_mismatch": "实际载荷长度与声明长度不符",
        "error_hex_format": "无效的十六进制格式",
        "error_hex_length": "十六进制数据长度必须为偶数",
        "error_packet_short": "数据包太短，至少需要8字节（方向1+时间戳4+长度2+有效位1）",
        "error_port": "请选择串口",
        "error_connect": "连接错误",
        "error_serial": "串口连接失败",
        "save_success": "日志已保存",
        "save_failed": "保存失败",
        "warning_input": "请输入十六进制数据",
        "connected": "已连接到",
        "disconnected": "已断开串口",
        "unknown_direction": "未知方向",
        "empty_data": "空数据",
        "unknown_command": "未知命令",
        "language_zh": "中文",
        "language_en": "English",
    }
    
    EN = {
        "app_title": "ISO 15693 Protocol Parser",
        "serial_control": "Serial Control",
        "serial_port": "Port:",
        "refresh": "Refresh",
        "connect": "Connect",
        "disconnect": "Disconnect",
        "clear_log": "Clear Log",
        "save_log": "Save Log",
        "status_info": "Status",
        "status_ready": "Ready",
        "packet_count": "Packets",
        "buffer_size": "Buffer",
        "bytes": "bytes",
        "manual_input": "Manual Input",
        "parse": "Parse",
        "format_hint": "Format: [Dir][Timestamp4(BE)][Len2(BE)][ValidBits1][Data]",
        "log_title": "Raw Data Log (click to jump to result)",
        "result_title": "Parsed Result (click to jump to log)",
        "direction": "Direction",
        "timestamp": "Timestamp",
        "time_diff": "Time Diff",
        "first_packet": "First packet",
        "overflow_warning": "Timestamp overflow detected!",
        "overflow_compensated": "compensated",
        "payload_len": "Payload Length",
        "payload_data": "Payload Data",
        "commands": "Parsed Commands",
        "extra_info": "Additional Info",
        "direction_pcd_to_picc": "PCD -> PICC (Reader -> Card)",
        "direction_picc_to_pcd": "PICC -> PCD (Card -> Reader)",
        "error_packet_too_short": "Packet too short, at least 8 bytes header required",
        "error_payload_mismatch": "Payload length mismatch with declared length",
        "error_hex_format": "Invalid hex format",
        "error_hex_length": "Hex data length must be even",
        "error_packet_short": "Packet too short, at least 8 bytes required",
        "error_port": "Please select a port",
        "error_connect": "Connection Error",
        "error_serial": "Serial connection failed",
        "save_success": "Log saved successfully",
        "save_failed": "Save failed",
        "warning_input": "Please enter hex data",
        "connected": "Connected to",
        "disconnected": "Serial disconnected",
        "unknown_direction": "Unknown direction",
        "empty_data": "Empty data",
        "unknown_command": "Unknown command",
        "language_zh": "Chinese",
        "language_en": "English",
    }
    
    current_lang = "ZH"
    
    @classmethod
    def get(cls, key):
        lang_dict = cls.ZH if cls.current_lang == "ZH" else cls.EN
        return lang_dict.get(key, key)