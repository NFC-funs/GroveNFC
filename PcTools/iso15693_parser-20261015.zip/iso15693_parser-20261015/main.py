#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
ISO 15693 协议解析器 - 主程序入口
"""

import tkinter as tk
import sys
import os
import types

_PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

# Python 3.9 及更早版本内置了名为 "parser" 的模块，会遮蔽本项目同名的 parser 包，
# 导致 "ModuleNotFoundError: ... 'parser' is not a package"。
# 在导入前先把本地 parser 包注册到 sys.modules，避免与内置模块重名冲突。
if not getattr(sys.modules.get("parser"), "__path__", None):
    _local_parser = types.ModuleType("parser")
    _local_parser.__path__ = [os.path.join(_PROJECT_ROOT, "parser")]
    sys.modules["parser"] = _local_parser

from ui.main_window import MainWindow


def main():
    root = tk.Tk()
    app = MainWindow(root)
    root.protocol("WM_DELETE_WINDOW", app.on_closing)
    root.mainloop()


if __name__ == "__main__":
    main()