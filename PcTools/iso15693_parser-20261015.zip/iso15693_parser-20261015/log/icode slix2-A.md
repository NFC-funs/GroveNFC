# ISO 15693 Protocol Log

- Export time: 2026-10-15 12:09:03
- Total packets: 37

## Raw Log

```text
[12:06:57] 已连接到 COM4
[#1] > 3E004C2CD6000500260100F60A
[#2] < 3C004C250E000C00000002596D17090104E0C24E
[#3] > 3E004BFDE8000500260100F60A
[#4] < 3C004BF620000C00000002596D17090104E0C24E
[#5] > 3E004BC9AF000C00222B02596D17090104E0CDE4
[#6] < 3C004BB9A4001100000F02596D17090104E000004F0301C9C2
[#7] > 3E004B901F000D00222002596D17090104E00035F0
[#8] < 3C004B7EE7000700000000000077CF
[#9] > 3E004B3B29000D0022AB0402596D17090104E02047
[#10] < 3C004B29F0000A00000000007F350000DCD4
[#11] > 3E004B05B0000C00222B02596D17090104E0CDE4
[#12] < 3C004AF5A5001100000F02596D17090104E000004F0301C9C2
[#13] > 3E004AC547000D0022AB0402596D17090104E02047
[#14] < 3C004AB40E000A00000000007F350000DCD4
[#15] > 3E004A8554000400022B26A3
[#16] < 3C004A7EBA001100000F02596D17090104E000004F0301C9C2
[#17] > 3E004A44E9000D0022BD0402596D17090104E0A07D
[#18] < 3C004A33B00023000034AD03FE192A8BD0806830450BF285357E417D44D031DB156CA783B2C558E7ADDD83
[#19] > 3E0049ECA5000D0022A50402596D17090104E0DBC6
[#20] > 3E003A9AA9000D00222002596D17090104E00035F0
[#21] < 3C003A8971000700000000000077CF
[#22] > 3E003A69E7000E00222C02596D17090104E0004FAACE
[#23] < 3C003A5781005300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000BF80
[#24] > 3E0039D402000E00222302596D17090104E000085DE4
[#25] < 3C0039C19C00270000000000000000000000000000000000000000000000000000000000000000000000000000D26A
[#26] > 3E00396E99000E00622302596D17090104E000317F1F
[#27] < 3C00395C3200FD0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002428
[#28] > 3E0037FB77000E00622302596D17090104E0321D0371
[#29] < 3C0037E911009900000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001EFC
[#30] > 3E0036FF29000D0022B20402596D17090104E07CD0
[#31] < 3C0036EDF100050000C54D3FEB
[#32] > 3E0036CFE000120022B30402596D17090104E0B8DC48D14A071D
[#33] < 3C0036B8C10003000078F0
[#34] > 3E00369CAA000D0022BE0402596D17090104E0C909
[#35] < 3C00368B710007000013031621B537
[#36] > 3E00088959000D0026014002596D17090104E0D7FF
[#37] < 3C00087821000C00000002596D17090104E0C24E
```

## Parsed Results

### [#1] > 3E004C2CD6000500260100F60A

- Timestamp: 0x4C2CD6
- Payload: 5 bytes `260100F60A`
- Commands:
  - INVENTORY (寻卡) (0x01)
- Details:
  - 有效位: 0 (8 bits + 校验位)
  - Flags: 0x26 (二进制 00100110)
    - bit3 决定 bit5~bit8 的定义方式: 寻卡模式 (Inventory=1)
    - bit1 (0x01): 0 = 应答使用单个子载波 (ASK)
    - bit2 (0x02): 1 = 高速数据速率
    - bit3 (0x04): 1 = 寻卡(Inventory)请求
    - bit4 (0x08): 0 = 无协议扩展 (RFU)
    - bit5 (0x10) [寻卡模式]: 0 = 无 AFI 字段
    - bit6 (0x20) [寻卡模式]: 1 = 1 个时隙 (1 slot)
    - bit7 (0x40) [寻卡模式]: 0 = Option 清零
    - bit8 (0x80) [寻卡模式]: 0 = RFU (保留)
    - 标志位决定的后续参数:
        - 命令码后为 Mask 长度(1 字节) + Mask 值(⌈Mask长度/8⌉ 字节)
        - bit6=0 时阅读器需对 16 个时隙做防冲突处理(多卡场景)
  - 命令码: 0x01 (INVENTORY (寻卡))
    - Mask长度: 0 bits
  - CRC16: 字段 F6 0A (低字节在前 → 0x0AF6)
    - 校验: 通过 (整帧 crc16_V = 0x0F47, 期望 0x0F47)

### [#2] < 3C004C250E000C00000002596D17090104E0C24E

- Timestamp: 0x4C250E
- Time diff: 1992
- Payload: 12 bytes `000002596D17090104E0C24E`
- Commands:
  - 响应帧 (卡片→阅读器)
- Details:
  - 有效位: 0 (8 bits (完整字节))
  - 响应标志: 0x00 (二进制 00000000)
    - bit1 (0x01) ERROR: 0 = 无错误
    - bit2~bit3: RFU (保留，应为 0)
    - bit4 (0x08) Protocol Extension: 0 = 无协议扩展
    - bit5~bit8: RFU (保留，应为 0)
  - 对应请求命令: 0x01 (INVENTORY (寻卡))
  - 预期响应结构: [FLAG][DSFID][UID(8)][CRC16]
    - DSFID: 0x00
    - UID (显示序): E0 04 01 09 17 6D 59 02
    - UID (传输序): 02 59 6D 17 09 01 04 E0
    - IC 制造商代码: 0x04 → NXP Semiconductors
    - TAG/IC 类型: 0x01
    - ICODE 变体判定: 序列号区 bit37=0, bit36=1 (显示序第4字节 0x09) → NXP ICODE SLI-X2 (SL2S2602)
    - 识别厂商: NXP (NXP Semiconductors)
    - 卡片型号: NXP ICODE SLI-X2 (SL2S2602)
    - 型号备注: TAG 类型码 0x01 为 NXP ICODE SLI / SLI-X / SLI-X2 共用，由 UID 序列号区 bit37/bit36 细分（见下方 ICODE 变体判定）
  - CRC16: 字段 C2 4E (低字节在前 → 0x4EC2)
    - 校验: 通过 (整帧 crc16_V = 0x0F47, 期望 0x0F47)

### [#3] > 3E004BFDE8000500260100F60A

- Timestamp: 0x4BFDE8
- Time diff: 10022
- Payload: 5 bytes `260100F60A`
- Commands:
  - INVENTORY (寻卡) (0x01)
- Details:
  - 有效位: 0 (8 bits + 校验位)
  - Flags: 0x26 (二进制 00100110)
    - bit3 决定 bit5~bit8 的定义方式: 寻卡模式 (Inventory=1)
    - bit1 (0x01): 0 = 应答使用单个子载波 (ASK)
    - bit2 (0x02): 1 = 高速数据速率
    - bit3 (0x04): 1 = 寻卡(Inventory)请求
    - bit4 (0x08): 0 = 无协议扩展 (RFU)
    - bit5 (0x10) [寻卡模式]: 0 = 无 AFI 字段
    - bit6 (0x20) [寻卡模式]: 1 = 1 个时隙 (1 slot)
    - bit7 (0x40) [寻卡模式]: 0 = Option 清零
    - bit8 (0x80) [寻卡模式]: 0 = RFU (保留)
    - 标志位决定的后续参数:
        - 命令码后为 Mask 长度(1 字节) + Mask 值(⌈Mask长度/8⌉ 字节)
        - bit6=0 时阅读器需对 16 个时隙做防冲突处理(多卡场景)
  - 命令码: 0x01 (INVENTORY (寻卡))
    - Mask长度: 0 bits
  - CRC16: 字段 F6 0A (低字节在前 → 0x0AF6)
    - 校验: 通过 (整帧 crc16_V = 0x0F47, 期望 0x0F47)

### [#4] < 3C004BF620000C00000002596D17090104E0C24E

- Timestamp: 0x4BF620
- Time diff: 1992
- Payload: 12 bytes `000002596D17090104E0C24E`
- Commands:
  - 响应帧 (卡片→阅读器)
- Details:
  - 有效位: 0 (8 bits (完整字节))
  - 响应标志: 0x00 (二进制 00000000)
    - bit1 (0x01) ERROR: 0 = 无错误
    - bit2~bit3: RFU (保留，应为 0)
    - bit4 (0x08) Protocol Extension: 0 = 无协议扩展
    - bit5~bit8: RFU (保留，应为 0)
  - 对应请求命令: 0x01 (INVENTORY (寻卡))
  - 预期响应结构: [FLAG][DSFID][UID(8)][CRC16]
    - DSFID: 0x00
    - UID (显示序): E0 04 01 09 17 6D 59 02
    - UID (传输序): 02 59 6D 17 09 01 04 E0
    - IC 制造商代码: 0x04 → NXP Semiconductors
    - TAG/IC 类型: 0x01
    - ICODE 变体判定: 序列号区 bit37=0, bit36=1 (显示序第4字节 0x09) → NXP ICODE SLI-X2 (SL2S2602)
    - 识别厂商: NXP (NXP Semiconductors)
    - 卡片型号: NXP ICODE SLI-X2 (SL2S2602)
    - 型号备注: TAG 类型码 0x01 为 NXP ICODE SLI / SLI-X / SLI-X2 共用，由 UID 序列号区 bit37/bit36 细分（见下方 ICODE 变体判定）
  - CRC16: 字段 C2 4E (低字节在前 → 0x4EC2)
    - 校验: 通过 (整帧 crc16_V = 0x0F47, 期望 0x0F47)

### [#5] > 3E004BC9AF000C00222B02596D17090104E0CDE4

- Timestamp: 0x4BC9AF
- Time diff: 11377
- Payload: 12 bytes `222B02596D17090104E0CDE4`
- Commands:
  - GET SYSTEM INFORMATION (获取系统信息) (0x2B)
- Details:
  - 有效位: 0 (8 bits + 校验位)
  - Flags: 0x22 (二进制 00100010)
    - bit3 决定 bit5~bit8 的定义方式: 非寻卡模式 (Inventory=0)
    - bit1 (0x01): 0 = 应答使用单个子载波 (ASK)
    - bit2 (0x02): 1 = 高速数据速率
    - bit3 (0x04): 0 = 非寻卡请求
    - bit4 (0x08): 0 = 无协议扩展 (RFU)
    - bit5 (0x10) [非寻卡模式]: 0 = 非 Select
    - bit6 (0x20) [非寻卡模式]: 1 = Address (请求中含 8 字节 UID 寻址)
    - bit7 (0x40) [非寻卡模式]: 0 = Option 清零
    - bit8 (0x80) [非寻卡模式]: 0 = RFU (保留)
    - 标志位决定的后续参数:
        - bit6=1 → 请求中含 8 字节 UID（传输时 0xE0 为最后一个字节）；个别命令在 UID 之前另有参数字节，UID 之后的字节才是命令参数
  - 命令码: 0x2B (GET SYSTEM INFORMATION (获取系统信息))
    - UID (显示序): E0 04 01 09 17 6D 59 02
    - UID (传输序): 02 59 6D 17 09 01 04 E0
    - IC 制造商代码: 0x04 → NXP Semiconductors
    - TAG/IC 类型: 0x01
    - ICODE 变体判定: 序列号区 bit37=0, bit36=1 (显示序第4字节 0x09) → NXP ICODE SLI-X2 (SL2S2602)
    - 识别厂商: NXP (NXP Semiconductors)
    - 卡片型号: NXP ICODE SLI-X2 (SL2S2602)
    - 型号备注: TAG 类型码 0x01 为 NXP ICODE SLI / SLI-X / SLI-X2 共用，由 UID 序列号区 bit37/bit36 细分（见下方 ICODE 变体判定）
  - CRC16: 字段 CD E4 (低字节在前 → 0xE4CD)
    - 校验: 通过 (整帧 crc16_V = 0x0F47, 期望 0x0F47)

### [#6] < 3C004BB9A4001100000F02596D17090104E000004F0301C9C2

- Timestamp: 0x4BB9A4
- Time diff: 4107
- Payload: 17 bytes `000F02596D17090104E000004F0301C9C2`
- Commands:
  - 响应帧 (卡片→阅读器)
- Details:
  - 有效位: 0 (8 bits (完整字节))
  - 响应标志: 0x00 (二进制 00000000)
    - bit1 (0x01) ERROR: 0 = 无错误
    - bit2~bit3: RFU (保留，应为 0)
    - bit4 (0x08) Protocol Extension: 0 = 无协议扩展
    - bit5~bit8: RFU (保留，应为 0)
  - 对应请求命令: 0x2B (GET SYSTEM INFORMATION (获取系统信息))
  - 预期响应结构: [FLAG][Info flags][UID(8)][按 Info flags 存在的字段][CRC16]
    - Info flags: 0x0F
      - bit1 = 1 → DSFID 字段存在
      - bit2 = 1 → AFI 字段存在
      - bit3 = 1 → 存储容量字段存在
      - bit4 = 1 → IC 参考字段存在
      - bit5 = 0 → 块数量(2 字节)+块大小(1 字节)字段存在
    - UID (显示序): E0 04 01 09 17 6D 59 02
    - UID (传输序): 02 59 6D 17 09 01 04 E0
    - IC 制造商代码: 0x04 → NXP Semiconductors
    - TAG/IC 类型: 0x01
    - ICODE 变体判定: 序列号区 bit37=0, bit36=1 (显示序第4字节 0x09) → NXP ICODE SLI-X2 (SL2S2602)
    - 识别厂商: NXP (NXP Semiconductors)
    - 卡片型号: NXP ICODE SLI-X2 (SL2S2602)
    - 型号备注: TAG 类型码 0x01 为 NXP ICODE SLI / SLI-X / SLI-X2 共用，由 UID 序列号区 bit37/bit36 细分（见下方 ICODE 变体判定）
    - DSFID: 0x00
    - AFI: 0x00
    - 存储容量字段: 0x4F
    - IC 参考: 0x03
    - 未解析的剩余字节: 01
  - CRC16: 字段 C9 C2 (低字节在前 → 0xC2C9)
    - 校验: 通过 (整帧 crc16_V = 0x0F47, 期望 0x0F47)

### [#7] > 3E004B901F000D00222002596D17090104E00035F0

- Timestamp: 0x4B901F
- Time diff: 10629
- Payload: 13 bytes `222002596D17090104E00035F0`
- Commands:
  - READ SINGLE BLOCK (读单个块) (0x20)
- Details:
  - 有效位: 0 (8 bits + 校验位)
  - Flags: 0x22 (二进制 00100010)
    - bit3 决定 bit5~bit8 的定义方式: 非寻卡模式 (Inventory=0)
    - bit1 (0x01): 0 = 应答使用单个子载波 (ASK)
    - bit2 (0x02): 1 = 高速数据速率
    - bit3 (0x04): 0 = 非寻卡请求
    - bit4 (0x08): 0 = 无协议扩展 (RFU)
    - bit5 (0x10) [非寻卡模式]: 0 = 非 Select
    - bit6 (0x20) [非寻卡模式]: 1 = Address (请求中含 8 字节 UID 寻址)
    - bit7 (0x40) [非寻卡模式]: 0 = Option 清零
    - bit8 (0x80) [非寻卡模式]: 0 = RFU (保留)
    - 标志位决定的后续参数:
        - bit6=1 → 请求中含 8 字节 UID（传输时 0xE0 为最后一个字节）；个别命令在 UID 之前另有参数字节，UID 之后的字节才是命令参数
  - 命令码: 0x20 (READ SINGLE BLOCK (读单个块))
    - UID (显示序): E0 04 01 09 17 6D 59 02
    - UID (传输序): 02 59 6D 17 09 01 04 E0
    - IC 制造商代码: 0x04 → NXP Semiconductors
    - TAG/IC 类型: 0x01
    - ICODE 变体判定: 序列号区 bit37=0, bit36=1 (显示序第4字节 0x09) → NXP ICODE SLI-X2 (SL2S2602)
    - 识别厂商: NXP (NXP Semiconductors)
    - 卡片型号: NXP ICODE SLI-X2 (SL2S2602)
    - 型号备注: TAG 类型码 0x01 为 NXP ICODE SLI / SLI-X / SLI-X2 共用，由 UID 序列号区 bit37/bit36 细分（见下方 ICODE 变体判定）
    - 块号: 0
  - CRC16: 字段 35 F0 (低字节在前 → 0xF035)
    - 校验: 通过 (整帧 crc16_V = 0x0F47, 期望 0x0F47)

### [#8] < 3C004B7EE7000700000000000077CF

- Timestamp: 0x4B7EE7
- Time diff: 4408
- Payload: 7 bytes `000000000077CF`
- Commands:
  - 响应帧 (卡片→阅读器)
- Details:
  - 有效位: 0 (8 bits (完整字节))
  - 响应标志: 0x00 (二进制 00000000)
    - bit1 (0x01) ERROR: 0 = 无错误
    - bit2~bit3: RFU (保留，应为 0)
    - bit4 (0x08) Protocol Extension: 0 = 无协议扩展
    - bit5~bit8: RFU (保留，应为 0)
  - 对应请求命令: 0x20 (READ SINGLE BLOCK (读单个块))
  - 预期响应结构: [FLAG][块数据][CRC16]
    - 块数据(4 字节): 00 00 00 00
  - CRC16: 字段 77 CF (低字节在前 → 0xCF77)
    - 校验: 通过 (整帧 crc16_V = 0x0F47, 期望 0x0F47)

### [#9] > 3E004B3B29000D0022AB0402596D17090104E02047

- Timestamp: 0x4B3B29
- Time diff: 17342
- Payload: 13 bytes `22AB0402596D17090104E02047`
- Commands:
  - NXP GET_NXP_SYSTEM_INFO (获取NXP系统信息) (0xAB)
- Details:
  - 有效位: 0 (8 bits + 校验位)
  - Flags: 0x22 (二进制 00100010)
    - bit3 决定 bit5~bit8 的定义方式: 非寻卡模式 (Inventory=0)
    - bit1 (0x01): 0 = 应答使用单个子载波 (ASK)
    - bit2 (0x02): 1 = 高速数据速率
    - bit3 (0x04): 0 = 非寻卡请求
    - bit4 (0x08): 0 = 无协议扩展 (RFU)
    - bit5 (0x10) [非寻卡模式]: 0 = 非 Select
    - bit6 (0x20) [非寻卡模式]: 1 = Address (请求中含 8 字节 UID 寻址)
    - bit7 (0x40) [非寻卡模式]: 0 = Option 清零
    - bit8 (0x80) [非寻卡模式]: 0 = RFU (保留)
    - 标志位决定的后续参数:
        - bit6=1 → 请求中含 8 字节 UID（传输时 0xE0 为最后一个字节）；个别命令在 UID 之前另有参数字节，UID 之后的字节才是命令参数
  - 命令码: 0xAB (厂商私有命令)
    - IC Mfg code: 0x04 → NXP Semiconductors (NXP 私有命令在命令码之后携带的 IC 制造商代码，UID 位于其后)
    - UID (显示序): E0 04 01 09 17 6D 59 02
    - UID (传输序): 02 59 6D 17 09 01 04 E0
    - IC 制造商代码: 0x04 → NXP Semiconductors
    - TAG/IC 类型: 0x01
    - ICODE 变体判定: 序列号区 bit37=0, bit36=1 (显示序第4字节 0x09) → NXP ICODE SLI-X2 (SL2S2602)
    - 识别厂商: NXP (NXP Semiconductors)
    - 卡片型号: NXP ICODE SLI-X2 (SL2S2602)
    - 型号备注: TAG 类型码 0x01 为 NXP ICODE SLI / SLI-X / SLI-X2 共用，由 UID 序列号区 bit37/bit36 细分（见下方 ICODE 变体判定）
    - 按卡片厂商 NXP 的定义解析
    - NXP: GET_NXP_SYSTEM_INFO (获取NXP系统信息)
  - CRC16: 字段 20 47 (低字节在前 → 0x4720)
    - 校验: 通过 (整帧 crc16_V = 0x0F47, 期望 0x0F47)

### [#10] < 3C004B29F0000A00000000007F350000DCD4

- Timestamp: 0x4B29F0
- Time diff: 4409
- Payload: 10 bytes `000000007F350000DCD4`
- Commands:
  - 响应帧 (卡片→阅读器)
- Details:
  - 有效位: 0 (8 bits (完整字节))
  - 响应标志: 0x00 (二进制 00000000)
    - bit1 (0x01) ERROR: 0 = 无错误
    - bit2~bit3: RFU (保留，应为 0)
    - bit4 (0x08) Protocol Extension: 0 = 无协议扩展
    - bit5~bit8: RFU (保留，应为 0)
  - 对应请求命令: 0xAB (GET_NXP_SYSTEM_INFO (获取NXP系统信息))
  - 预期响应结构: [FLAG][PP pointer][PP conditions][Lock bits][Feature flags(32)][CRC16]
    - PP pointer(密码保护指针地址): 0x00
    - PP conditions: 0x00
      - bit1 = 0 → RL：Page L 读密码保护
      - bit2 = 0 → WL：Page L 写密码保护
      - bit5 = 0 → RH：Page H 读密码保护
      - bit6 = 0 → WH：Page H 写密码保护
    - Lock bits: 0x00
      - bit1 = 0 → AFI 锁定
      - bit2 = 0 → EAS 锁定
      - bit3 = 0 → DSFID 锁定
      - bit4 = 0 → PP：密码保护指针地址与访问条件锁定
    - Feature flags: 7F 35 00 00 (32 位, LSB 优先，以下列出置位项)
      - bit1 = 1 → UM PP：用户存储区密码保护
      - bit2 = 1 → COUNTER：计数器功能
      - bit3 = 1 → EAS ID：EAS ALARM 携带 EAS ID
      - bit4 = 1 → EAS PP：EAS 密码保护
      - bit5 = 1 → AFI PP：AFI 密码保护
      - bit6 = 1 → INVENTORY READ EXT：INVENTORY READ 扩展模式
      - bit7 = 1 → EAS IR：扩展模式下可做 EAS 选择
      - bit9 = 1 → ORIGINALITY SIG：READ SIGNATURE 命令
      - bit11 = 1 → P QUIET：STAY QUIET PERSISTENT
      - bit13 = 1 → PRIVACY：ENABLE PRIVACY
      - bit14 = 1 → DESTROY：DESTROY 命令
  - CRC16: 字段 DC D4 (低字节在前 → 0xD4DC)
    - 校验: 通过 (整帧 crc16_V = 0x0F47, 期望 0x0F47)

### [#11] > 3E004B05B0000C00222B02596D17090104E0CDE4

- Timestamp: 0x4B05B0
- Time diff: 9280
- Payload: 12 bytes `222B02596D17090104E0CDE4`
- Commands:
  - GET SYSTEM INFORMATION (获取系统信息) (0x2B)
- Details:
  - 有效位: 0 (8 bits + 校验位)
  - Flags: 0x22 (二进制 00100010)
    - bit3 决定 bit5~bit8 的定义方式: 非寻卡模式 (Inventory=0)
    - bit1 (0x01): 0 = 应答使用单个子载波 (ASK)
    - bit2 (0x02): 1 = 高速数据速率
    - bit3 (0x04): 0 = 非寻卡请求
    - bit4 (0x08): 0 = 无协议扩展 (RFU)
    - bit5 (0x10) [非寻卡模式]: 0 = 非 Select
    - bit6 (0x20) [非寻卡模式]: 1 = Address (请求中含 8 字节 UID 寻址)
    - bit7 (0x40) [非寻卡模式]: 0 = Option 清零
    - bit8 (0x80) [非寻卡模式]: 0 = RFU (保留)
    - 标志位决定的后续参数:
        - bit6=1 → 请求中含 8 字节 UID（传输时 0xE0 为最后一个字节）；个别命令在 UID 之前另有参数字节，UID 之后的字节才是命令参数
  - 命令码: 0x2B (GET SYSTEM INFORMATION (获取系统信息))
    - UID (显示序): E0 04 01 09 17 6D 59 02
    - UID (传输序): 02 59 6D 17 09 01 04 E0
    - IC 制造商代码: 0x04 → NXP Semiconductors
    - TAG/IC 类型: 0x01
    - ICODE 变体判定: 序列号区 bit37=0, bit36=1 (显示序第4字节 0x09) → NXP ICODE SLI-X2 (SL2S2602)
    - 识别厂商: NXP (NXP Semiconductors)
    - 卡片型号: NXP ICODE SLI-X2 (SL2S2602)
    - 型号备注: TAG 类型码 0x01 为 NXP ICODE SLI / SLI-X / SLI-X2 共用，由 UID 序列号区 bit37/bit36 细分（见下方 ICODE 变体判定）
  - CRC16: 字段 CD E4 (低字节在前 → 0xE4CD)
    - 校验: 通过 (整帧 crc16_V = 0x0F47, 期望 0x0F47)

### [#12] < 3C004AF5A5001100000F02596D17090104E000004F0301C9C2

- Timestamp: 0x4AF5A5
- Time diff: 4107
- Payload: 17 bytes `000F02596D17090104E000004F0301C9C2`
- Commands:
  - 响应帧 (卡片→阅读器)
- Details:
  - 有效位: 0 (8 bits (完整字节))
  - 响应标志: 0x00 (二进制 00000000)
    - bit1 (0x01) ERROR: 0 = 无错误
    - bit2~bit3: RFU (保留，应为 0)
    - bit4 (0x08) Protocol Extension: 0 = 无协议扩展
    - bit5~bit8: RFU (保留，应为 0)
  - 对应请求命令: 0x2B (GET SYSTEM INFORMATION (获取系统信息))
  - 预期响应结构: [FLAG][Info flags][UID(8)][按 Info flags 存在的字段][CRC16]
    - Info flags: 0x0F
      - bit1 = 1 → DSFID 字段存在
      - bit2 = 1 → AFI 字段存在
      - bit3 = 1 → 存储容量字段存在
      - bit4 = 1 → IC 参考字段存在
      - bit5 = 0 → 块数量(2 字节)+块大小(1 字节)字段存在
    - UID (显示序): E0 04 01 09 17 6D 59 02
    - UID (传输序): 02 59 6D 17 09 01 04 E0
    - IC 制造商代码: 0x04 → NXP Semiconductors
    - TAG/IC 类型: 0x01
    - ICODE 变体判定: 序列号区 bit37=0, bit36=1 (显示序第4字节 0x09) → NXP ICODE SLI-X2 (SL2S2602)
    - 识别厂商: NXP (NXP Semiconductors)
    - 卡片型号: NXP ICODE SLI-X2 (SL2S2602)
    - 型号备注: TAG 类型码 0x01 为 NXP ICODE SLI / SLI-X / SLI-X2 共用，由 UID 序列号区 bit37/bit36 细分（见下方 ICODE 变体判定）
    - DSFID: 0x00
    - AFI: 0x00
    - 存储容量字段: 0x4F
    - IC 参考: 0x03
    - 未解析的剩余字节: 01
  - CRC16: 字段 C9 C2 (低字节在前 → 0xC2C9)
    - 校验: 通过 (整帧 crc16_V = 0x0F47, 期望 0x0F47)

### [#13] > 3E004AC547000D0022AB0402596D17090104E02047

- Timestamp: 0x4AC547
- Time diff: 12382
- Payload: 13 bytes `22AB0402596D17090104E02047`
- Commands:
  - NXP GET_NXP_SYSTEM_INFO (获取NXP系统信息) (0xAB)
- Details:
  - 有效位: 0 (8 bits + 校验位)
  - Flags: 0x22 (二进制 00100010)
    - bit3 决定 bit5~bit8 的定义方式: 非寻卡模式 (Inventory=0)
    - bit1 (0x01): 0 = 应答使用单个子载波 (ASK)
    - bit2 (0x02): 1 = 高速数据速率
    - bit3 (0x04): 0 = 非寻卡请求
    - bit4 (0x08): 0 = 无协议扩展 (RFU)
    - bit5 (0x10) [非寻卡模式]: 0 = 非 Select
    - bit6 (0x20) [非寻卡模式]: 1 = Address (请求中含 8 字节 UID 寻址)
    - bit7 (0x40) [非寻卡模式]: 0 = Option 清零
    - bit8 (0x80) [非寻卡模式]: 0 = RFU (保留)
    - 标志位决定的后续参数:
        - bit6=1 → 请求中含 8 字节 UID（传输时 0xE0 为最后一个字节）；个别命令在 UID 之前另有参数字节，UID 之后的字节才是命令参数
  - 命令码: 0xAB (厂商私有命令)
    - IC Mfg code: 0x04 → NXP Semiconductors (NXP 私有命令在命令码之后携带的 IC 制造商代码，UID 位于其后)
    - UID (显示序): E0 04 01 09 17 6D 59 02
    - UID (传输序): 02 59 6D 17 09 01 04 E0
    - IC 制造商代码: 0x04 → NXP Semiconductors
    - TAG/IC 类型: 0x01
    - ICODE 变体判定: 序列号区 bit37=0, bit36=1 (显示序第4字节 0x09) → NXP ICODE SLI-X2 (SL2S2602)
    - 识别厂商: NXP (NXP Semiconductors)
    - 卡片型号: NXP ICODE SLI-X2 (SL2S2602)
    - 型号备注: TAG 类型码 0x01 为 NXP ICODE SLI / SLI-X / SLI-X2 共用，由 UID 序列号区 bit37/bit36 细分（见下方 ICODE 变体判定）
    - 按卡片厂商 NXP 的定义解析
    - NXP: GET_NXP_SYSTEM_INFO (获取NXP系统信息)
  - CRC16: 字段 20 47 (低字节在前 → 0x4720)
    - 校验: 通过 (整帧 crc16_V = 0x0F47, 期望 0x0F47)

### [#14] < 3C004AB40E000A00000000007F350000DCD4

- Timestamp: 0x4AB40E
- Time diff: 4409
- Payload: 10 bytes `000000007F350000DCD4`
- Commands:
  - 响应帧 (卡片→阅读器)
- Details:
  - 有效位: 0 (8 bits (完整字节))
  - 响应标志: 0x00 (二进制 00000000)
    - bit1 (0x01) ERROR: 0 = 无错误
    - bit2~bit3: RFU (保留，应为 0)
    - bit4 (0x08) Protocol Extension: 0 = 无协议扩展
    - bit5~bit8: RFU (保留，应为 0)
  - 对应请求命令: 0xAB (GET_NXP_SYSTEM_INFO (获取NXP系统信息))
  - 预期响应结构: [FLAG][PP pointer][PP conditions][Lock bits][Feature flags(32)][CRC16]
    - PP pointer(密码保护指针地址): 0x00
    - PP conditions: 0x00
      - bit1 = 0 → RL：Page L 读密码保护
      - bit2 = 0 → WL：Page L 写密码保护
      - bit5 = 0 → RH：Page H 读密码保护
      - bit6 = 0 → WH：Page H 写密码保护
    - Lock bits: 0x00
      - bit1 = 0 → AFI 锁定
      - bit2 = 0 → EAS 锁定
      - bit3 = 0 → DSFID 锁定
      - bit4 = 0 → PP：密码保护指针地址与访问条件锁定
    - Feature flags: 7F 35 00 00 (32 位, LSB 优先，以下列出置位项)
      - bit1 = 1 → UM PP：用户存储区密码保护
      - bit2 = 1 → COUNTER：计数器功能
      - bit3 = 1 → EAS ID：EAS ALARM 携带 EAS ID
      - bit4 = 1 → EAS PP：EAS 密码保护
      - bit5 = 1 → AFI PP：AFI 密码保护
      - bit6 = 1 → INVENTORY READ EXT：INVENTORY READ 扩展模式
      - bit7 = 1 → EAS IR：扩展模式下可做 EAS 选择
      - bit9 = 1 → ORIGINALITY SIG：READ SIGNATURE 命令
      - bit11 = 1 → P QUIET：STAY QUIET PERSISTENT
      - bit13 = 1 → PRIVACY：ENABLE PRIVACY
      - bit14 = 1 → DESTROY：DESTROY 命令
  - CRC16: 字段 DC D4 (低字节在前 → 0xD4DC)
    - 校验: 通过 (整帧 crc16_V = 0x0F47, 期望 0x0F47)

### [#15] > 3E004A8554000400022B26A3

- Timestamp: 0x4A8554
- Time diff: 11962
- Payload: 4 bytes `022B26A3`
- Commands:
  - GET SYSTEM INFORMATION (获取系统信息) (0x2B)
- Details:
  - 有效位: 0 (8 bits + 校验位)
  - Flags: 0x02 (二进制 00000010)
    - bit3 决定 bit5~bit8 的定义方式: 非寻卡模式 (Inventory=0)
    - bit1 (0x01): 0 = 应答使用单个子载波 (ASK)
    - bit2 (0x02): 1 = 高速数据速率
    - bit3 (0x04): 0 = 非寻卡请求
    - bit4 (0x08): 0 = 无协议扩展 (RFU)
    - bit5 (0x10) [非寻卡模式]: 0 = 非 Select
    - bit6 (0x20) [非寻卡模式]: 0 = 不含地址(UID)
    - bit7 (0x40) [非寻卡模式]: 0 = Option 清零
    - bit8 (0x80) [非寻卡模式]: 0 = RFU (保留)
    - 标志位决定的后续参数:
  - 命令码: 0x2B (GET SYSTEM INFORMATION (获取系统信息))
  - CRC16: 字段 26 A3 (低字节在前 → 0xA326)
    - 校验: 通过 (整帧 crc16_V = 0x0F47, 期望 0x0F47)

### [#16] < 3C004A7EBA001100000F02596D17090104E000004F0301C9C2

- Timestamp: 0x4A7EBA
- Time diff: 1690
- Payload: 17 bytes `000F02596D17090104E000004F0301C9C2`
- Commands:
  - 响应帧 (卡片→阅读器)
- Details:
  - 有效位: 0 (8 bits (完整字节))
  - 响应标志: 0x00 (二进制 00000000)
    - bit1 (0x01) ERROR: 0 = 无错误
    - bit2~bit3: RFU (保留，应为 0)
    - bit4 (0x08) Protocol Extension: 0 = 无协议扩展
    - bit5~bit8: RFU (保留，应为 0)
  - 对应请求命令: 0x2B (GET SYSTEM INFORMATION (获取系统信息))
  - 预期响应结构: [FLAG][Info flags][UID(8)][按 Info flags 存在的字段][CRC16]
    - Info flags: 0x0F
      - bit1 = 1 → DSFID 字段存在
      - bit2 = 1 → AFI 字段存在
      - bit3 = 1 → 存储容量字段存在
      - bit4 = 1 → IC 参考字段存在
      - bit5 = 0 → 块数量(2 字节)+块大小(1 字节)字段存在
    - UID (显示序): E0 04 01 09 17 6D 59 02
    - UID (传输序): 02 59 6D 17 09 01 04 E0
    - IC 制造商代码: 0x04 → NXP Semiconductors
    - TAG/IC 类型: 0x01
    - ICODE 变体判定: 序列号区 bit37=0, bit36=1 (显示序第4字节 0x09) → NXP ICODE SLI-X2 (SL2S2602)
    - 识别厂商: NXP (NXP Semiconductors)
    - 卡片型号: NXP ICODE SLI-X2 (SL2S2602)
    - 型号备注: TAG 类型码 0x01 为 NXP ICODE SLI / SLI-X / SLI-X2 共用，由 UID 序列号区 bit37/bit36 细分（见下方 ICODE 变体判定）
    - DSFID: 0x00
    - AFI: 0x00
    - 存储容量字段: 0x4F
    - IC 参考: 0x03
    - 未解析的剩余字节: 01
  - CRC16: 字段 C9 C2 (低字节在前 → 0xC2C9)
    - 校验: 通过 (整帧 crc16_V = 0x0F47, 期望 0x0F47)

### [#17] > 3E004A44E9000D0022BD0402596D17090104E0A07D

- Timestamp: 0x4A44E9
- Time diff: 14801
- Payload: 13 bytes `22BD0402596D17090104E0A07D`
- Commands:
  - NXP READ_SIGNATURE (读取签名) (0xBD)
- Details:
  - 有效位: 0 (8 bits + 校验位)
  - Flags: 0x22 (二进制 00100010)
    - bit3 决定 bit5~bit8 的定义方式: 非寻卡模式 (Inventory=0)
    - bit1 (0x01): 0 = 应答使用单个子载波 (ASK)
    - bit2 (0x02): 1 = 高速数据速率
    - bit3 (0x04): 0 = 非寻卡请求
    - bit4 (0x08): 0 = 无协议扩展 (RFU)
    - bit5 (0x10) [非寻卡模式]: 0 = 非 Select
    - bit6 (0x20) [非寻卡模式]: 1 = Address (请求中含 8 字节 UID 寻址)
    - bit7 (0x40) [非寻卡模式]: 0 = Option 清零
    - bit8 (0x80) [非寻卡模式]: 0 = RFU (保留)
    - 标志位决定的后续参数:
        - bit6=1 → 请求中含 8 字节 UID（传输时 0xE0 为最后一个字节）；个别命令在 UID 之前另有参数字节，UID 之后的字节才是命令参数
  - 命令码: 0xBD (厂商私有命令)
    - IC Mfg code: 0x04 → NXP Semiconductors (NXP 私有命令在命令码之后携带的 IC 制造商代码，UID 位于其后)
    - UID (显示序): E0 04 01 09 17 6D 59 02
    - UID (传输序): 02 59 6D 17 09 01 04 E0
    - IC 制造商代码: 0x04 → NXP Semiconductors
    - TAG/IC 类型: 0x01
    - ICODE 变体判定: 序列号区 bit37=0, bit36=1 (显示序第4字节 0x09) → NXP ICODE SLI-X2 (SL2S2602)
    - 识别厂商: NXP (NXP Semiconductors)
    - 卡片型号: NXP ICODE SLI-X2 (SL2S2602)
    - 型号备注: TAG 类型码 0x01 为 NXP ICODE SLI / SLI-X / SLI-X2 共用，由 UID 序列号区 bit37/bit36 细分（见下方 ICODE 变体判定）
    - 按卡片厂商 NXP 的定义解析
    - NXP: READ_SIGNATURE (读取签名)
  - CRC16: 字段 A0 7D (低字节在前 → 0x7DA0)
    - 校验: 通过 (整帧 crc16_V = 0x0F47, 期望 0x0F47)

### [#18] < 3C004A33B00023000034AD03FE192A8BD0806830450BF285357E417D44D031DB156CA783B2C558E7ADDD83

- Timestamp: 0x4A33B0
- Time diff: 4409
- Payload: 35 bytes `0034AD03FE192A8BD0806830450BF285357E417D44D031DB156CA783B2C558E7ADDD83`
- Commands:
  - 响应帧 (卡片→阅读器)
- Details:
  - 有效位: 0 (8 bits (完整字节))
  - 响应标志: 0x00 (二进制 00000000)
    - bit1 (0x01) ERROR: 0 = 无错误
    - bit2~bit3: RFU (保留，应为 0)
    - bit4 (0x08) Protocol Extension: 0 = 无协议扩展
    - bit5~bit8: RFU (保留，应为 0)
  - 对应请求命令: 0xBD (READ_SIGNATURE (读取签名))
  - 预期响应结构: [FLAG][签名(32 字节)][CRC16]
    - 签名数据(32 字节): 34 AD 03 FE 19 2A 8B D0 80 68 30 45 0B F2 85 35 7E 41 7D 44 D0 31 DB 15 6C A7 83 B2 C5 58 E7 AD
  - CRC16: 字段 DD 83 (低字节在前 → 0x83DD)
    - 校验: 通过 (整帧 crc16_V = 0x0F47, 期望 0x0F47)

### [#19] > 3E0049ECA5000D0022A50402596D17090104E0DBC6

- Timestamp: 0x49ECA5
- Time diff: 18187
- Payload: 13 bytes `22A50402596D17090104E0DBC6`
- Commands:
  - NXP EAS_ALARM (EAS报警) (0xA5)
- Details:
  - 有效位: 0 (8 bits + 校验位)
  - Flags: 0x22 (二进制 00100010)
    - bit3 决定 bit5~bit8 的定义方式: 非寻卡模式 (Inventory=0)
    - bit1 (0x01): 0 = 应答使用单个子载波 (ASK)
    - bit2 (0x02): 1 = 高速数据速率
    - bit3 (0x04): 0 = 非寻卡请求
    - bit4 (0x08): 0 = 无协议扩展 (RFU)
    - bit5 (0x10) [非寻卡模式]: 0 = 非 Select
    - bit6 (0x20) [非寻卡模式]: 1 = Address (请求中含 8 字节 UID 寻址)
    - bit7 (0x40) [非寻卡模式]: 0 = Option 清零
    - bit8 (0x80) [非寻卡模式]: 0 = RFU (保留)
    - 标志位决定的后续参数:
        - bit6=1 → 请求中含 8 字节 UID（传输时 0xE0 为最后一个字节）；个别命令在 UID 之前另有参数字节，UID 之后的字节才是命令参数
  - 命令码: 0xA5 (厂商私有命令)
    - IC Mfg code: 0x04 → NXP Semiconductors (NXP 私有命令在命令码之后携带的 IC 制造商代码，UID 位于其后)
    - UID (显示序): E0 04 01 09 17 6D 59 02
    - UID (传输序): 02 59 6D 17 09 01 04 E0
    - IC 制造商代码: 0x04 → NXP Semiconductors
    - TAG/IC 类型: 0x01
    - ICODE 变体判定: 序列号区 bit37=0, bit36=1 (显示序第4字节 0x09) → NXP ICODE SLI-X2 (SL2S2602)
    - 识别厂商: NXP (NXP Semiconductors)
    - 卡片型号: NXP ICODE SLI-X2 (SL2S2602)
    - 型号备注: TAG 类型码 0x01 为 NXP ICODE SLI / SLI-X / SLI-X2 共用，由 UID 序列号区 bit37/bit36 细分（见下方 ICODE 变体判定）
    - 按卡片厂商 NXP 的定义解析
    - NXP: EAS_ALARM (EAS报警)
  - CRC16: 字段 DB C6 (低字节在前 → 0xC6DB)
    - 校验: 通过 (整帧 crc16_V = 0x0F47, 期望 0x0F47)

### [#20] > 3E003A9AA9000D00222002596D17090104E00035F0

- Timestamp: 0x3A9AA9
- Time diff: 1004028
- Payload: 13 bytes `222002596D17090104E00035F0`
- Commands:
  - READ SINGLE BLOCK (读单个块) (0x20)
- Details:
  - 有效位: 0 (8 bits + 校验位)
  - Flags: 0x22 (二进制 00100010)
    - bit3 决定 bit5~bit8 的定义方式: 非寻卡模式 (Inventory=0)
    - bit1 (0x01): 0 = 应答使用单个子载波 (ASK)
    - bit2 (0x02): 1 = 高速数据速率
    - bit3 (0x04): 0 = 非寻卡请求
    - bit4 (0x08): 0 = 无协议扩展 (RFU)
    - bit5 (0x10) [非寻卡模式]: 0 = 非 Select
    - bit6 (0x20) [非寻卡模式]: 1 = Address (请求中含 8 字节 UID 寻址)
    - bit7 (0x40) [非寻卡模式]: 0 = Option 清零
    - bit8 (0x80) [非寻卡模式]: 0 = RFU (保留)
    - 标志位决定的后续参数:
        - bit6=1 → 请求中含 8 字节 UID（传输时 0xE0 为最后一个字节）；个别命令在 UID 之前另有参数字节，UID 之后的字节才是命令参数
  - 命令码: 0x20 (READ SINGLE BLOCK (读单个块))
    - UID (显示序): E0 04 01 09 17 6D 59 02
    - UID (传输序): 02 59 6D 17 09 01 04 E0
    - IC 制造商代码: 0x04 → NXP Semiconductors
    - TAG/IC 类型: 0x01
    - ICODE 变体判定: 序列号区 bit37=0, bit36=1 (显示序第4字节 0x09) → NXP ICODE SLI-X2 (SL2S2602)
    - 识别厂商: NXP (NXP Semiconductors)
    - 卡片型号: NXP ICODE SLI-X2 (SL2S2602)
    - 型号备注: TAG 类型码 0x01 为 NXP ICODE SLI / SLI-X / SLI-X2 共用，由 UID 序列号区 bit37/bit36 细分（见下方 ICODE 变体判定）
    - 块号: 0
  - CRC16: 字段 35 F0 (低字节在前 → 0xF035)
    - 校验: 通过 (整帧 crc16_V = 0x0F47, 期望 0x0F47)

### [#21] < 3C003A8971000700000000000077CF

- Timestamp: 0x3A8971
- Time diff: 4408
- Payload: 7 bytes `000000000077CF`
- Commands:
  - 响应帧 (卡片→阅读器)
- Details:
  - 有效位: 0 (8 bits (完整字节))
  - 响应标志: 0x00 (二进制 00000000)
    - bit1 (0x01) ERROR: 0 = 无错误
    - bit2~bit3: RFU (保留，应为 0)
    - bit4 (0x08) Protocol Extension: 0 = 无协议扩展
    - bit5~bit8: RFU (保留，应为 0)
  - 对应请求命令: 0x20 (READ SINGLE BLOCK (读单个块))
  - 预期响应结构: [FLAG][块数据][CRC16]
    - 块数据(4 字节): 00 00 00 00
  - CRC16: 字段 77 CF (低字节在前 → 0xCF77)
    - 校验: 通过 (整帧 crc16_V = 0x0F47, 期望 0x0F47)

### [#22] > 3E003A69E7000E00222C02596D17090104E0004FAACE

- Timestamp: 0x3A69E7
- Time diff: 8074
- Payload: 14 bytes `222C02596D17090104E0004FAACE`
- Commands:
  - GET MULTIPLE BLOCK SECURITY STATUS (获取多块安全状态) (0x2C)
- Details:
  - 有效位: 0 (8 bits + 校验位)
  - Flags: 0x22 (二进制 00100010)
    - bit3 决定 bit5~bit8 的定义方式: 非寻卡模式 (Inventory=0)
    - bit1 (0x01): 0 = 应答使用单个子载波 (ASK)
    - bit2 (0x02): 1 = 高速数据速率
    - bit3 (0x04): 0 = 非寻卡请求
    - bit4 (0x08): 0 = 无协议扩展 (RFU)
    - bit5 (0x10) [非寻卡模式]: 0 = 非 Select
    - bit6 (0x20) [非寻卡模式]: 1 = Address (请求中含 8 字节 UID 寻址)
    - bit7 (0x40) [非寻卡模式]: 0 = Option 清零
    - bit8 (0x80) [非寻卡模式]: 0 = RFU (保留)
    - 标志位决定的后续参数:
        - bit6=1 → 请求中含 8 字节 UID（传输时 0xE0 为最后一个字节）；个别命令在 UID 之前另有参数字节，UID 之后的字节才是命令参数
  - 命令码: 0x2C (GET MULTIPLE BLOCK SECURITY STATUS (获取多块安全状态))
    - UID (显示序): E0 04 01 09 17 6D 59 02
    - UID (传输序): 02 59 6D 17 09 01 04 E0
    - IC 制造商代码: 0x04 → NXP Semiconductors
    - TAG/IC 类型: 0x01
    - ICODE 变体判定: 序列号区 bit37=0, bit36=1 (显示序第4字节 0x09) → NXP ICODE SLI-X2 (SL2S2602)
    - 识别厂商: NXP (NXP Semiconductors)
    - 卡片型号: NXP ICODE SLI-X2 (SL2S2602)
    - 型号备注: TAG 类型码 0x01 为 NXP ICODE SLI / SLI-X / SLI-X2 共用，由 UID 序列号区 bit37/bit36 细分（见下方 ICODE 变体判定）
    - 起始块: 0
    - 块数量: 79
  - CRC16: 字段 AA CE (低字节在前 → 0xCEAA)
    - 校验: 通过 (整帧 crc16_V = 0x0F47, 期望 0x0F47)

### [#23] < 3C003A5781005300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000BF80

- Timestamp: 0x3A5781
- Time diff: 4710
- Payload: 83 bytes `000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000BF80`
- Commands:
  - 响应帧 (卡片→阅读器)
- Details:
  - 有效位: 0 (8 bits (完整字节))
  - 响应标志: 0x00 (二进制 00000000)
    - bit1 (0x01) ERROR: 0 = 无错误
    - bit2~bit3: RFU (保留，应为 0)
    - bit4 (0x08) Protocol Extension: 0 = 无协议扩展
    - bit5~bit8: RFU (保留，应为 0)
  - 对应请求命令: 0x2C (GET MULTIPLE BLOCK SECURITY STATUS (获取多块安全状态))
  - 预期响应结构: [FLAG][各块安全状态位图(每块 1 位)][CRC16]
    - 安全状态位图: 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00
    - 已锁定(位=1)的块号(从 1 起): 无
  - CRC16: 字段 BF 80 (低字节在前 → 0x80BF)
    - 校验: 通过 (整帧 crc16_V = 0x0F47, 期望 0x0F47)

### [#24] > 3E0039D402000E00222302596D17090104E000085DE4

- Timestamp: 0x39D402
- Time diff: 33663
- Payload: 14 bytes `222302596D17090104E000085DE4`
- Commands:
  - READ MULTIPLE BLOCKS (读多个块) (0x23)
- Details:
  - 有效位: 0 (8 bits + 校验位)
  - Flags: 0x22 (二进制 00100010)
    - bit3 决定 bit5~bit8 的定义方式: 非寻卡模式 (Inventory=0)
    - bit1 (0x01): 0 = 应答使用单个子载波 (ASK)
    - bit2 (0x02): 1 = 高速数据速率
    - bit3 (0x04): 0 = 非寻卡请求
    - bit4 (0x08): 0 = 无协议扩展 (RFU)
    - bit5 (0x10) [非寻卡模式]: 0 = 非 Select
    - bit6 (0x20) [非寻卡模式]: 1 = Address (请求中含 8 字节 UID 寻址)
    - bit7 (0x40) [非寻卡模式]: 0 = Option 清零
    - bit8 (0x80) [非寻卡模式]: 0 = RFU (保留)
    - 标志位决定的后续参数:
        - bit6=1 → 请求中含 8 字节 UID（传输时 0xE0 为最后一个字节）；个别命令在 UID 之前另有参数字节，UID 之后的字节才是命令参数
  - 命令码: 0x23 (READ MULTIPLE BLOCKS (读多个块))
    - UID (显示序): E0 04 01 09 17 6D 59 02
    - UID (传输序): 02 59 6D 17 09 01 04 E0
    - IC 制造商代码: 0x04 → NXP Semiconductors
    - TAG/IC 类型: 0x01
    - ICODE 变体判定: 序列号区 bit37=0, bit36=1 (显示序第4字节 0x09) → NXP ICODE SLI-X2 (SL2S2602)
    - 识别厂商: NXP (NXP Semiconductors)
    - 卡片型号: NXP ICODE SLI-X2 (SL2S2602)
    - 型号备注: TAG 类型码 0x01 为 NXP ICODE SLI / SLI-X / SLI-X2 共用，由 UID 序列号区 bit37/bit36 细分（见下方 ICODE 变体判定）
    - 起始块: 0
    - 块数量: 8
  - CRC16: 字段 5D E4 (低字节在前 → 0xE45D)
    - 校验: 通过 (整帧 crc16_V = 0x0F47, 期望 0x0F47)

### [#25] < 3C0039C19C00270000000000000000000000000000000000000000000000000000000000000000000000000000D26A

- Timestamp: 0x39C19C
- Time diff: 4710
- Payload: 39 bytes `00000000000000000000000000000000000000000000000000000000000000000000000000D26A`
- Commands:
  - 响应帧 (卡片→阅读器)
- Details:
  - 有效位: 0 (8 bits (完整字节))
  - 响应标志: 0x00 (二进制 00000000)
    - bit1 (0x01) ERROR: 0 = 无错误
    - bit2~bit3: RFU (保留，应为 0)
    - bit4 (0x08) Protocol Extension: 0 = 无协议扩展
    - bit5~bit8: RFU (保留，应为 0)
  - 对应请求命令: 0x23 (READ MULTIPLE BLOCKS (读多个块))
  - 预期响应结构: [FLAG][多块数据][CRC16]
    - 块数据(36 字节): 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00
  - CRC16: 字段 D2 6A (低字节在前 → 0x6AD2)
    - 校验: 通过 (整帧 crc16_V = 0x0F47, 期望 0x0F47)

### [#26] > 3E00396E99000E00622302596D17090104E000317F1F

- Timestamp: 0x396E99
- Time diff: 21251
- Payload: 14 bytes `622302596D17090104E000317F1F`
- Commands:
  - READ MULTIPLE BLOCKS (读多个块) (0x23)
- Details:
  - 有效位: 0 (8 bits + 校验位)
  - Flags: 0x62 (二进制 01100010)
    - bit3 决定 bit5~bit8 的定义方式: 非寻卡模式 (Inventory=0)
    - bit1 (0x01): 0 = 应答使用单个子载波 (ASK)
    - bit2 (0x02): 1 = 高速数据速率
    - bit3 (0x04): 0 = 非寻卡请求
    - bit4 (0x08): 0 = 无协议扩展 (RFU)
    - bit5 (0x10) [非寻卡模式]: 0 = 非 Select
    - bit6 (0x20) [非寻卡模式]: 1 = Address (请求中含 8 字节 UID 寻址)
    - bit7 (0x40) [非寻卡模式]: 1 = Option 置位 (命令相关选项)
    - bit8 (0x80) [非寻卡模式]: 0 = RFU (保留)
    - 标志位决定的后续参数:
        - bit6=1 → 请求中含 8 字节 UID（传输时 0xE0 为最后一个字节）；个别命令在 UID 之前另有参数字节，UID 之后的字节才是命令参数
        - bit7=1 → 末尾附加该命令定义的 Option 参数(命令相关)
  - 命令码: 0x23 (READ MULTIPLE BLOCKS (读多个块))
    - UID (显示序): E0 04 01 09 17 6D 59 02
    - UID (传输序): 02 59 6D 17 09 01 04 E0
    - IC 制造商代码: 0x04 → NXP Semiconductors
    - TAG/IC 类型: 0x01
    - ICODE 变体判定: 序列号区 bit37=0, bit36=1 (显示序第4字节 0x09) → NXP ICODE SLI-X2 (SL2S2602)
    - 识别厂商: NXP (NXP Semiconductors)
    - 卡片型号: NXP ICODE SLI-X2 (SL2S2602)
    - 型号备注: TAG 类型码 0x01 为 NXP ICODE SLI / SLI-X / SLI-X2 共用，由 UID 序列号区 bit37/bit36 细分（见下方 ICODE 变体判定）
    - 起始块: 0
    - 块数量: 49
  - CRC16: 字段 7F 1F (低字节在前 → 0x1F7F)
    - 校验: 通过 (整帧 crc16_V = 0x0F47, 期望 0x0F47)

### [#27] < 3C00395C3200FD0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002428

- Timestamp: 0x395C32
- Time diff: 4711
- Payload: 253 bytes `00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002428`
- Commands:
  - 响应帧 (卡片→阅读器)
- Details:
  - 有效位: 0 (8 bits (完整字节))
  - 响应标志: 0x00 (二进制 00000000)
    - bit1 (0x01) ERROR: 0 = 无错误
    - bit2~bit3: RFU (保留，应为 0)
    - bit4 (0x08) Protocol Extension: 0 = 无协议扩展
    - bit5~bit8: RFU (保留，应为 0)
  - 对应请求命令: 0x23 (READ MULTIPLE BLOCKS (读多个块))
  - 预期响应结构: [FLAG][多块数据][CRC16]
    - 块数据(250 字节): 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00
  - CRC16: 字段 24 28 (低字节在前 → 0x2824)
    - 校验: 通过 (整帧 crc16_V = 0x0F47, 期望 0x0F47)

### [#28] > 3E0037FB77000E00622302596D17090104E0321D0371

- Timestamp: 0x37FB77
- Time diff: 90299
- Payload: 14 bytes `622302596D17090104E0321D0371`
- Commands:
  - READ MULTIPLE BLOCKS (读多个块) (0x23)
- Details:
  - 有效位: 0 (8 bits + 校验位)
  - Flags: 0x62 (二进制 01100010)
    - bit3 决定 bit5~bit8 的定义方式: 非寻卡模式 (Inventory=0)
    - bit1 (0x01): 0 = 应答使用单个子载波 (ASK)
    - bit2 (0x02): 1 = 高速数据速率
    - bit3 (0x04): 0 = 非寻卡请求
    - bit4 (0x08): 0 = 无协议扩展 (RFU)
    - bit5 (0x10) [非寻卡模式]: 0 = 非 Select
    - bit6 (0x20) [非寻卡模式]: 1 = Address (请求中含 8 字节 UID 寻址)
    - bit7 (0x40) [非寻卡模式]: 1 = Option 置位 (命令相关选项)
    - bit8 (0x80) [非寻卡模式]: 0 = RFU (保留)
    - 标志位决定的后续参数:
        - bit6=1 → 请求中含 8 字节 UID（传输时 0xE0 为最后一个字节）；个别命令在 UID 之前另有参数字节，UID 之后的字节才是命令参数
        - bit7=1 → 末尾附加该命令定义的 Option 参数(命令相关)
  - 命令码: 0x23 (READ MULTIPLE BLOCKS (读多个块))
    - UID (显示序): E0 04 01 09 17 6D 59 02
    - UID (传输序): 02 59 6D 17 09 01 04 E0
    - IC 制造商代码: 0x04 → NXP Semiconductors
    - TAG/IC 类型: 0x01
    - ICODE 变体判定: 序列号区 bit37=0, bit36=1 (显示序第4字节 0x09) → NXP ICODE SLI-X2 (SL2S2602)
    - 识别厂商: NXP (NXP Semiconductors)
    - 卡片型号: NXP ICODE SLI-X2 (SL2S2602)
    - 型号备注: TAG 类型码 0x01 为 NXP ICODE SLI / SLI-X / SLI-X2 共用，由 UID 序列号区 bit37/bit36 细分（见下方 ICODE 变体判定）
    - 起始块: 50
    - 块数量: 29
  - CRC16: 字段 03 71 (低字节在前 → 0x7103)
    - 校验: 通过 (整帧 crc16_V = 0x0F47, 期望 0x0F47)

### [#29] < 3C0037E911009900000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001EFC

- Timestamp: 0x37E911
- Time diff: 4710
- Payload: 153 bytes `000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001EFC`
- Commands:
  - 响应帧 (卡片→阅读器)
- Details:
  - 有效位: 0 (8 bits (完整字节))
  - 响应标志: 0x00 (二进制 00000000)
    - bit1 (0x01) ERROR: 0 = 无错误
    - bit2~bit3: RFU (保留，应为 0)
    - bit4 (0x08) Protocol Extension: 0 = 无协议扩展
    - bit5~bit8: RFU (保留，应为 0)
  - 对应请求命令: 0x23 (READ MULTIPLE BLOCKS (读多个块))
  - 预期响应结构: [FLAG][多块数据][CRC16]
    - 块数据(150 字节): 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00
  - CRC16: 字段 1E FC (低字节在前 → 0xFC1E)
    - 校验: 通过 (整帧 crc16_V = 0x0F47, 期望 0x0F47)

### [#30] > 3E0036FF29000D0022B20402596D17090104E07CD0

- Timestamp: 0x36FF29
- Time diff: 59880
- Payload: 13 bytes `22B20402596D17090104E07CD0`
- Commands:
  - NXP GET_RANDOM_NUMBER (获取随机数) (0xB2)
- Details:
  - 有效位: 0 (8 bits + 校验位)
  - Flags: 0x22 (二进制 00100010)
    - bit3 决定 bit5~bit8 的定义方式: 非寻卡模式 (Inventory=0)
    - bit1 (0x01): 0 = 应答使用单个子载波 (ASK)
    - bit2 (0x02): 1 = 高速数据速率
    - bit3 (0x04): 0 = 非寻卡请求
    - bit4 (0x08): 0 = 无协议扩展 (RFU)
    - bit5 (0x10) [非寻卡模式]: 0 = 非 Select
    - bit6 (0x20) [非寻卡模式]: 1 = Address (请求中含 8 字节 UID 寻址)
    - bit7 (0x40) [非寻卡模式]: 0 = Option 清零
    - bit8 (0x80) [非寻卡模式]: 0 = RFU (保留)
    - 标志位决定的后续参数:
        - bit6=1 → 请求中含 8 字节 UID（传输时 0xE0 为最后一个字节）；个别命令在 UID 之前另有参数字节，UID 之后的字节才是命令参数
  - 命令码: 0xB2 (厂商私有命令)
    - IC Mfg code: 0x04 → NXP Semiconductors (NXP 私有命令在命令码之后携带的 IC 制造商代码，UID 位于其后)
    - UID (显示序): E0 04 01 09 17 6D 59 02
    - UID (传输序): 02 59 6D 17 09 01 04 E0
    - IC 制造商代码: 0x04 → NXP Semiconductors
    - TAG/IC 类型: 0x01
    - ICODE 变体判定: 序列号区 bit37=0, bit36=1 (显示序第4字节 0x09) → NXP ICODE SLI-X2 (SL2S2602)
    - 识别厂商: NXP (NXP Semiconductors)
    - 卡片型号: NXP ICODE SLI-X2 (SL2S2602)
    - 型号备注: TAG 类型码 0x01 为 NXP ICODE SLI / SLI-X / SLI-X2 共用，由 UID 序列号区 bit37/bit36 细分（见下方 ICODE 变体判定）
    - 按卡片厂商 NXP 的定义解析
    - NXP: GET_RANDOM_NUMBER (获取随机数)
  - CRC16: 字段 7C D0 (低字节在前 → 0xD07C)
    - 校验: 通过 (整帧 crc16_V = 0x0F47, 期望 0x0F47)

### [#31] < 3C0036EDF100050000C54D3FEB

- Timestamp: 0x36EDF1
- Time diff: 4408
- Payload: 5 bytes `00C54D3FEB`
- Commands:
  - 响应帧 (卡片→阅读器)
- Details:
  - 有效位: 0 (8 bits (完整字节))
  - 响应标志: 0x00 (二进制 00000000)
    - bit1 (0x01) ERROR: 0 = 无错误
    - bit2~bit3: RFU (保留，应为 0)
    - bit4 (0x08) Protocol Extension: 0 = 无协议扩展
    - bit5~bit8: RFU (保留，应为 0)
  - 对应请求命令: 0xB2 (GET_RANDOM_NUMBER (获取随机数))
  - 预期响应结构: [FLAG][随机数(2 字节)][CRC16]
    - 随机数: 0xC54D
  - CRC16: 字段 3F EB (低字节在前 → 0xEB3F)
    - 校验: 通过 (整帧 crc16_V = 0x0F47, 期望 0x0F47)

### [#32] > 3E0036CFE000120022B30402596D17090104E0B8DC48D14A071D

- Timestamp: 0x36CFE0
- Time diff: 7697
- Payload: 18 bytes `22B30402596D17090104E0B8DC48D14A071D`
- Commands:
  - NXP SET_PASSWORD (设置密码) (0xB3)
- Details:
  - 有效位: 0 (8 bits + 校验位)
  - Flags: 0x22 (二进制 00100010)
    - bit3 决定 bit5~bit8 的定义方式: 非寻卡模式 (Inventory=0)
    - bit1 (0x01): 0 = 应答使用单个子载波 (ASK)
    - bit2 (0x02): 1 = 高速数据速率
    - bit3 (0x04): 0 = 非寻卡请求
    - bit4 (0x08): 0 = 无协议扩展 (RFU)
    - bit5 (0x10) [非寻卡模式]: 0 = 非 Select
    - bit6 (0x20) [非寻卡模式]: 1 = Address (请求中含 8 字节 UID 寻址)
    - bit7 (0x40) [非寻卡模式]: 0 = Option 清零
    - bit8 (0x80) [非寻卡模式]: 0 = RFU (保留)
    - 标志位决定的后续参数:
        - bit6=1 → 请求中含 8 字节 UID（传输时 0xE0 为最后一个字节）；个别命令在 UID 之前另有参数字节，UID 之后的字节才是命令参数
  - 命令码: 0xB3 (厂商私有命令)
    - IC Mfg code: 0x04 → NXP Semiconductors (NXP 私有命令在命令码之后携带的 IC 制造商代码，UID 位于其后)
    - UID (显示序): E0 04 01 09 17 6D 59 02
    - UID (传输序): 02 59 6D 17 09 01 04 E0
    - IC 制造商代码: 0x04 → NXP Semiconductors
    - TAG/IC 类型: 0x01
    - ICODE 变体判定: 序列号区 bit37=0, bit36=1 (显示序第4字节 0x09) → NXP ICODE SLI-X2 (SL2S2602)
    - 识别厂商: NXP (NXP Semiconductors)
    - 卡片型号: NXP ICODE SLI-X2 (SL2S2602)
    - 型号备注: TAG 类型码 0x01 为 NXP ICODE SLI / SLI-X / SLI-X2 共用，由 UID 序列号区 bit37/bit36 细分（见下方 ICODE 变体判定）
    - 按卡片厂商 NXP 的定义解析
    - NXP: SET_PASSWORD (设置密码)
    - 密码标识: 0xB8
    - 密码: DC48D14A
  - CRC16: 字段 07 1D (低字节在前 → 0x1D07)
    - 校验: 通过 (整帧 crc16_V = 0x0F47, 期望 0x0F47)

### [#33] < 3C0036B8C10003000078F0

- Timestamp: 0x36B8C1
- Time diff: 5919
- Payload: 3 bytes `0078F0`
- Commands:
  - 响应帧 (卡片→阅读器)
- Details:
  - 有效位: 0 (8 bits (完整字节))
  - 响应标志: 0x00 (二进制 00000000)
    - bit1 (0x01) ERROR: 0 = 无错误
    - bit2~bit3: RFU (保留，应为 0)
    - bit4 (0x08) Protocol Extension: 0 = 无协议扩展
    - bit5~bit8: RFU (保留，应为 0)
  - 对应请求命令: 0xB3 (SET_PASSWORD (设置密码))
  - 预期响应结构: [FLAG][CRC16]
    - 命令执行成功，无数据返回
  - CRC16: 字段 78 F0 (低字节在前 → 0xF078)
    - 校验: 通过 (整帧 crc16_V = 0x0F47, 期望 0x0F47)

### [#34] > 3E00369CAA000D0022BE0402596D17090104E0C909

- Timestamp: 0x369CAA
- Time diff: 7191
- Payload: 13 bytes `22BE0402596D17090104E0C909`
- Commands:
  - NXP 未定义私有命令 (0xBE)
- Details:
  - 有效位: 0 (8 bits + 校验位)
  - Flags: 0x22 (二进制 00100010)
    - bit3 决定 bit5~bit8 的定义方式: 非寻卡模式 (Inventory=0)
    - bit1 (0x01): 0 = 应答使用单个子载波 (ASK)
    - bit2 (0x02): 1 = 高速数据速率
    - bit3 (0x04): 0 = 非寻卡请求
    - bit4 (0x08): 0 = 无协议扩展 (RFU)
    - bit5 (0x10) [非寻卡模式]: 0 = 非 Select
    - bit6 (0x20) [非寻卡模式]: 1 = Address (请求中含 8 字节 UID 寻址)
    - bit7 (0x40) [非寻卡模式]: 0 = Option 清零
    - bit8 (0x80) [非寻卡模式]: 0 = RFU (保留)
    - 标志位决定的后续参数:
        - bit6=1 → 请求中含 8 字节 UID（传输时 0xE0 为最后一个字节）；个别命令在 UID 之前另有参数字节，UID 之后的字节才是命令参数
  - 命令码: 0xBE (厂商私有命令)
    - IC Mfg code: 0x04 → NXP Semiconductors (NXP 私有命令在命令码之后携带的 IC 制造商代码，UID 位于其后)
    - UID (显示序): E0 04 01 09 17 6D 59 02
    - UID (传输序): 02 59 6D 17 09 01 04 E0
    - IC 制造商代码: 0x04 → NXP Semiconductors
    - TAG/IC 类型: 0x01
    - ICODE 变体判定: 序列号区 bit37=0, bit36=1 (显示序第4字节 0x09) → NXP ICODE SLI-X2 (SL2S2602)
    - 识别厂商: NXP (NXP Semiconductors)
    - 卡片型号: NXP ICODE SLI-X2 (SL2S2602)
    - 型号备注: TAG 类型码 0x01 为 NXP ICODE SLI / SLI-X / SLI-X2 共用，由 UID 序列号区 bit37/bit36 细分（见下方 ICODE 变体判定）
    - 按卡片厂商 NXP 的定义解析
    - 0xBE: NXP 未定义该私有命令
  - CRC16: 字段 C9 09 (低字节在前 → 0x09C9)
    - 校验: 通过 (整帧 crc16_V = 0x0F47, 期望 0x0F47)

### [#35] < 3C00368B710007000013031621B537

- Timestamp: 0x368B71
- Time diff: 4409
- Payload: 7 bytes `0013031621B537`
- Commands:
  - 响应帧 (卡片→阅读器)
- Details:
  - 有效位: 0 (8 bits (完整字节))
  - 响应标志: 0x00 (二进制 00000000)
    - bit1 (0x01) ERROR: 0 = 无错误
    - bit2~bit3: RFU (保留，应为 0)
    - bit4 (0x08) Protocol Extension: 0 = 无协议扩展
    - bit5~bit8: RFU (保留，应为 0)
  - 对应请求命令: 0xBE (未知命令 (0xBE))
    - 命令 0xBE 的响应结构未在表内定义
    - 原始数据: 13 03 16 21 B5 37
  - CRC16: 字段 B5 37 (低字节在前 → 0x37B5)
    - 校验: 通过 (整帧 crc16_V = 0x0F47, 期望 0x0F47)

### [#36] > 3E00088959000D0026014002596D17090104E0D7FF

- Timestamp: 0x088959
- Time diff: 3015192
- Payload: 13 bytes `26014002596D17090104E0D7FF`
- Commands:
  - INVENTORY (寻卡) (0x01)
- Details:
  - 有效位: 0 (8 bits + 校验位)
  - Flags: 0x26 (二进制 00100110)
    - bit3 决定 bit5~bit8 的定义方式: 寻卡模式 (Inventory=1)
    - bit1 (0x01): 0 = 应答使用单个子载波 (ASK)
    - bit2 (0x02): 1 = 高速数据速率
    - bit3 (0x04): 1 = 寻卡(Inventory)请求
    - bit4 (0x08): 0 = 无协议扩展 (RFU)
    - bit5 (0x10) [寻卡模式]: 0 = 无 AFI 字段
    - bit6 (0x20) [寻卡模式]: 1 = 1 个时隙 (1 slot)
    - bit7 (0x40) [寻卡模式]: 0 = Option 清零
    - bit8 (0x80) [寻卡模式]: 0 = RFU (保留)
    - 标志位决定的后续参数:
        - 命令码后为 Mask 长度(1 字节) + Mask 值(⌈Mask长度/8⌉ 字节)
        - bit6=0 时阅读器需对 16 个时隙做防冲突处理(多卡场景)
  - 命令码: 0x01 (INVENTORY (寻卡))
    - Mask长度: 64 bits
    - Mask: 02596D17090104E0
  - CRC16: 字段 D7 FF (低字节在前 → 0xFFD7)
    - 校验: 通过 (整帧 crc16_V = 0x0F47, 期望 0x0F47)

### [#37] < 3C00087821000C00000002596D17090104E0C24E

- Timestamp: 0x087821
- Time diff: 4408
- Payload: 12 bytes `000002596D17090104E0C24E`
- Commands:
  - 响应帧 (卡片→阅读器)
- Details:
  - 有效位: 0 (8 bits (完整字节))
  - 响应标志: 0x00 (二进制 00000000)
    - bit1 (0x01) ERROR: 0 = 无错误
    - bit2~bit3: RFU (保留，应为 0)
    - bit4 (0x08) Protocol Extension: 0 = 无协议扩展
    - bit5~bit8: RFU (保留，应为 0)
  - 对应请求命令: 0x01 (INVENTORY (寻卡))
  - 预期响应结构: [FLAG][DSFID][UID(8)][CRC16]
    - DSFID: 0x00
    - UID (显示序): E0 04 01 09 17 6D 59 02
    - UID (传输序): 02 59 6D 17 09 01 04 E0
    - IC 制造商代码: 0x04 → NXP Semiconductors
    - TAG/IC 类型: 0x01
    - ICODE 变体判定: 序列号区 bit37=0, bit36=1 (显示序第4字节 0x09) → NXP ICODE SLI-X2 (SL2S2602)
    - 识别厂商: NXP (NXP Semiconductors)
    - 卡片型号: NXP ICODE SLI-X2 (SL2S2602)
    - 型号备注: TAG 类型码 0x01 为 NXP ICODE SLI / SLI-X / SLI-X2 共用，由 UID 序列号区 bit37/bit36 细分（见下方 ICODE 变体判定）
  - CRC16: 字段 C2 4E (低字节在前 → 0x4EC2)
    - 校验: 通过 (整帧 crc16_V = 0x0F47, 期望 0x0F47)

