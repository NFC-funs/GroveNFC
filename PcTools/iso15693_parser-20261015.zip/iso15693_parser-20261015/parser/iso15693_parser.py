#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
ISO 15693 核心协议解析器
包含 Inventory、Read、Write 等标准命令

数据包格式：[方向1][时间戳4][长度2][有效位1][载荷N]
载荷格式：
  请求帧 (PCD -> PICC, 方向 '>')：[请求FLAG(1)][命令码(1)][参数/数据...]
  响应帧 (PICC -> PCD, 方向 '<')：[响应FLAG(1)][数据/错误码...]

标志位/错误码定义与项目内 ISO15_cmd.h 保持一致。
卡片厂商由 INVENTORY(0x01) 响应中的 UID（或带地址请求中的 UID）按制造商代码识别，
后续私有命令即按该厂商的定义解析。
"""

import struct
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from ui.language import Language
from parser.inventory_parser import InventoryParser
from parser.custom_commands import CustomCommandsParser


class ISO15693Parser:
    """ISO 15693 协议解析器"""

    # 请求标志位（与 ISO15_cmd.h 一致）
    FLAG_SUBCARRIER_SINGLE = 0x00
    FLAG_SUBCARRIER_TWO = 0x01
    FLAG_DATARATE_LOW = 0x00
    FLAG_DATARATE_HIGH = 0x02
    FLAG_NONINVENTORY = 0x00
    FLAG_INVENTORY = 0x04
    FLAG_PROTOCOL_EXT = 0x08
    # 非 Inventory 请求
    FLAG_SELECT = 0x10
    FLAG_ADDRESS = 0x20
    FLAG_OPTION = 0x40
    # Inventory 请求
    FLAG_INV_AFI = 0x10
    FLAG_INV_SLOT1 = 0x20

    # 响应标志位
    RSP_FLAG_ERROR = 0x01
    RSP_FLAG_EXT = 0x08

    # 命令码
    CMD_INVENTORY = 0x01
    CMD_STAY_QUIET = 0x02
    CMD_READ_SINGLE_BLOCK = 0x20
    CMD_WRITE_SINGLE_BLOCK = 0x21
    CMD_LOCK_BLOCK = 0x22
    CMD_READ_MULTIPLE_BLOCKS = 0x23
    CMD_WRITE_MULTIPLE_BLOCKS = 0x24
    CMD_SELECT = 0x25
    CMD_RESET_TO_READY = 0x26
    CMD_WRITE_AFI = 0x27
    CMD_LOCK_AFI = 0x28
    CMD_WRITE_DSFID = 0x29
    CMD_LOCK_DSFID = 0x2A
    CMD_GET_SYSTEM_INFO = 0x2B
    CMD_GET_MULTIPLE_BLOCK_SECURITY = 0x2C

    # 标准 ISO/IEC 15693-3 命令码 -> 名称
    STANDARD_COMMANDS = {
        0x01: "INVENTORY (寻卡)",
        0x02: "STAY QUIET (保持静默)",
        0x20: "READ SINGLE BLOCK (读单个块)",
        0x21: "WRITE SINGLE BLOCK (写单个块)",
        0x22: "LOCK BLOCK (锁定块)",
        0x23: "READ MULTIPLE BLOCKS (读多个块)",
        0x24: "WRITE MULTIPLE BLOCKS (写多个块)",
        0x25: "SELECT (选择)",
        0x26: "RESET TO READY (复位到就绪)",
        0x27: "WRITE AFI (写AFI)",
        0x28: "LOCK AFI (锁定AFI)",
        0x29: "WRITE DSFID (写DSFID)",
        0x2A: "LOCK DSFID (锁定DSFID)",
        0x2B: "GET SYSTEM INFORMATION (获取系统信息)",
        0x2C: "GET MULTIPLE BLOCK SECURITY STATUS (获取多块安全状态)",
    }

    # UID 显示序（MSB 优先）第 2 字节 = IC 制造商代码，取自 ISO/IEC 7816-6:
    # 该字节在传输序（LSB 优先）中位于 index 6
    MANUFACTURERS = {
        0x01: (None, "Motorola"),
        0x02: ("ST", "STMicroelectronics"),
        0x03: (None, "Hitachi"),
        0x04: ("NXP", "NXP Semiconductors"),
        0x05: (None, "Infineon Technologies"),
        0x06: (None, "Cylinc"),
        0x07: ("TI", "Texas Instruments"),
        0x08: (None, "Fujitsu"),
        0x09: (None, "Matsushita"),
        0x0A: (None, "NEC"),
        0x0B: (None, "Oki"),
        0x0C: (None, "Toshiba"),
        0x0D: (None, "Mitsubishi"),
        0x0E: (None, "Samsung"),
        0x0F: (None, "Hyundai"),
        0x10: (None, "LG"),
        0x12: (None, "WISeKey"),
        0x16: (None, "EM Microelectronic"),
        0x1F: (None, "Melexis"),
        0x2B: (None, "Maxim"),
        0x33: (None, "AMIC"),
        0x44: (None, "GenTag"),
        0x45: (None, "Invengo"),
    }

    # 厂商系列（型号兜底名称）
    VENDOR_FAMILY = {
        "NXP": "NXP ICODE 系列",
        "TI": "TI Tag-it HF-I 系列",
    }

    # 具体型号：(厂商key, TAG/IC 类型字节) -> 型号
    # TAG 类型位于 UID bit41-48，即显示序第 3 字节、传输序 index 5
    MODEL_HINTS = {
        ("NXP", 0x01): "NXP ICODE SLI/SLI-X/SLI-X2 系列",
        ("NXP", 0x02): "NXP ICODE SLI-S (SL2ICS53)",
        ("NXP", 0x03): "NXP ICODE SLIX-L (SL2S5002)",
    }

    # NXP ICODE 变体：TAG 类型码 0x01 为 ICODE SLI / SLI-X / SLI-X2 共用，
    # 由 UID 序列号区 bit37/bit36 区分（即显示序第 4 字节的 0x10 / 0x08 位）。
    # 依据：NXP SL2S2602(ICODE SLIX2) 数据手册 Rev.4.1 的 UID 结构说明
    NXP_ICODE_VARIANTS = {
        (False, False): "NXP ICODE SLI",
        (True, False): "NXP ICODE SLI-X",
        (False, True): "NXP ICODE SLI-X2 (SL2S2602)",
    }

    # 型号备注：类型码在多个型号间共用时提示区分方法
    MODEL_NOTES = {
        ("NXP", 0x01): "TAG 类型码 0x01 为 NXP ICODE SLI / SLI-X / SLI-X2 共用，"
                       "由 UID 序列号区 bit37/bit36 细分（见下方 ICODE 变体判定）",
    }

    # NXP 私有命令请求中固定携带的 IC 制造商代码（ISO/IEC 7816-6: 04h = NXP），
    # 位于命令码之后、UID 之前（如 GET NXP SYSTEM INFORMATION 0xAB）
    NXP_IC_MFG_CODE = 0x04

    # CRC16 参数（与项目根目录 ISO15_crc.h 的 crc16_V / HasValidCrcV 一致）
    CRC_POLYNOMIAL = 0x8408    # ISO/IEC 13239: x^16 + x^12 + x^5 + 1
    CRC_PRESET_VALUE = 0xFFFF
    CRC_CHECK_VALUE = 0x0F47   # HasValidCrcV 的判定值

    # 会话状态：当前识别到的卡片，以及最近一次请求命令（用于推断响应类型，
    # 因为响应帧中不含命令码）
    _card_uid = None
    _card_vendor = None
    _card_model = None
    _last_req_cmd = None

    # ------------------------------------------------------------------ #
    # 会话/卡片识别
    # ------------------------------------------------------------------ #
    @staticmethod
    def reset_session():
        """清除当前识别的卡片信息（可在打开新抓包文件时调用）"""
        ISO15693Parser._card_uid = None
        ISO15693Parser._card_vendor = None
        ISO15693Parser._card_model = None
        ISO15693Parser._last_req_cmd = None

    @staticmethod
    def _lookup_model(vendor, tag_type):
        if vendor is None:
            return None
        hint = ISO15693Parser.MODEL_HINTS.get((vendor, tag_type))
        return hint if hint else ISO15693Parser.VENDOR_FAMILY.get(vendor)

    @staticmethod
    def current_card():
        """返回当前识别到的卡片信息 (uid, vendor, model)"""
        return (ISO15693Parser._card_uid,
                ISO15693Parser._card_vendor,
                ISO15693Parser._card_model)

    # ------------------------------------------------------------------ #
    # 基础解析
    # ------------------------------------------------------------------ #
    @staticmethod
    def parse_timestamp(timestamp_raw):
        ts_value = timestamp_raw & 0x00FFFFFF
        if ts_value == 0:
            return f"0x{ts_value:06X}", ts_value, True
        elif ts_value == 0x00FFFFFF:
            return f"0x{ts_value:06X}", ts_value, False
        else:
            return f"0x{ts_value:06X}", ts_value, False

    @staticmethod
    def calculate_time_diff(prev_ts, curr_ts):
        if curr_ts <= prev_ts:
            diff = prev_ts - curr_ts
            overflow = False
        else:
            diff = (prev_ts + 0x01000000) - curr_ts
            overflow = True
        return diff, overflow

    @staticmethod
    def parse_valid_bits_info(direction_byte, valid_bits, extra_info):
        """解析最后一个字节的有效位信息"""
        if direction_byte == ord('<'):
            if valid_bits == 0:
                desc = "8 bits (完整字节)"
            else:
                desc = f"{valid_bits} bits (部分字节)"
            extra_info.append(f"  - 有效位: {valid_bits} ({desc})")
        elif direction_byte == ord('>'):
            if valid_bits == 0:
                desc = "8 bits + 校验位"
            else:
                desc = f"{valid_bits} bits (无校验位)"
            extra_info.append(f"  - 有效位: {valid_bits} ({desc})")
        else:
            extra_info.append(f"  - 有效位: {valid_bits}")

    # ------------------------------------------------------------------ #
    # CRC16（对应项目根目录 ISO15_crc.h 的 crc16_V / HasValidCrcV）
    # ------------------------------------------------------------------ #
    @staticmethod
    def crc16_v(data):
        """正向计算 CRC16（对应 ISO15_crc.h 的 crc16_V）：
        初值 0xFFFF，反射多项式 0x8408，逐字节 LSB 优先移位，结果按位取反。"""
        crc = ISO15693Parser.CRC_PRESET_VALUE
        for byte in data:
            crc ^= byte
            for _ in range(8):
                if crc & 0x0001:
                    crc = (crc >> 1) ^ ISO15693Parser.CRC_POLYNOMIAL
                else:
                    crc >>= 1
        return (~crc) & 0xFFFF

    @staticmethod
    def has_valid_crc(data):
        """校验含 CRC 的整帧是否正确（对应 ISO15_crc.h 的 HasValidCrcV）：
        整帧（含末尾 2 字节 CRC）计算结果等于 CRC_CHECK_VALUE 即通过。"""
        return ISO15693Parser.crc16_v(data) == ISO15693Parser.CRC_CHECK_VALUE

    @staticmethod
    def parse_crc(payload, extra_info):
        """解析并校验帧尾 16 位 CRC。
        15693 帧以 2 字节 CRC 结束，传输时低字节在前；CRC 覆盖整帧（FLAG 起至 CRC 末字节）。
        注：抓包若缺失末尾字节，此处会判定为校验失败。"""
        if len(payload) < 2:
            extra_info.append("  - CRC16: 帧长不足 2 字节，无 CRC 字段")
            return
        crc_bytes = payload[-2:]
        field_val = crc_bytes[0] | (crc_bytes[1] << 8)   # 传输时低字节在前
        computed = ISO15693Parser.crc16_v(payload)
        ok = computed == ISO15693Parser.CRC_CHECK_VALUE
        extra_info.append(f"  - CRC16: 字段 {crc_bytes.hex(' ').upper()} "
                          f"(低字节在前 → 0x{field_val:04X})")
        extra_info.append(f"    - 校验: {'通过' if ok else '失败'} "
                          f"(整帧 crc16_V = 0x{computed:04X}, "
                          f"期望 0x{ISO15693Parser.CRC_CHECK_VALUE:04X})")
        if not ok:
            extra_info.append("    - 提示: 校验失败可能因抓包缺失末尾字节或帧数据被修改")

    @staticmethod
    def parse_flags(flags, extra_info):
        """
        按 ISO/IEC 15693-3 逐位解析请求标志位（bit1~bit8，LSB 为 bit1）。
        bit5~bit8 有两种定义方式，取决于 bit3 的 Inventory 标志：
          - bit3=0（非寻卡模式）: Select / Address / Option / RFU
          - bit3=1（寻卡模式）  : AFI / Number of slots / Option / RFU
        """
        extra_info.append(f"  - Flags: 0x{flags:02X} (二进制 {flags:08b})")

        inventory = bool(flags & ISO15693Parser.FLAG_INVENTORY)
        extra_info.append(f"    - bit3 决定 bit5~bit8 的定义方式: "
                          f"{'寻卡模式 (Inventory=1)' if inventory else '非寻卡模式 (Inventory=0)'}")

        extra_info.append(f"    - bit1 (0x01): "
                          f"{'1 = 应答使用两个子载波 (FSK)' if flags & 0x01 else '0 = 应答使用单个子载波 (ASK)'}")
        extra_info.append(f"    - bit2 (0x02): "
                          f"{'1 = 高速数据速率' if flags & 0x02 else '0 = 低速数据速率'}")
        extra_info.append(f"    - bit3 (0x04): "
                          f"{'1 = 寻卡(Inventory)请求' if inventory else '0 = 非寻卡请求'}")
        extra_info.append(f"    - bit4 (0x08): "
                          f"{'1 = 支持协议扩展 (Protocol Extension, RFU)' if flags & 0x08 else '0 = 无协议扩展 (RFU)'}")

        if inventory:
            extra_info.append(f"    - bit5 (0x10) [寻卡模式]: "
                              f"{'1 = AFI 字段存在' if flags & 0x10 else '0 = 无 AFI 字段'}")
            extra_info.append(f"    - bit6 (0x20) [寻卡模式]: "
                              f"{'1 = 1 个时隙 (1 slot)' if flags & 0x20 else '0 = 16 个时隙 (16 slots)'}")
            extra_info.append(f"    - bit7 (0x40) [寻卡模式]: "
                              f"{'1 = Option 置位 (命令相关选项)' if flags & 0x40 else '0 = Option 清零'}")
            extra_info.append(f"    - bit8 (0x80) [寻卡模式]: "
                              f"{'1 = RFU (保留，应为0)' if flags & 0x80 else '0 = RFU (保留)'}")
        else:
            extra_info.append(f"    - bit5 (0x10) [非寻卡模式]: "
                              f"{'1 = Select (仅处于 Selected 状态的卡片应答)' if flags & 0x10 else '0 = 非 Select'}")
            extra_info.append(f"    - bit6 (0x20) [非寻卡模式]: "
                              f"{'1 = Address (请求中含 8 字节 UID 寻址)' if flags & 0x20 else '0 = 不含地址(UID)'}")
            extra_info.append(f"    - bit7 (0x40) [非寻卡模式]: "
                              f"{'1 = Option 置位 (命令相关选项)' if flags & 0x40 else '0 = Option 清零'}")
            extra_info.append(f"    - bit8 (0x80) [非寻卡模式]: "
                              f"{'1 = RFU (保留，应为0)' if flags & 0x80 else '0 = RFU (保留)'}")

        # 标志位决定的“命令码之后”的参数/数据
        extra_info.append("    - 标志位决定的后续参数:")
        if inventory:
            if flags & 0x10:
                extra_info.append("        * bit5=1 → 命令码后为 AFI(1 字节)，用于限定应答卡的 AFI 值")
            extra_info.append("        * 命令码后为 Mask 长度(1 字节) + Mask 值(⌈Mask长度/8⌉ 字节)")
            extra_info.append("        * bit6=0 时阅读器需对 16 个时隙做防冲突处理(多卡场景)")
        else:
            if flags & 0x20:
                extra_info.append("        * bit6=1 → 请求中含 8 字节 UID（传输时 0xE0 为最后一个字节）；"
                                  "个别命令在 UID 之前另有参数字节，UID 之后的字节才是命令参数")
            if flags & 0x10:
                extra_info.append("        * bit5=1 → 仅 Selected 状态的卡片应答，本身不增加参数字节")
            if flags & 0x40:
                extra_info.append("        * bit7=1 → 末尾附加该命令定义的 Option 参数(命令相关)")

    @staticmethod
    def parse_error_code(error_code, extra_info):
        """解析错误码（与 ISO15_cmd.h 的 RESPONSE ERROR CODES 一致）"""
        errors = {
            0x00: "NOERROR 无错误",
            0x01: "CMD_NOT_SUP 命令不支持",
            0x02: "CMD_NOT_REC 命令无法识别(参数错误)",
            0x03: "CMD_OPTION 命令选项不支持",
            0x0F: "GENERIC 未知错误",
            0x10: "BLOCK_UNAVAILABLE 块不可用",
            0x11: "BLOCK_LOCKED_ALREADY 块已锁定，无法再次锁定",
            0x12: "BLOCK_LOCKED 块已锁定，无法修改",
            0x13: "BLOCK_WRITE 写入失败",
            0x14: "BLOCK_WRITELOCK 锁定失败",
        }
        extra_info.append(f"    - 错误码: 0x{error_code:02X} ({errors.get(error_code, '未知错误')})")

    @staticmethod
    def parse_uid(uid_bytes, extra_info):
        """
        解析 UID(8字节)，识别卡片厂商与型号，并记录为会话状态。
        UID 在线路上以 LSB 优先传输，故先逆序还原为显示序（MSB 优先）再按标准结构解读：
          显示序 byte1 = 0xE0（固定）
          显示序 byte2 = IC 制造商代码 (ISO/IEC 7816-6，如 04h = NXP)
          显示序 byte3 = TAG/IC 类型 (UID bit41-48)
          显示序 byte4~8 = 厂商定义（序列号等）
        """
        if len(uid_bytes) < 8:
            return None
        uid = uid_bytes[:8]                 # 传输序 LSB→MSB
        display = bytes(reversed(uid))      # 显示序 MSB→LSB

        extra_info.append(f"    - UID (显示序): {display.hex(' ').upper()}")
        extra_info.append(f"    - UID (传输序): {uid.hex(' ').upper()}")

        if display[0] != 0xE0:
            extra_info.append(f"    - 注意: UID 首字节按标准应为 0xE0，实际为 0x{display[0]:02X}")

        mfr_code = display[1]
        tag_type = display[2]

        vendor, vendor_name = ISO15693Parser.MANUFACTURERS.get(
            mfr_code, (None, f"未知厂商 (0x{mfr_code:02X})"))
        extra_info.append(f"    - IC 制造商代码: 0x{mfr_code:02X} → {vendor_name}")
        extra_info.append(f"    - TAG/IC 类型: 0x{tag_type:02X}")

        model = ISO15693Parser._lookup_model(vendor, tag_type)
        note = ISO15693Parser.MODEL_NOTES.get((vendor, tag_type))

        # NXP ICODE SLI/SLI-X/SLI-X2 共用 TAG 类型码 0x01，
        # 具体变体由 UID 序列号区 bit37/bit36 区分（显示序第 4 字节的 0x10/0x08 位）
        if vendor == "NXP" and tag_type == 0x01:
            byte4 = display[3]
            bit37 = bool(byte4 & 0x10)
            bit36 = bool(byte4 & 0x08)
            variant = ISO15693Parser.NXP_ICODE_VARIANTS.get((bit37, bit36))
            extra_info.append(
                f"    - ICODE 变体判定: 序列号区 bit37={int(bit37)}, bit36={int(bit36)}"
                f" (显示序第4字节 0x{byte4:02X}) → {variant if variant else '未定义组合'}")
            if variant:
                model = variant

        # 记录会话状态，供后续私有命令按厂商解析
        ISO15693Parser._card_uid = display
        ISO15693Parser._card_vendor = vendor
        ISO15693Parser._card_model = model

        if vendor:
            extra_info.append(f"    - 识别厂商: {vendor} ({vendor_name})")
        if model:
            extra_info.append(f"    - 卡片型号: {model}")
        if note:
            extra_info.append(f"    - 型号备注: {note}")
        return vendor

    # ------------------------------------------------------------------ #
    # 响应解析
    # ------------------------------------------------------------------ #
    @staticmethod
    def parse_inventory_response(body, extra_info):
        """
        解析 Inventory 响应体（已去掉响应标志字节）：UID 末尾字节在线路上固定为 0xE0
        （LSB 优先传输），据此定位 UID；其前为 DSFID，其余为 CRC16（由 parse_crc 报告）。
        """
        data = ISO15693Parser._strip_rsp_crc(body)
        hit = ISO15693Parser.find_uid_window(data)
        if not hit:
            extra_info.append("    - 未找到以 0xE0 结尾的 8 字节 UID")
            if data:
                extra_info.append(f"    - 数据: {data.hex(' ').upper()}")
            return

        before, uid, after = hit
        if before:
            extra_info.append(f"    - DSFID: 0x{before[0]:02X}")
            if len(before) > 1:
                extra_info.append(f"    - UID 之前的其它字节: {before[1:].hex(' ').upper()}")

        ISO15693Parser.parse_uid(uid, extra_info)

        if after:
            extra_info.append(f"    - UID 之后的其它字节: {after.hex(' ').upper()}")

    # ---- 成功响应结构表：命令码 -> (结构类型, 预期结构说明) ----
    # 响应帧不含命令码，必须依据“最近一次请求命令”来确定本响应对应哪个命令及其结构
    RESPONSE_TABLE = {
        # 标准 ISO15693 命令
        CMD_INVENTORY: ("inventory", "[FLAG][DSFID][UID(8)][CRC16]"),
        CMD_STAY_QUIET: ("silent", "卡片进入 Quiet 状态，不应答（无响应帧）"),
        CMD_READ_SINGLE_BLOCK: ("block_data", "[FLAG][块数据][CRC16]"),
        CMD_WRITE_SINGLE_BLOCK: ("no_data", "[FLAG][CRC16]"),
        CMD_LOCK_BLOCK: ("no_data", "[FLAG][CRC16]"),
        CMD_READ_MULTIPLE_BLOCKS: ("block_data", "[FLAG][多块数据][CRC16]"),
        CMD_WRITE_MULTIPLE_BLOCKS: ("no_data", "[FLAG][CRC16]"),
        CMD_SELECT: ("no_data", "[FLAG][CRC16]"),
        CMD_RESET_TO_READY: ("no_data", "[FLAG][CRC16]"),
        CMD_WRITE_AFI: ("no_data", "[FLAG][CRC16]"),
        CMD_LOCK_AFI: ("no_data", "[FLAG][CRC16]"),
        CMD_WRITE_DSFID: ("no_data", "[FLAG][CRC16]"),
        CMD_LOCK_DSFID: ("no_data", "[FLAG][CRC16]"),
        CMD_GET_SYSTEM_INFO: ("sysinfo",
                              "[FLAG][Info flags][UID(8)][按 Info flags 存在的字段][CRC16]"),
        CMD_GET_MULTIPLE_BLOCK_SECURITY: ("sec_status",
                                          "[FLAG][各块安全状态位图(每块 1 位)][CRC16]"),
        # NXP 私有命令
        0xA0: ("inv_read", "[FLAG][DSFID][UID(8)][块数据][CRC16]"),
        0xA1: ("inv_read", "[FLAG][DSFID][UID(8)][块数据][CRC16]"),
        0xA2: ("no_data", "[FLAG][CRC16]"),
        0xA3: ("no_data", "[FLAG][CRC16]"),
        0xA4: ("no_data", "[FLAG][CRC16]"),
        0xA5: ("silent", "EAS ALARM：卡片以 EAS 信号应答（EOF 信号），无数据帧"),
        0xA6: ("no_data", "[FLAG][CRC16]"),
        0xA7: ("no_data", "[FLAG][CRC16]"),
        0xA8: ("epc", "[FLAG][EPC 数据][CRC16]"),
        0xAB: ("nxp_sysinfo",
               "[FLAG][PP pointer][PP conditions][Lock bits][Feature flags(32)][CRC16]"),
        0xB0: ("inv_read", "[FLAG][DSFID][UID(8)][页数据][CRC16]"),
        0xB1: ("inv_read", "[FLAG][DSFID][UID(8)][页数据][CRC16]"),
        0xB2: ("random", "[FLAG][随机数(2 字节)][CRC16]"),
        0xB3: ("no_data", "[FLAG][CRC16]"),
        0xB4: ("no_data", "[FLAG][CRC16]"),
        0xB5: ("no_data", "[FLAG][CRC16]"),
        0xB6: ("no_data", "[FLAG][CRC16]"),
        0xB7: ("no_data", "[FLAG][CRC16]"),
        0xB8: ("protection", "[FLAG][各块 1 字节保护状态][CRC16]"),
        0xB9: ("no_data", "[FLAG][CRC16]"),
        0xBA: ("no_data", "[FLAG][CRC16]"),
        0xBB: ("no_data", "[FLAG][CRC16]"),
        0xBC: ("silent", "卡片进入持久静默，不应答（无响应帧）"),
        0xBD: ("signature", "[FLAG][签名(32 字节)][CRC16]"),
    }

    # 标准 GET SYSTEM INFORMATION 响应的 Info flags 位定义
    SYSINFO_INFO_FLAGS_BITS = {
        1: "DSFID 字段存在",
        2: "AFI 字段存在",
        3: "存储容量字段存在",
        4: "IC 参考字段存在",
        5: "块数量(2 字节)+块大小(1 字节)字段存在",
    }

    # NXP 0xAB (GET NXP SYSTEM INFORMATION) 响应的字段位定义（见 NXP SL2S2602 手册 Table 72~74）
    NXP_PP_CONDITIONS_BITS = {
        1: "RL：Page L 读密码保护",
        2: "WL：Page L 写密码保护",
        5: "RH：Page H 读密码保护",
        6: "WH：Page H 写密码保护",
    }
    NXP_LOCK_BITS = {
        1: "AFI 锁定",
        2: "EAS 锁定",
        3: "DSFID 锁定",
        4: "PP：密码保护指针地址与访问条件锁定",
    }
    NXP_FEATURE_FLAGS_BITS = {
        1: "UM PP：用户存储区密码保护",
        2: "COUNTER：计数器功能",
        3: "EAS ID：EAS ALARM 携带 EAS ID",
        4: "EAS PP：EAS 密码保护",
        5: "AFI PP：AFI 密码保护",
        6: "INVENTORY READ EXT：INVENTORY READ 扩展模式",
        7: "EAS IR：扩展模式下可做 EAS 选择",
        9: "ORIGINALITY SIG：READ SIGNATURE 命令",
        10: "ORIGINALITY SIG PP：READ SIGNATURE 密码保护",
        11: "P QUIET：STAY QUIET PERSISTENT",
        13: "PRIVACY：ENABLE PRIVACY",
        14: "DESTROY：DESTROY 命令",
        32: "EXT：附加 32 位特性标志随帧传输",
    }

    @staticmethod
    def parse_rsp_flags(rsp_flags, extra_info):
        """响应标志逐位解析（见 ISO15_cmd.h 的 RESPONSE FLAGS）"""
        extra_info.append(
            f"    - bit1 (0x01) ERROR: "
            f"{'1 = 错误响应，随后 1 字节为错误码' if rsp_flags & ISO15693Parser.RSP_FLAG_ERROR else '0 = 无错误'}")
        extra_info.append("    - bit2~bit3: RFU (保留，应为 0)")
        extra_info.append(
            f"    - bit4 (0x08) Protocol Extension: "
            f"{'1 = 使用协议扩展' if rsp_flags & ISO15693Parser.RSP_FLAG_EXT else '0 = 无协议扩展'}")
        extra_info.append("    - bit5~bit8: RFU (保留，应为 0)")

    @staticmethod
    def lookup_cmd_name(cmd):
        """查命令名：标准命令表优先，私有命令按当前卡片厂商优先"""
        if cmd in ISO15693Parser.STANDARD_COMMANDS:
            return ISO15693Parser.STANDARD_COMMANDS[cmd], "ISO15693"
        vendor = ISO15693Parser._card_vendor
        tables = CustomCommandsParser.VENDOR_TABLES
        if vendor in tables and cmd in tables[vendor]:
            return tables[vendor][cmd], vendor
        for name_of_vendor, table in tables.items():
            if cmd in table:
                return f"{table[cmd]} (按 {name_of_vendor})", name_of_vendor
        return f"未知命令 (0x{cmd:02X})", None

    @staticmethod
    def _strip_rsp_crc(body):
        """去掉响应体末尾 2 字节 CRC16（CRC 字段的显示与校验由帧级 parse_crc 统一负责）"""
        return body[:-2] if len(body) >= 2 else body

    @staticmethod
    def _format_bits(data, bit_defs, extra_info, indent="      ", only_set=False):
        """按位列出定义：bit 编号从 1 起，首字节为最低 8 位（LSB 优先）"""
        for bit in sorted(bit_defs):
            byte_idx, bit_idx = (bit - 1) // 8, (bit - 1) % 8
            if byte_idx >= len(data):
                continue
            val = (data[byte_idx] >> bit_idx) & 1
            if only_set and not val:
                continue
            extra_info.append(f"{indent}bit{bit} = {val} → {bit_defs[bit]}")

    @staticmethod
    def parse_rsp_no_data(body, extra_info):
        """[FLAG][CRC16]：命令执行成功，无数据返回"""
        data = ISO15693Parser._strip_rsp_crc(body)
        if data:
            extra_info.append(f"    - 意外数据: {data.hex(' ').upper()}")
        else:
            extra_info.append("    - 命令执行成功，无数据返回")

    @staticmethod
    def parse_rsp_block_data(body, extra_info):
        """[FLAG][块数据][CRC16]"""
        data = ISO15693Parser._strip_rsp_crc(body)
        if data:
            extra_info.append(f"    - 块数据({len(data)} 字节): {data.hex(' ').upper()}")
        else:
            extra_info.append("    - 无块数据返回")

    @staticmethod
    def parse_rsp_epc(body, extra_info):
        """[FLAG][EPC 数据][CRC16]"""
        data = ISO15693Parser._strip_rsp_crc(body)
        if data:
            extra_info.append(f"    - EPC 数据({len(data)} 字节): {data.hex(' ').upper()}")
        else:
            extra_info.append("    - 无 EPC 数据返回")

    @staticmethod
    def parse_rsp_sec_status(body, extra_info):
        """[FLAG][各块安全状态位图(每块 1 位, 位=1 表示已锁定)][CRC16]"""
        data = ISO15693Parser._strip_rsp_crc(body)
        if not data:
            extra_info.append("    - 无安全状态数据")
            return
        extra_info.append(f"    - 安全状态位图: {data.hex(' ').upper()}")
        locked = []
        for byte_idx, byte in enumerate(data):
            for bit_idx in range(8):
                if byte & (1 << bit_idx):
                    locked.append(byte_idx * 8 + bit_idx + 1)
        extra_info.append(f"    - 已锁定(位=1)的块号(从 1 起): "
                          f"{', '.join(map(str, locked)) if locked else '无'}")

    @staticmethod
    def parse_rsp_protection(body, extra_info):
        """NXP GET MULTI BLOCK PROTECTION: [FLAG][各块 1 字节保护状态][CRC16]"""
        data = ISO15693Parser._strip_rsp_crc(body)
        if not data:
            extra_info.append("    - 无保护状态数据")
            return
        for idx, byte in enumerate(data):
            extra_info.append(f"    - 块 {idx}: 保护状态 0x{byte:02X} "
                              f"(bit1 写保护={'是' if byte & 0x01 else '否'})")

    @staticmethod
    def parse_rsp_inventory_read(body, extra_info):
        """NXP INVENTORY (PAGE) READ 响应：UID + 读到的数据"""
        data = ISO15693Parser._strip_rsp_crc(body)
        hit = ISO15693Parser.find_uid_window(data)
        if not hit:
            extra_info.append(f"    - 未找到 UID，数据: {data.hex(' ').upper()}")
            return
        before, uid, after = hit
        if before:
            extra_info.append(f"    - DSFID: 0x{before[0]:02X}")
            if len(before) > 1:
                extra_info.append(f"    - UID 之前的其它字节: {before[1:].hex(' ').upper()}")
        ISO15693Parser.parse_uid(uid, extra_info)
        if after:
            extra_info.append(f"    - 读到的数据({len(after)} 字节): {after.hex(' ').upper()}")

    @staticmethod
    def parse_rsp_random(body, extra_info):
        """NXP GET RANDOM NUMBER: [FLAG][随机数(2 字节)][CRC16]"""
        data = ISO15693Parser._strip_rsp_crc(body)
        if len(data) >= 2:
            extra_info.append(f"    - 随机数: 0x{struct.unpack('>H', data[:2])[0]:04X}")
            if len(data) > 2:
                extra_info.append(f"    - 其余字节: {data[2:].hex(' ').upper()}")
        elif data:
            extra_info.append(f"    - 数据不足 2 字节: {data.hex(' ').upper()}")
        else:
            extra_info.append("    - 无随机数返回")

    @staticmethod
    def parse_rsp_signature(body, extra_info):
        """NXP READ SIGNATURE: [FLAG][签名(32 字节)][CRC16]"""
        data = ISO15693Parser._strip_rsp_crc(body)
        if data:
            extra_info.append(f"    - 签名数据({len(data)} 字节): {data.hex(' ').upper()}")
        else:
            extra_info.append("    - 无签名数据返回")

    @staticmethod
    def parse_rsp_system_info(body, extra_info):
        """标准 0x2B GET SYSTEM INFORMATION 响应体：
        [Info flags(1)][UID(8)][按 Info flags 存在的 DSFID/AFI/存储容量/IC参考/块信息][CRC16]"""
        data = ISO15693Parser._strip_rsp_crc(body)
        if not data:
            extra_info.append("    - 无数据")
            return

        info_flags = data[0]
        extra_info.append(f"    - Info flags: 0x{info_flags:02X}")
        ISO15693Parser._format_bits(data[0:1], ISO15693Parser.SYSINFO_INFO_FLAGS_BITS, extra_info)

        rest = data[1:]
        hit = ISO15693Parser.find_uid_window(rest)
        if not hit:
            extra_info.append(f"    - 未找到 UID，剩余数据: {rest.hex(' ').upper()}")
            return

        before, uid, after = hit
        if before:
            extra_info.append(f"    - Info flags 之后的其它字节: {before.hex(' ').upper()}")
        ISO15693Parser.parse_uid(uid, extra_info)

        idx = 0
        if info_flags & 0x01 and idx < len(after):
            extra_info.append(f"    - DSFID: 0x{after[idx]:02X}")
            idx += 1
        if info_flags & 0x02 and idx < len(after):
            extra_info.append(f"    - AFI: 0x{after[idx]:02X}")
            idx += 1
        if info_flags & 0x04 and idx < len(after):
            extra_info.append(f"    - 存储容量字段: 0x{after[idx]:02X}")
            idx += 1
        if info_flags & 0x08 and idx < len(after):
            extra_info.append(f"    - IC 参考: 0x{after[idx]:02X}")
            idx += 1
        if info_flags & 0x10 and idx + 1 < len(after):
            num_blocks = struct.unpack('>H', after[idx:idx + 2])[0]
            idx += 2
            extra_info.append(f"    - 块数量: {num_blocks}")
            if idx < len(after):
                extra_info.append(f"    - 块大小: {after[idx]} 字节")
                idx += 1
        if idx < len(after):
            extra_info.append(f"    - 未解析的剩余字节: {after[idx:].hex(' ').upper()}")

    @staticmethod
    def parse_rsp_nxp_system_info(body, extra_info):
        """NXP 0xAB GET NXP SYSTEM INFORMATION 响应体：
        [PP pointer(1)][PP conditions(1)][Lock bits(1)][Feature flags(32, LSB 优先)][CRC16]"""
        data = ISO15693Parser._strip_rsp_crc(body)
        if len(data) < 7:
            extra_info.append(f"    - 字段不足(期望 7 字节, 实际 {len(data)} 字节): "
                              f"{data.hex(' ').upper()}")
            return

        extra_info.append(f"    - PP pointer(密码保护指针地址): 0x{data[0]:02X}")
        extra_info.append(f"    - PP conditions: 0x{data[1]:02X}")
        ISO15693Parser._format_bits(data[1:2], ISO15693Parser.NXP_PP_CONDITIONS_BITS, extra_info)
        extra_info.append(f"    - Lock bits: 0x{data[2]:02X}")
        ISO15693Parser._format_bits(data[2:3], ISO15693Parser.NXP_LOCK_BITS, extra_info)
        extra_info.append(f"    - Feature flags: {data[3:7].hex(' ').upper()} "
                          f"(32 位, LSB 优先，以下列出置位项)")
        ISO15693Parser._format_bits(data[3:7], ISO15693Parser.NXP_FEATURE_FLAGS_BITS,
                                    extra_info, only_set=True)

    @staticmethod
    def parse_15693_response(direction_byte, payload, data_len, result):
        """解析15693响应帧: [响应FLAG(1)][数据/错误码...]（帧内不含命令码）。
        响应对应哪个命令、采用哪种结构，依据最近一次请求命令(_last_req_cmd)查响应结构表确定。"""
        extra_info = result["extra_info"]
        if direction_byte != ord('<') or data_len == 0:
            return

        rsp_flags = payload[0]
        extra_info.append(f"  - 响应标志: 0x{rsp_flags:02X} (二进制 {rsp_flags:08b})")
        ISO15693Parser.parse_rsp_flags(rsp_flags, extra_info)

        body = payload[1:]
        cmd = ISO15693Parser._last_req_cmd
        if cmd is None:
            extra_info.append("  - 未找到对应的请求帧记录，无法确定本响应对应哪个命令")
        else:
            name, _vendor = ISO15693Parser.lookup_cmd_name(cmd)
            extra_info.append(f"  - 对应请求命令: 0x{cmd:02X} ({name})")

        # 错误响应（所有命令通用）: [FLAG][错误码][CRC16]
        if rsp_flags & ISO15693Parser.RSP_FLAG_ERROR:
            if body:
                ISO15693Parser.parse_error_code(body[0], extra_info)
            else:
                extra_info.append("    - 错误响应但缺少错误码字段")
            return

        kind, desc = ISO15693Parser.RESPONSE_TABLE.get(cmd, (None, None))

        if kind is None:
            if cmd is not None:
                extra_info.append(f"    - 命令 0x{cmd:02X} 的响应结构未在表内定义")
            # 无请求记录或未定义结构：仅在能从 UID 特征确认时才按 Inventory 解析
            if ISO15693Parser.find_uid_window(body):
                extra_info.append("  - 依据 UID(末尾 0xE0) 特征按 Inventory 响应解析")
                ISO15693Parser.parse_inventory_response(body, extra_info)
            elif body:
                extra_info.append(f"    - 原始数据: {body.hex(' ').upper()}")
            return

        extra_info.append(f"  - 预期响应结构: {desc}")
        if kind == "silent":
            return

        parsers = {
            "inventory": ISO15693Parser.parse_inventory_response,
            "inv_read": ISO15693Parser.parse_rsp_inventory_read,
            "no_data": ISO15693Parser.parse_rsp_no_data,
            "block_data": ISO15693Parser.parse_rsp_block_data,
            "epc": ISO15693Parser.parse_rsp_epc,
            "sec_status": ISO15693Parser.parse_rsp_sec_status,
            "protection": ISO15693Parser.parse_rsp_protection,
            "sysinfo": ISO15693Parser.parse_rsp_system_info,
            "nxp_sysinfo": ISO15693Parser.parse_rsp_nxp_system_info,
            "random": ISO15693Parser.parse_rsp_random,
            "signature": ISO15693Parser.parse_rsp_signature,
        }
        parsers[kind](body, extra_info)

    # ------------------------------------------------------------------ #
    # 请求解析
    # ------------------------------------------------------------------ #
    @staticmethod
    def find_uid_window(data, start=0):
        """
        在字节流中定位 UID：UID 以 LSB 优先传输，其最后一个字节固定为 0xE0，
        故 UID 即“末尾为 0xE0 的 8 字节窗口”。返回 (窗口前字节, uid8, 窗口后字节)，
        未找到返回 None。请求/响应两个方向均按此规则定位，不假定 UID 一定紧跟命令码。
        """
        for i in range(start, len(data) - 7):
            if data[i + 7] == 0xE0:
                return data[:i], data[i:i + 8], data[i + 8:]
        return None

    @staticmethod
    def _split_uid(cmd, vendor, flags, params, extra_info):
        """地址标志置位时，解析命令码之后的 UID 并返回其后的参数。
        部分私有命令在 UID 之前还带参数字节（如 GET NXP SYSTEM INFO 0xAB 的 IC Mfg code），
        因此按“末尾为 0xE0”的规则定位 UID，窗口之前的字节按命令语义列出。"""
        if not (flags & ISO15693Parser.FLAG_ADDRESS):
            return params

        hit = ISO15693Parser.find_uid_window(params)
        if not hit:
            extra_info.append("    - Address 标志已置位，但未找到以 0xE0 结尾的 8 字节 UID")
            return params

        before, uid, after = hit
        if before:
            ISO15693Parser._describe_pre_uid_bytes(cmd, vendor, before, extra_info)
        ISO15693Parser.parse_uid(uid, extra_info)
        return after

    @staticmethod
    def _describe_pre_uid_bytes(cmd, vendor, before, extra_info):
        """解释 UID 之前的字节。NXP 私有命令在命令码之后固定携带 1 字节 IC Mfg code
        (04h = NXP Semiconductors)，再往后才是 UID（见 NXP SL2S2602 手册 Table 69）。"""
        if (cmd is not None and vendor in (None, "NXP") and 0xA0 <= cmd <= 0xBF
                and before and before[0] == ISO15693Parser.NXP_IC_MFG_CODE):
            extra_info.append("    - IC Mfg code: 0x04 → NXP Semiconductors "
                              "(NXP 私有命令在命令码之后携带的 IC 制造商代码，UID 位于其后)")
            if len(before) > 1:
                extra_info.append(f"    - UID 之前的其它参数: {before[1:].hex(' ').upper()}")
            return
        extra_info.append(f"    - UID 之前的命令参数: {before.hex(' ').upper()}")

    @staticmethod
    def _parse_standard_params(cmd, flags, params, extra_info):
        """解析标准命令“命令码之后”的参数/数据（params 已去除UID）"""
        if cmd == ISO15693Parser.CMD_INVENTORY:
            # Inventory 请求: [AFI(若Inventory AFI标志)][Mask长度(1)][Mask]
            idx = 0
            if (flags & ISO15693Parser.FLAG_INV_AFI) and len(params) > idx:
                extra_info.append(f"    - AFI: 0x{params[idx]:02X}")
                idx += 1
            if len(params) > idx:
                mask_bits = params[idx]
                extra_info.append(f"    - Mask长度: {mask_bits} bits")
                idx += 1
                nbytes = (mask_bits + 7) // 8
                if nbytes and len(params) >= idx + nbytes:
                    extra_info.append(f"    - Mask: {params[idx:idx+nbytes].hex().upper()}")
            return

        if cmd == ISO15693Parser.CMD_STAY_QUIET:
            return

        if cmd in (ISO15693Parser.CMD_READ_SINGLE_BLOCK,
                   ISO15693Parser.CMD_WRITE_SINGLE_BLOCK,
                   ISO15693Parser.CMD_LOCK_BLOCK):
            if params:
                extra_info.append(f"    - 块号: {params[0]}")
            if cmd == ISO15693Parser.CMD_WRITE_SINGLE_BLOCK and len(params) > 1:
                extra_info.append(f"    - 写入数据: {params[1:].hex().upper()}")
            return

        if cmd in (ISO15693Parser.CMD_READ_MULTIPLE_BLOCKS,
                   ISO15693Parser.CMD_WRITE_MULTIPLE_BLOCKS):
            if params:
                extra_info.append(f"    - 起始块: {params[0]}")
            if len(params) > 1:
                extra_info.append(f"    - 块数量: {params[1]}")
            if cmd == ISO15693Parser.CMD_WRITE_MULTIPLE_BLOCKS and len(params) > 2:
                extra_info.append(f"    - 写入数据: {params[2:].hex().upper()}")
            return

        if cmd == ISO15693Parser.CMD_WRITE_AFI:
            if params:
                extra_info.append(f"    - AFI: 0x{params[0]:02X}")
            return

        if cmd == ISO15693Parser.CMD_WRITE_DSFID:
            if params:
                extra_info.append(f"    - DSFID: 0x{params[0]:02X}")
            return

        if cmd == ISO15693Parser.CMD_GET_MULTIPLE_BLOCK_SECURITY:
            if params:
                extra_info.append(f"    - 起始块: {params[0]}")
            if len(params) > 1:
                extra_info.append(f"    - 块数量: {params[1]}")
            return

        # SELECT / RESET TO READY / LOCK AFI / LOCK DSFID / GET SYSTEM INFO: 仅含可选UID
        return

    @staticmethod
    def parse_15693_command(cmd, payload, data_len, result):
        """
        解析请求命令。
        请求载荷: [请求FLAG(1)][命令码(1)][参数/数据...]
        payload[0] = 请求FLAG（由 parse_request 负责解析）
        payload[1] = 命令码
        payload[2:] = 命令码之后的参数/数据
        """
        extra_info = result["extra_info"]
        flags = payload[0] if data_len >= 1 else 0
        # 命令码之后的参数/数据；帧尾 2 字节为 CRC16，需先剔除（CRC 由帧级 parse_crc 统一处理）
        params = payload[2:]
        params = params[:-2] if len(params) >= 2 else b''

        # 标准 ISO15693 命令
        if cmd in ISO15693Parser.STANDARD_COMMANDS:
            name = ISO15693Parser.STANDARD_COMMANDS[cmd]
            extra_info.append(f"  - 命令码: 0x{cmd:02X} ({name})")
            if cmd == ISO15693Parser.CMD_INVENTORY:
                ISO15693Parser._parse_standard_params(cmd, flags, params, extra_info)
            else:
                rest = ISO15693Parser._split_uid(cmd, None, flags, params, extra_info)
                ISO15693Parser._parse_standard_params(cmd, flags, rest, extra_info)
            return f"{name} (0x{cmd:02X})"

        # 厂商私有命令：按已识别卡片厂商的定义解析
        if CustomCommandsParser.is_vendor_code(cmd):
            extra_info.append(f"  - 命令码: 0x{cmd:02X} (厂商私有命令)")
            if cmd in (0xA0, 0xA1, 0xB0, 0xB1):
                rest = params
            else:
                rest = ISO15693Parser._split_uid(cmd, ISO15693Parser._card_vendor,
                                                 flags, params, extra_info)
            # UID 解析可能已更新当前卡片厂商，这里再取一次
            vendor = ISO15693Parser._card_vendor
            if vendor:
                extra_info.append(f"    - 按卡片厂商 {vendor} 的定义解析")
            else:
                extra_info.append(f"    - 卡片厂商未识别，列出各厂商可能含义")
            return CustomCommandsParser.parse(cmd, vendor, flags, rest, extra_info)

        # 未识别命令
        extra_info.append(f"  - 命令码: 0x{cmd:02X} (未识别命令)")
        rest = ISO15693Parser._split_uid(cmd, None, flags, params, extra_info)
        if rest:
            extra_info.append(f"    - 参数/数据: {rest.hex().upper()}")
        return f"未识别命令 (0x{cmd:02X})"

    @staticmethod
    def parse_request(payload, data_len, result):
        """解析请求帧: [请求FLAG(1)][命令码(1)][参数/数据...]"""
        if data_len < 1:
            return
        ISO15693Parser.parse_flags(payload[0], result["extra_info"])
        if data_len < 2:
            result["commands"].append("请求帧缺少命令码")
            return
        cmd = payload[1]
        # 记录最近一次请求命令，供响应帧(不含命令码)推断类型
        ISO15693Parser._last_req_cmd = cmd
        cmd_desc = ISO15693Parser.parse_15693_command(cmd, payload, data_len, result)
        result["commands"].append(cmd_desc)

    @staticmethod
    def parse_packet(packet_bytes):
        """
        解析完整数据包。
        数据格式：[方向1][时间戳4][长度2][有效位1][数据N]
        """
        if len(packet_bytes) < 8:
            return {"error": "数据包太短，至少需要8字节头部（方向1+时间戳4+长度2+有效位1）"}

        direction_byte = packet_bytes[0]
        timestamp_raw = struct.unpack('>I', packet_bytes[1:5])[0]
        data_len = struct.unpack('>H', packet_bytes[5:7])[0]
        valid_bits = packet_bytes[7]
        payload = packet_bytes[8:8+data_len]
        # 抓包/粘贴数据可能缺失 1~2 字节，此时按实际可用数据继续解析，仅给出提示
        payload_len_note = None
        if len(payload) < data_len:
            payload_len_note = (f"声明载荷 {data_len} 字节，实际仅 {len(payload)} 字节"
                                f"（按实际数据解析，末尾可能缺失 {data_len - len(payload)} 字节）")

        if direction_byte == ord('>'):
            direction_str = Language.get("direction_pcd_to_picc")
            direction_short = ">"
        elif direction_byte == ord('<'):
            direction_str = Language.get("direction_picc_to_pcd")
            direction_short = "<"
        else:
            direction_str = f"未知方向 (0x{direction_byte:02X})"
            direction_short = "?"

        ts_display, ts_value, ts_zero = ISO15693Parser.parse_timestamp(timestamp_raw)

        result = {
            "direction_short": direction_short,
            "direction": direction_str,
            "direction_byte": direction_byte,
            "timestamp_raw": timestamp_raw,
            "timestamp_display": ts_display,
            "timestamp_value": ts_value,
            "timestamp_zero": ts_zero,
            "valid_bits": valid_bits,
            "payload_hex": payload.hex().upper(),
            "payload_len": data_len,
            "commands": [],
            "extra_info": [],
        }

        if payload_len_note:
            result["extra_info"].append(f"  - 长度提示: {payload_len_note}")

        ISO15693Parser.parse_valid_bits_info(direction_byte, valid_bits, result["extra_info"])

        if len(payload) == 0:
            result["commands"].append("空数据")
            return result

        actual_len = len(payload)
        if direction_byte == ord('>'):
            # 请求帧: [请求FLAG][命令码][参数/数据...]
            ISO15693Parser.parse_request(payload, actual_len, result)
        elif direction_byte == ord('<'):
            # 响应帧: [响应FLAG][数据/错误码...]（不含命令码）
            ISO15693Parser.parse_15693_response(direction_byte, payload, actual_len, result)
            if not result["commands"]:
                result["commands"].append("响应帧 (卡片→阅读器)")
        else:
            ISO15693Parser.parse_request(payload, actual_len, result)

        # 帧级 CRC16 校验（覆盖 FLAG 至 CRC 末字节，见 ISO15_crc.h）
        ISO15693Parser.parse_crc(payload, result["extra_info"])

        return result
