#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
厂商私有/扩展命令解析器

私有命令码区间（0xA0~0xBF、0xE0 及以上）由各芯片厂商自定义，同一码值在不同厂商
含义不同（例如 0xA2：NXP 为 SET_EAS，TI 为 WRITE_2_BLOCKS）。

解析策略：
  1. 先由 INVENTORY(0x01) 响应中的 UID（或带地址请求中的 UID）按制造商代码识别卡片厂商；
  2. 再按该厂商的命令表解析后续私有命令。

NXP 私有命令定义与项目内 ISO15_cmd.h 保持一致（0xA0~0xBD）。
"""


class CustomCommandsParser:
    """厂商私有命令解析器"""

    # NXP / Philips 私有命令（与 ISO15_cmd.h 对接）
    NXP_COMMANDS = {
        0xA0: "INVENTORY_READ (寻卡读取)",
        0xA1: "FAST_INVENTORY_READ (快速寻卡读取)",
        0xA2: "SET_EAS (开启EAS)",
        0xA3: "RESET_EAS (关闭EAS)",
        0xA4: "LOCK_EAS (锁定EAS)",
        0xA5: "EAS_ALARM (EAS报警)",
        0xA6: "PASSWORD_PROTECT_EAS (密码保护EAS)",
        0xA7: "WRITE_EAS_ID (写EAS ID)",
        0xA8: "READ_EPC (读EPC)",
        0xAB: "GET_NXP_SYSTEM_INFO (获取NXP系统信息)",
        0xB0: "INVENTORY_PAGE_READ (寻卡页读取)",
        0xB1: "FAST_INVENTORY_PAGE_READ (快速寻卡页读取)",
        0xB2: "GET_RANDOM_NUMBER (获取随机数)",
        0xB3: "SET_PASSWORD (设置密码)",
        0xB4: "WRITE_PASSWORD (写入密码)",
        0xB5: "LOCK_PASSWORD (锁定密码)",
        0xB6: "PROTECT_PAGE (保护页)",
        0xB7: "LOCK_PAGE_PROTECTION (锁定页保护条件)",
        0xB8: "GET_MULTI_BLOCK_PROTECTION (获取多块保护状态)",
        0xB9: "DESTROY (销毁标签)",
        0xBA: "ENABLE_PRIVACY (启用隐私模式)",
        0xBB: "64BIT_PASSWORD_PROTECTION (64位密码保护)",
        0xBC: "STAYQUIET_PERSISTENT (持久静默)",
        0xBD: "READ_SIGNATURE (读取签名)",
    }

    # TI Tag-it 私有命令
    TI_COMMANDS = {
        0xA2: "WRITE_2_BLOCKS (写2个块)",
        0xA3: "LOCK_2_BLOCKS (锁定2个块)",
    }

    # 厂商key -> 命令表
    VENDOR_TABLES = {
        "NXP": NXP_COMMANDS,
        "TI": TI_COMMANDS,
    }

    @staticmethod
    def is_vendor_code(cmd):
        """是否处于厂商私有命令码区间"""
        return 0xA0 <= cmd <= 0xBF or cmd >= 0xE0

    @staticmethod
    def parse(cmd, vendor, flags, params, extra_info):
        """
        按已识别厂商解析私有命令。
        vendor: ISO15693Parser 识别出的厂商key（如 "NXP"/"TI"），未识别为 None
        params: 命令码之后的参数（调用方已去除UID）
        """
        table = CustomCommandsParser.VENDOR_TABLES.get(vendor) if vendor else None

        # 1) 已知厂商且命令表中有该码值
        if table is not None and cmd in table:
            name = table[cmd]
            extra_info.append(f"    - {vendor}: {name}")
            CustomCommandsParser._parse_params(cmd, vendor, flags, params, extra_info)
            return f"{vendor} {name} (0x{cmd:02X})"

        # 2) 收集其它厂商对该码值的定义
        found = [(v, t[cmd]) for v, t in CustomCommandsParser.VENDOR_TABLES.items() if cmd in t]

        if vendor is not None:
            # 已识别厂商，但该码值未在其命令表中定义
            extra_info.append(f"    - 0x{cmd:02X}: {vendor} 未定义该私有命令")
            for v, n in found:
                extra_info.append(f"    - 其它厂商 [{v}]: {n}")
            if params:
                extra_info.append(f"    - 参数/数据: {params.hex().upper()}")
            return f"{vendor} 未定义私有命令 (0x{cmd:02X})"

        # 3) 卡片厂商未识别：列出各厂商可能含义
        for v, n in found:
            extra_info.append(f"    - [{v}] {n}")
        if found:
            CustomCommandsParser._parse_params(cmd, found[0][0], flags, params, extra_info)
            desc = f"{found[0][1]} [{found[0][0]}] (0x{cmd:02X})"
            if len(found) > 1:
                desc += " / " + "; ".join(f"{n} [{v}]" for v, n in found[1:])
            return desc

        extra_info.append(f"    - 0x{cmd:02X}: 未知厂商私有命令")
        if params:
            extra_info.append(f"    - 参数/数据: {params.hex().upper()}")
        return f"厂商私有命令 (0x{cmd:02X})"

    @staticmethod
    def _parse_params(cmd, vendor, flags, params, extra_info):
        """解析私有命令码之后的参数/数据（params 已去除UID）"""

        # 寻卡/寻卡页读取：与 INVENTORY 类似 [AFI(若Inventory AFI标志)][Mask长度][Mask]
        if cmd in (0xA0, 0xA1, 0xB0, 0xB1):
            idx = 0
            if (flags & 0x10) and len(params) > idx:
                extra_info.append(f"    - AFI: 0x{params[idx]:02X}")
                idx += 1
            if len(params) > idx:
                mask_bits = params[idx]
                extra_info.append(f"    - Mask长度: {mask_bits} bits")
                idx += 1
                nbytes = (mask_bits + 7) // 8
                if nbytes and len(params) >= idx + nbytes:
                    extra_info.append(f"    - Mask: {params[idx:idx+nbytes].hex().upper()}")
            return

        # 0xA2: NXP 无参数；TI WRITE_2_BLOCKS = [UID]+块号+2块数据
        if cmd == 0xA2:
            if vendor == "TI":
                if params:
                    extra_info.append(f"    - 起始块号: {params[0]}")
                if len(params) > 1:
                    extra_info.append(f"    - 写入数据(2块): {params[1:].hex().upper()}")
            elif params:
                extra_info.append(f"    - 参数/数据: {params.hex().upper()}")
            return

        # 0xA3: NXP 无参数；TI LOCK_2_BLOCKS = [UID]+块号
        if cmd == 0xA3:
            if vendor == "TI":
                if params:
                    extra_info.append(f"    - 起始块号: {params[0]}")
            elif params:
                extra_info.append(f"    - 参数/数据: {params.hex().upper()}")
            return

        # SET_PASSWORD / WRITE_PASSWORD = [UID]+密码标识(1)+密码(4)
        if cmd in (0xB3, 0xB4):
            if params:
                extra_info.append(f"    - 密码标识: 0x{params[0]:02X}")
            if len(params) > 1:
                extra_info.append(f"    - 密码: {params[1:5].hex().upper()}")
            return

        # LOCK_PASSWORD = [UID]+密码标识(1)
        if cmd == 0xB5:
            if params:
                extra_info.append(f"    - 密码标识: 0x{params[0]:02X}")
            return

        # WRITE_EAS_ID = [UID]+EAS ID(4)
        if cmd == 0xA7:
            if params:
                extra_info.append(f"    - EAS ID: {params[:4].hex().upper()}")
            return

        # GET_MULTI_BLOCK_PROTECTION = [UID]+起始块+块数量
        if cmd == 0xB8:
            if params:
                extra_info.append(f"    - 起始块: {params[0]}")
            if len(params) > 1:
                extra_info.append(f"    - 块数量: {params[1]}")
            return

        # PROTECT_PAGE / LOCK_PAGE_PROTECTION：保护条件
        if cmd in (0xB6, 0xB7):
            if params:
                extra_info.append(f"    - 参数/数据: {params.hex().upper()}")
            return

        # 其余命令无附加参数；若有剩余字节按原始数据展示
        if params:
            extra_info.append(f"    - 参数/数据: {params.hex().upper()}")
