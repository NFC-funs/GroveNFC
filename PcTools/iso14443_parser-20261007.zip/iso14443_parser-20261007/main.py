#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
ISO 14443A 协议解析器 - 主程序入口
"""

import tkinter as tk
import sys
import os
import types

_PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _PROJECT_ROOT)

# Python 3.9 兼容: 内置 parser C 扩展模块会优先于本地 parser 包被加载,
# 导致 'parser' is not a package 错误. 手动注册本地 parser 包到 sys.modules,
# 但不执行 __init__.py (避免循环导入), 子模块按需导入即可.
if 'parser' in sys.builtin_module_names:
    _parser_mod = types.ModuleType('parser')
    _parser_mod.__path__ = [os.path.join(_PROJECT_ROOT, 'parser')]
    sys.modules['parser'] = _parser_mod

from ui.main_window import MainWindow


def main():
    root = tk.Tk()
    app = MainWindow(root)
    root.protocol("WM_DELETE_WINDOW", app.on_closing)
    root.mainloop()


if __name__ == "__main__":
    main()