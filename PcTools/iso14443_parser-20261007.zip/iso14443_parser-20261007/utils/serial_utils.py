#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
串口工具类
"""

import serial
import serial.tools.list_ports


class SerialUtils:
    """串口工具类"""
    
    DEFAULT_BAUDRATE = 115200
    
    @staticmethod
    def list_ports():
        return serial.tools.list_ports.comports()
    
    @staticmethod
    def connect(port, baudrate=DEFAULT_BAUDRATE, timeout=0.1):
        return serial.Serial(port, baudrate, timeout=timeout)
    
    @staticmethod
    def disconnect(conn):
        if conn and conn.is_open:
            conn.close()
    
    @staticmethod
    def read_data(conn, timeout=0.01):
        if not conn or not conn.is_open:
            return None
        
        if conn.in_waiting > 0:
            return conn.read(conn.in_waiting)
        return None
    
    @staticmethod
    def write_data(conn, data):
        if conn and conn.is_open:
            return conn.write(data)
        return 0